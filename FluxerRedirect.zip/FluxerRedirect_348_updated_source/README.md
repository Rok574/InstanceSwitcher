# FluxerRedirect — Discord iOS 348.0 update

Target IPA inspected: Discord **348.0 (113691)**, minimum iOS **16.0**, arm64.

## Build

This package contains the updated source and a macOS/Xcode build script. A real iOS
`.dylib` cannot be compiled in this Linux environment because Apple's iPhoneOS SDK
and `codesign` are not available here.

On a Mac with Xcode command-line tools:

```sh
./build.sh
```

Or push this folder to a GitHub repository and run the included **Build FluxerRedirect
(Discord 348.0)** workflow. Download the `FluxerRedirect-iOS-arm64-Discord-348`
artifact from the workflow run.

## Important compatibility status

This update aligns the build target with the uploaded Discord 348.0 IPA (iOS 16.0+)
and keeps the previously launch-safe Stage 4 hook implementation. It does **not**
claim to fix Fluxer login or registration yet. Fluxer's auth API requires its own
request schema and `X-Captcha-Token` challenge flow; the existing URL rewrite does
not translate Discord's auth request bodies or solve that challenge. Guessing those
formats would risk breaking launch or exposing account data.

Logs are diagnostic only; do not add passwords, tokens, cookies, email addresses,
or request/response body values to logs.
