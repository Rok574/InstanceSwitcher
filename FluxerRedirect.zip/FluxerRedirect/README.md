# FluxerRedirect

Inject `FluxerRedirect.dylib` into the Discord iOS IPA. It sends Discord traffic to a Fluxer instance.

| Discord | Becomes |
| --- | --- |
| `discord.com/api/v9/...` | `{api_public}/v1/...` |
| `gateway.discord.gg` (ws) | discovered gateway, `?v=1&encoding=json`, no compression |
| `cdn.discordapp.com/avatars,icons,banners,emojis,stickers,...` | `{media}/...` (same paths) |
| `media.discordapp.net/attachments,external` | `{media}/...` |
| `cdn.discordapp.com/embed/avatars/N.png` | Fluxer's default avatar, embedded in the dylib (no network) |
| `discord.gg/CODE`, `discord.com/invite/CODE` | `{invite}/CODE` |
| `discord.com/channels/...` | `{webapp}/channels/...` |

Also: Identify payload is cleaned to what Fluxer accepts, Discord-only gateway opcodes are dropped, links tapped outside the app are converted, and other Discord hosts are blocked so nothing leaks (`block_unmapped`).

Settings are at the top of `FluxerRedirect.m` (instance, block_unmapped, debug, optional endpoint overrides), so no config file is needed. Endpoints come from `<instance>/.well-known/fluxer` (cached on disk). To point at a self-hosted instance or override any endpoint, put `Documents/fluxer_redirect.json` in the app container; keys: `instance, api, gateway, media, static_cdn, invite, webapp, block_unmapped, debug`.

Build: `./build.sh` on a Mac, or push to GitHub and run the included workflow. Single `.m` file, so it also builds on-device.

Limits: voice/video (Discord RTC servers) can't be redirected, and Discord's gateway events/objects aren't translated, so screens that expect Discord-only fields may be blank.
