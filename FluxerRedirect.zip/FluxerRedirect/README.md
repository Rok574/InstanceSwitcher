# FluxerRedirect — Discord iOS 348.0 + Fluxer captcha solver

Target IPA: Discord **348.0 (113691)**, minimum iOS **16.0**, arm64.

## What's new: automatic Fluxer captcha

Fluxer protects `POST /v1/auth/login`, `/register`, `/register/handoff`, `/forgot` and `/recover`
with an [ALTCHA](https://altcha.org) proof-of-work challenge (`PBKDF2/SHA-256`). Requests must carry
`X-Captcha-Token`; without it the server answers `400 CAPTCHA_REQUIRED`. The Discord app cannot
produce that token, which is why login failed with a verification error.

Now, when a request for one of those endpoints is redirected to Fluxer, the tweak:

1. sends a bare `POST {}` to the endpoint (captcha is checked before the body is validated, so no
   login/registration happens and none of your data is sent) to get a challenge,
2. solves it natively with `CCKeyDerivationPBKDF` on all cores,
3. adds the `X-Captcha-Token` header to the real request.

Registration validates its body *before* the captcha, so for register the challenge is taken from
`/v1/auth/forgot` instead.

Because the exact byte layout altcha-lib v2 feeds to PBKDF2 could not be checked from the source
available (only its callers), the tweak **verifies it against your server the first time**: it submits
a solved token to the bare probe and watches for `INVALID_CAPTCHA`. A rejected layout is followed by
the next of four candidates until the server accepts one. Expect 1–3 extra solves on the first
login after launch. The result is logged (`captcha: variant N accepted`).

If the instance has captcha turned off, the probe returns no challenge and requests go out untouched.

Set `"solve_captcha": false` in `Documents/fluxer_redirect.json` to disable.

## Gateway (WSS) notes

- Fluxer's gateway URL comes from `endpoints.gateway` in the discovery document. Discovery is tried at
  `<instance>/.well-known/fluxer`, `<instance>/api/v1/.well-known/fluxer`, and (for `web.` hosts)
  `https://api.<root>/v1/.well-known/fluxer`. If all fail, the gateway is guessed
  (`wss://gateway.<root>` for `web.` hosts) instead of blocking the socket.
- The URL always gets `v=1&encoding=json`. `compress` is dropped (plain JSON frames; the app accepts them).
  Set `"gateway_zstd": true` to keep `compress=zstd-stream` if the app asked for it. Fluxer has no zlib-stream.
- Every class whose name contains "websocket" is scanned and hooked (URL rewrite, Identify cleanup on send,
  and `WS OPEN/FAIL/CLOSE/RECV/SEND` log lines), again after the app becomes active. A `User-Agent` is added
  to the handshake if missing. Ported from the older InstanceSwitcher project.
- Log lines to check: `discovery ok/miss`, `endpoints ... gateway=`, `gateway: app asked X -> Y`.
  No `gateway: app asked` line means the app isn't using a hooked WebSocket class.

- Three-finger instance menu includes **Nitro Preview: On/Off**. This is a local-only display hint for the signed-in user's own profile (`premium_type` in the locally transformed READY/profile payload). It does not change Fluxer's account, billing, server entitlements, upload limits, or paid-feature authorization. Restart the app after changing it.

- Outgoing frames are translated to Fluxer's protocol: Discord op 37 / legacy op 14 become Fluxer Lazy Request
  (op 14, guilds marked active), op 3/4/8 are rebuilt with only fields Fluxer accepts, Discord-only opcodes
  (incl. 13) are dropped instead of risking a 4001/4002 close.
- READY is converted to Discord's v9 shape (`merged_members`, `read_state`, `user_guild_settings` entries,
  `merged_presences`, `users`, recipient ids, guild defaults, `v`, `resume_gateway_url`, ...). Key names of
  Fluxer's READY are logged as `READY d keys:` for further tuning.

- API requests to the Fluxer host go through a small proxy that fixes rate-limit headers (Fluxer's
  `X-RateLimit-Reset` is a millisecond timestamp, Discord's is seconds; `Reset-After` is added and clamped),
  normalises 429 bodies, and detects global limits from both the JSON body and `X-RateLimit-Scope` /
  `X-RateLimit-Global` headers. It also swallows Discord-only telemetry POSTs (`/science`, `/track`, `/metrics`),
  and throttles typing (1 per 8s per channel) and duplicate acks. Every 429 is logged as `HTTP 429 METHOD path ...`.
  It does not bypass server limits or replay failed message POSTs, which could duplicate messages.

- Media upload compatibility: the attachment-plan JSON is normalized to Fluxer's `attachments` shape, signed upload destinations are remembered in memory, and `PUT` requests to those exact destinations have app API credentials/cookies removed and the returned content type applied when absent. Common image, video, audio, HEIC/HEIF/AVIF, and document MIME types are inferred from filenames when missing. Upload transport diagnostics log only the host, method, MIME type, and whether the destination was registered; signed URLs and file contents are never logged. Files above 10 MiB require the client's multipart-part upload and `/attachments/complete` flow; this tweak does not synthesize missing parts or completion requests.

- Role icons: Fluxer roles only have `unicode_emoji`; Discord draws role icons only when the guild has the
  `ROLE_ICONS` feature, so it is added to every guild (READY, GUILD_CREATE/SYNC, GUILD_UPDATE).
- Message pages: Fluxer reverses the array when `after` is used; the proxy re-sorts every channel message
  list newest-first (this is what made scrolling skip and a channel need a second tap to reach the bottom).
- GIF picker: Discord's `GET /gifs/trending-search` maps to Fluxer's `GET /gifs/featured` (featured GIF plus categories), `GET /gifs/trending-gifs` maps to `/gifs/trending`, and `POST /gifs/select` maps to `/gifs/register-share`. Search and suggestion paths already match Fluxer's `/gifs/search` and `/gifs/suggest`. The Fluxer instance must have GIF search enabled and a provider configured; otherwise Fluxer returns `FEATURE_TEMPORARILY_DISABLED` / `403` and the picker cannot populate.
- Typing: TYPING_START gets a full `member.user` (from a user cache fed by READY, messages, member lists).
  Member list items, presences, chunks and PRESENCE_UPDATE get Discord's `activities` / `client_status`.
  PASSIVE_UPDATES is converted to PASSIVE_UPDATE_V1 so big guilds keep unread state current.

## Not covered

- Only the five endpoints above are handled. Group DM creation, gift redeem and application creation
  can also be gated; they would need a response hook.
- Escalated register cost (after heavy sign-ups from one network) is not matched, because the
  challenge comes from `/forgot`.
- Discord's login/register request and response shapes versus Fluxer's are not translated. Fluxer's
  login schema ignores unknown fields, but check the log if login still fails after the captcha.
- The HTTP error logger now reads the response body only after it has been initialized; this fixes a
  compile-time ordering error in the previous source archive.
- Unsupported Discord-only stateful routes (settings-proto, billing, notes, collectibles, voice, etc.)
  are deliberately not answered with fabricated success data. They need real endpoint-specific adapters.
- Not compiled or run in the environment this was written in: build it and check the log.

## Build

On a Mac with Xcode command-line tools: `./build.sh`, or push this folder to GitHub and run the
**Build FluxerRedirect** workflow, then download the `FluxerRedirect-iOS-arm64-Discord-348` artifact.

## Debugging

Log: `<App>/Documents/fluxer_redirect.log`. Look for lines starting `captcha:`. Logs never contain
passwords, tokens, emails or request/response bodies.

### Current-user profile editing

The compatibility layer now normalizes `PATCH /api/v*/users/@me` requests for Fluxer's current-user route. It preserves supported profile/account fields (username, display name, avatar, banner, bio, pronouns, accent color and related documented settings) and removes Discord-only client decoration fields that Fluxer rejects. Avatar/banner data URIs are passed through because Fluxer accepts the `data:...;base64,` form. The server remains authoritative for validation, account verification, change cooldowns, and premium-gated features; this does not bypass those checks.

## Instance manager (three-finger hold)

Hold three fingers on the screen for about one second to open the instance manager. It can add an HTTPS instance, switch between saved origins, and remove custom entries. The selected origin is written to `Documents/fluxer_redirect.json`; fully quit and relaunch the app after changing it. The built-in `https://web.fluxer.app` entry cannot be removed.

Security note: only sign in to instances you trust. The app's authentication storage is shared by the app process and this tweak does **not** create separate encrypted login-token stores per instance. Sign out before switching instances; do not assume that switching servers isolates credentials. Cookies remain scoped by their cookie domain, and the tweak does not fabricate or periodically rotate cookies. Server-issued session updates are left to the app/server.

## Current compatibility limits

- Thread lazy subscriptions explicitly request Fluxer's `threads` subscription flag. This does not yet implement a complete Discord-to-Fluxer thread event adapter; thread behavior still needs a fresh gateway trace from the target instance.
- Attachment upload-plan JSON is normalized when it passes through the API proxy. Multipart upload bodies are intentionally left to the app's native upload path. The current diagnostics log request content type and byte counts (never file contents); a failed upload log is needed before safely changing the upload flow.
- Discord DM call-connect opcode 13 is not sent to Fluxer because it is not a compatible Fluxer voice-signaling message. Standard voice-state opcode 4 is translated, but full voice calling is not implemented. Sending an invented signaling frame would break the gateway session.
- HTTP 429 responses are normalized for the Discord client, but the tweak does not bypass server rate limits or automatically replay requests.
- Build/test status: source-level checks only in this environment. Build the dylib on macOS with Xcode using `./build.sh`; this archive does not contain a compiled dylib.


## Media upload compatibility update

The media compatibility layer now records the exact signed upload URLs returned by
Fluxer's attachment-upload-plan response. When the app later sends bytes to one
of those exact URLs, the tweak removes API authorization/cookie headers from that
storage request (Fluxer's upload contract says not to send `Authorization`) and
preserves the app's original upload body. The URL registry is in-memory only,
bounded, and does not write signed URLs to the log.

The tweak also normalizes attachment metadata in successful single-message
responses, as it already did for message-history responses.

Fluxer's documented upload flow is: request an upload plan, PUT the file bytes
to the returned URL, complete multipart uploads when applicable, then attach
the returned `upload_filename` when creating the message. Uploads over 10 MiB
use multipart parts and require the completion endpoint. This update addresses
the signed-URL request-header compatibility issue; it does not implement a
separate multipart chunk uploader if the Discord client never issues the
required part PUTs or completion request.

Device testing is still required. Check the log for the sanitized
`upload: registered signed upload destinations=...` breadcrumb and the
HTTP status for the subsequent upload-plan, PUT, completion, and message
requests. Do not share signed upload URLs or authorization tokens in logs.


## Profile badge compatibility update

Successful Fluxer `GET /v1/users/{id}/profile` responses now preserve the original
`profile_badges` array and also expose a Discord-client-compatible `badges` array.
Each badge keeps its Fluxer fields and receives compatible `id`, `description`,
`icon`, and `link` aliases when the corresponding source values exist. Fluxer
public user flags are translated into the matching Discord public flag bits for
Staff, Partner, and Bug Hunter Level 1; unrelated Fluxer flags are not presented
as Discord badges.

Fluxer only returns another person's full profile when the signed-in account
has a qualifying relationship (friendship, pending friend request, mutual guild,
or shared group DM). A 403 `MISSING_ACCESS` is an intentional access restriction,
not a badge-format error; this tweak does not bypass it or invent profile data.
Custom badge images may use `asset_url`; built-in badge images use the instance
static CDN badge hash. Device testing is still required.
