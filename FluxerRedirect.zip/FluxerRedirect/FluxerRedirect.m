// FluxerRedirect.m
// Injectable dylib for the Discord iOS app: sends Discord traffic to a Fluxer
// instance and converts URLs/gateway payloads to what Fluxer expects.
// Plain ObjC runtime hooks only (no Substrate), so it works in sideloaded IPAs.
// Build: ./build.sh   Config: <App>/Documents/fluxer_redirect.json (optional)

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <ImageIO/ImageIO.h>
#import <WebKit/WebKit.h>
#import <objc/runtime.h>
#import <CommonCrypto/CommonKeyDerivation.h>
#import <CommonCrypto/CommonDigest.h>
#import <stdatomic.h>
#import <objc/message.h>
#include <string.h>
#include <strings.h>
#include <sys/utsname.h>

#pragma clang diagnostic ignored "-Wdeprecated-declarations"

// Build stage for bisecting crashes (compile with -DFX_STAGE=n):
//  0 = loads and does nothing   1 = + endpoint discovery   2 = + NSURLSession hooks
//  3 = + websocket hooks        4 = validated signatures + per-hook exception logging
#ifndef FX_STAGE
#define FX_STAGE 4
#endif

// ===================== SETTINGS (edit here, no external files needed) =====================
#define FX_INSTANCE        @"https://web.fluxer.app"   // your Fluxer instance
#define FX_BLOCK_UNMAPPED  YES                          // block Discord hosts that have no Fluxer equivalent
#define FX_DEBUG           NO                           // verbose logging
// Optional endpoint overrides. Leave @"" to auto-discover from the instance.
#define FX_API             @""
#define FX_GATEWAY         @""
#define FX_MEDIA           @""
#define FX_STATIC_CDN      @""
#define FX_INVITE          @""
#define FX_WEBAPP          @""
// ===========================================================================================

static NSString *gInstance = FX_INSTANCE;
static NSString *gSelfUserID;
static NSString *gAPI, *gGateway, *gMedia, *gStatic, *gInvite, *gWebapp;
static BOOL gBlockUnmapped = FX_BLOCK_UNMAPPED;
static BOOL gDebug = FX_DEBUG;
static BOOL gKeepZstd = NO;        // default: strip compress (plain JSON works with the app); "gateway_zstd": true keeps zstd-stream
static BOOL gSolveCaptcha = YES;   // solve Fluxer's ALTCHA check for the Discord app (set "solve_captcha": false to disable)
static BOOL gNitroPreview = NO;    // local-only cosmetic preview; never changes server entitlements
static dispatch_once_t gResolveOnce;
static dispatch_group_t gResolveGroup;
static volatile BOOL gResolved = NO;
static NSObject *gUploadURLLock;
static NSMutableDictionary *gUploadURLInfo;
static NSObject *gBadgeURLLock;
static NSMutableDictionary *gBadgeURLInfo;
static NSString * const kFXBadgeProtocolHandled = @"FXBadgeSVGProtocolHandled";
static NSDictionary *FXUploadInfoForURL(NSURL *url);
static void FXRememberUploadURLs(NSData *data);
static NSString *FXS(id v);

#define FXLog(fmt, ...) do { if (gDebug) NSLog(@"[FluxerRedirect] " fmt, ##__VA_ARGS__); } while (0)

// Always-on breadcrumb log: <App>/Documents/fluxer_redirect.log (readable in Files / via a file manager)
static void FXFileLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *line = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[FluxerRedirect] %@", line);
    @try {
        NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.log"];
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
        if (!h) {
            [@"" writeToFile:path atomically:NO encoding:NSUTF8StringEncoding error:nil];
            h = [NSFileHandle fileHandleForWritingAtPath:path];
        }
        [h seekToEndOfFile];
        [h writeData:[[line stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]];
        [h closeFile];
    } @catch (NSException *e) {}
}

#define FXSET(var, val) do { NSString *_v = (val); if (!((var) == _v || [(var) isEqualToString:_v])) (var) = _v; } while (0)

#pragma mark - Config + discovery

static NSString *FXTrim(NSString *s) {
    if (![s isKindOfClass:NSString.class]) return nil;
    while ([s hasSuffix:@"/"]) s = [s substringToIndex:s.length - 1];
    return s.length ? s : nil;
}

static NSString *FXCachePath(void) {
    return [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_discovery_cache.json"];
}

static NSDictionary *FXFetchJSON(NSString *urlStr) {
    NSURL *u = [NSURL URLWithString:urlStr];
    if (!u) return nil;
    NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    cfg.timeoutIntervalForRequest = 4;
    NSURLSession *s = [NSURLSession sessionWithConfiguration:cfg];
    __block NSDictionary *out = nil;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    [[s dataTaskWithURL:u completionHandler:^(NSData *data, NSURLResponse *r, NSError *e) {
        NSHTTPURLResponse *h = (NSHTTPURLResponse *)r;
        if (data && [h isKindOfClass:NSHTTPURLResponse.class] && h.statusCode == 200) {
            id j = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            if ([j isKindOfClass:NSDictionary.class]) out = j;
        }
        dispatch_semaphore_signal(sem);
    }] resume];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 6 * NSEC_PER_SEC));
    [s invalidateAndCancel];
    return out;
}

static NSDictionary *FXLoadOverrides(void) {
    NSDictionary *ov = nil;
    NSData *cf = [NSData dataWithContentsOfFile:
        [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.json"]];
    if (cf) {
        id j = [NSJSONSerialization JSONObjectWithData:cf options:0 error:nil];
        if ([j isKindOfClass:NSDictionary.class]) ov = j;
    }
    NSString *envInst = NSProcessInfo.processInfo.environment[@"FLUXER_INSTANCE"];
    NSString *inst = FXTrim(ov[@"instance"]) ?: FXTrim(envInst) ?: gInstance;
    FXSET(gInstance, inst);
    if ([ov[@"block_unmapped"] isKindOfClass:NSNumber.class]) gBlockUnmapped = [ov[@"block_unmapped"] boolValue];
    if ([ov[@"debug"] isKindOfClass:NSNumber.class]) gDebug = [ov[@"debug"] boolValue];
    if ([ov[@"gateway_zstd"] isKindOfClass:NSNumber.class]) gKeepZstd = [ov[@"gateway_zstd"] boolValue];
    if ([ov[@"solve_captcha"] isKindOfClass:NSNumber.class]) gSolveCaptcha = [ov[@"solve_captcha"] boolValue];
    if ([ov[@"nitro_preview"] isKindOfClass:NSNumber.class]) gNitroPreview = [ov[@"nitro_preview"] boolValue];
    // Built-in settings first; the optional Documents/fluxer_redirect.json overrides them.
    NSMutableDictionary *merged = [NSMutableDictionary dictionary];
    NSDictionary *consts = @{@"api": FX_API, @"gateway": FX_GATEWAY, @"media": FX_MEDIA,
                             @"static_cdn": FX_STATIC_CDN, @"invite": FX_INVITE, @"webapp": FX_WEBAPP};
    for (NSString *k in consts) if ([consts[k] length]) merged[k] = consts[k];
    [merged addEntriesFromDictionary:ov ?: @{}];
    return merged;
}

static NSDictionary *FXReadCache(void) {
    NSData *c = [NSData dataWithContentsOfFile:FXCachePath()];
    id j = c ? [NSJSONSerialization JSONObjectWithData:c options:0 error:nil] : nil;
    return [j isKindOfClass:NSDictionary.class] ? j : nil;
}

static void FXApply(NSDictionary *ov, NSDictionary *disc) {
    NSDictionary *ep = [disc[@"endpoints"] isKindOfClass:NSDictionary.class] ? disc[@"endpoints"] : nil;
    NSString *inst = gInstance;
    FXSET(gAPI, FXTrim(ov[@"api"]) ?: FXTrim(ep[@"api_public"]) ?: FXTrim(ep[@"api_client"])
                ?: FXTrim(ep[@"api"]) ?: [inst stringByAppendingString:@"/api"]);
    FXSET(gGateway, FXTrim(ov[@"gateway"]) ?: FXTrim(ep[@"gateway"]));
    if (!gGateway.length) {
        // No discovery (offline / wrong path) and no override: guess instead of blocking every WSS connect.
        NSURLComponents *iu = [NSURLComponents componentsWithString:inst];
        NSString *h = iu.host.lowercaseString ?: @"";
        NSString *guess;
        if ([h hasPrefix:@"web."]) guess = [NSString stringWithFormat:@"wss://gateway.%@", [h substringFromIndex:4]];
        else guess = [NSString stringWithFormat:@"%@://%@/gateway",
                      [iu.scheme.lowercaseString isEqualToString:@"http"] ? @"ws" : @"wss",
                      iu.port ? [NSString stringWithFormat:@"%@:%@", h, iu.port] : h];
        FXSET(gGateway, guess);
        FXFileLog(@"gateway: none from discovery/overrides, guessing %@", guess);
    }
    FXSET(gMedia,   FXTrim(ov[@"media"]) ?: FXTrim(ep[@"media"]));
    FXSET(gStatic,  FXTrim(ov[@"static_cdn"]) ?: FXTrim(ep[@"static_cdn"]));
    FXSET(gInvite,  FXTrim(ov[@"invite"]) ?: FXTrim(ep[@"invite"]));
    FXSET(gWebapp,  FXTrim(ov[@"webapp"]) ?: FXTrim(ep[@"webapp"]) ?: inst);
    FXFileLog(@"endpoints instance=%@ api=%@ gateway=%@ media=%@ invite=%@ webapp=%@ (from %@)",
              gInstance, gAPI, gGateway, gMedia, gInvite, gWebapp, disc ? @"discovery" : @"defaults");
}

// Where the discovery document can live. The docs say /.well-known/fluxer on the instance origin, but the
// hosted web app (web.fluxer.app) is a separate origin from the API (api.fluxer.app/v1/.well-known/fluxer).
static NSArray<NSString *> *FXDiscoveryCandidates(void) {
    NSMutableArray *c = [NSMutableArray array];
    [c addObject:[gInstance stringByAppendingString:@"/.well-known/fluxer"]];
    [c addObject:[gInstance stringByAppendingString:@"/api/v1/.well-known/fluxer"]];
    [c addObject:[gInstance stringByAppendingString:@"/api/.well-known/fluxer"]];
    NSURLComponents *u = [NSURLComponents componentsWithString:gInstance];
    NSString *h = u.host.lowercaseString ?: @"";
    if ([h hasPrefix:@"web."]) {
        NSString *root = [h substringFromIndex:4];
        [c addObject:[NSString stringWithFormat:@"https://api.%@/v1/.well-known/fluxer", root]];
        [c addObject:[NSString stringWithFormat:@"https://api.%@/.well-known/fluxer", root]];
    }
    return c;
}

// Runs on a background queue: refresh discovery from the network, then apply.
static void FXResolve(void) {
    NSDictionary *ov = FXLoadOverrides();
    NSDictionary *disc = nil;
    for (NSString *cand in FXDiscoveryCandidates()) {
        disc = FXFetchJSON(cand);
        if ([disc[@"endpoints"] isKindOfClass:NSDictionary.class]) { FXFileLog(@"discovery ok: %@", cand); break; }
        FXFileLog(@"discovery miss: %@", cand);
        disc = nil;
    }
    if (disc) [[NSJSONSerialization dataWithJSONObject:disc options:0 error:nil] writeToFile:FXCachePath() atomically:YES];
    else disc = FXReadCache();
    FXApply(ov, disc);
}

// Never blocks the main thread for long; with a cached discovery document it never blocks at all.
static void FXStartResolve(void) {
    dispatch_once(&gResolveOnce, ^{
        gResolveGroup = dispatch_group_create();
        NSDictionary *ov = FXLoadOverrides();
        NSDictionary *cached = FXReadCache();
        if (cached) { FXApply(ov, cached); gResolved = YES; }
        dispatch_group_enter(gResolveGroup);
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            @try { FXResolve(); } @catch (NSException *e) { FXFileLog(@"resolve exception: %@", e); }
            gResolved = YES;
            dispatch_group_leave(gResolveGroup);
        });
    });
}

static void FXEnsureResolved(void) {
    FXStartResolve();
    if (gResolved) return;
    dispatch_group_wait(gResolveGroup, dispatch_time(DISPATCH_TIME_NOW,
                        ([NSThread isMainThread] ? 1 : 12) * NSEC_PER_SEC));
}

#pragma mark - Three-finger instance menu

static void FXShowInstanceMenu(void);

@interface FXInstanceGestureTarget : NSObject
- (void)fx_threeFingerHold:(UILongPressGestureRecognizer *)gesture;
@end
@implementation FXInstanceGestureTarget
- (void)fx_threeFingerHold:(UILongPressGestureRecognizer *)gesture { if (gesture.state == UIGestureRecognizerStateBegan) FXShowInstanceMenu(); }
@end

static char kFXInstanceGestureKey;

static UIViewController *FXTopController(UIViewController *vc) {
    while (vc.presentedViewController) vc = vc.presentedViewController;
    if ([vc isKindOfClass:UINavigationController.class])
        return FXTopController(((UINavigationController *)vc).visibleViewController ?: vc);
    if ([vc isKindOfClass:UITabBarController.class])
        return FXTopController(((UITabBarController *)vc).selectedViewController ?: vc);
    return vc;
}

static BOOL FXValidInstanceURL(NSString *value) {
    NSURLComponents *c = [NSURLComponents componentsWithString:FXTrim(value) ?: @""];
    return ([c.scheme.lowercaseString isEqualToString:@"https"] || [c.scheme.lowercaseString isEqualToString:@"http"]) &&
           c.host.length > 0 && !c.user.length && !c.password.length && !c.query.length && !c.fragment.length;
}

static NSDictionary *FXInstanceConfig(void) {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    id json = data ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil] : nil;
    return [json isKindOfClass:NSDictionary.class] ? json : @{};
}

static NSArray<NSString *> *FXSavedInstances(void) {
    NSDictionary *cfg = FXInstanceConfig();
    NSMutableArray *items = [NSMutableArray array];
    id saved = cfg[@"instances"];
    if ([saved isKindOfClass:NSArray.class]) {
        for (id value in saved) {
            NSString *url = FXTrim(value);
            if (url.length && FXValidInstanceURL(url) && ![items containsObject:url]) [items addObject:url];
        }
    }
    NSString *active = FXTrim(cfg[@"instance"]) ?: FX_INSTANCE;
    if (FXValidInstanceURL(active) && ![items containsObject:active]) [items insertObject:active atIndex:0];
    if (![items containsObject:FX_INSTANCE]) [items addObject:FX_INSTANCE];
    return items;
}

static void FXWriteInstanceConfig(NSArray<NSString *> *instances, NSString *active) {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.json"];
    NSMutableDictionary *cfg = [FXInstanceConfig() mutableCopy];
    NSMutableArray *valid = [NSMutableArray array];
    for (id value in instances) {
        NSString *url = FXTrim(value);
        if (url.length && FXValidInstanceURL(url) && ![valid containsObject:url]) [valid addObject:url];
    }
    if (![valid containsObject:FX_INSTANCE]) [valid addObject:FX_INSTANCE];
    NSString *selected = FXTrim(active);
    if (!selected.length || ![valid containsObject:selected]) selected = FX_INSTANCE;
    cfg[@"instances"] = valid;
    cfg[@"instance"] = selected;
    NSData *data = [NSJSONSerialization dataWithJSONObject:cfg options:NSJSONWritingPrettyPrinted error:nil];
    NSString *dir = [path stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    if (data && [data writeToFile:path atomically:YES])
        FXFileLog(@"instance list saved (%lu entries), active=%@; restart the app to reconnect", (unsigned long)valid.count, selected);
    else FXFileLog(@"failed to save instance list");
}

static void FXWriteNitroPreviewConfig(BOOL enabled) {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.json"];
    NSMutableDictionary *cfg = [FXInstanceConfig() mutableCopy];
    cfg[@"nitro_preview"] = @(enabled);
    NSData *data = [NSJSONSerialization dataWithJSONObject:cfg options:NSJSONWritingPrettyPrinted error:nil];
    NSString *dir = [path stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    if (data && [data writeToFile:path atomically:YES]) {
        gNitroPreview = enabled;
        FXFileLog(@"local Nitro preview %@; restart Fluxer to refresh profile UI", enabled ? @"enabled" : @"disabled");
    } else FXFileLog(@"failed to save local Nitro preview setting");
}

static void FXShowInstanceMenu(void);
static void FXShowAddInstance(UIViewController *presenter, NSArray<NSString *> *instances);

static void FXShowInstanceMenu(void) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ FXShowInstanceMenu(); }); return; }
    UIWindow *window = nil;
    for (UIWindow *w in UIApplication.sharedApplication.windows) if (w.isKeyWindow) { window = w; break; }
    UIViewController *presenter = FXTopController(window.rootViewController);
    if (!presenter || presenter.presentedViewController) return;
    NSArray<NSString *> *instances = FXSavedInstances();
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:@"Fluxer Instances"
        message:[NSString stringWithFormat:@"Active: %@\nChoose an instance or add another. Changes require an app restart.", gInstance ?: FX_INSTANCE]
        preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *url in instances) {
        BOOL active = [url isEqualToString:(gInstance ?: FX_INSTANCE)];
        NSString *title = active ? [NSString stringWithFormat:@"%@ (active)", url] : url;
        [menu addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            FXWriteInstanceConfig(instances, url);
            UIAlertController *saved = [UIAlertController alertControllerWithTitle:@"Instance Selected"
                message:@"Fully close and reopen Fluxer to connect. Sign out before switching instances; this build does not isolate the app’s stored login token."
                preferredStyle:UIAlertControllerStyleAlert];
            [saved addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [presenter presentViewController:saved animated:YES completion:nil];
        }]];
    }
    BOOL nitroPreview = [FXInstanceConfig()[@"nitro_preview"] boolValue];
    [menu addAction:[UIAlertAction actionWithTitle:(nitroPreview ? @"Nitro Preview: On" : @"Nitro Preview: Off")
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            FXWriteNitroPreviewConfig(!nitroPreview);
            UIAlertController *saved = [UIAlertController alertControllerWithTitle:@"Nitro Preview Updated"
                message:@"This is a local visual preview for your own account only. It does not grant Nitro, bypass server checks, or unlock paid features. Fully close and reopen Fluxer to refresh your profile."
                preferredStyle:UIAlertControllerStyleAlert];
            [saved addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [presenter presentViewController:saved animated:YES completion:nil];
        }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"Add Instance" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        FXShowAddInstance(presenter, instances);
    }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"Remove an Instance" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        UIAlertController *remove = [UIAlertController alertControllerWithTitle:@"Remove Instance" message:@"Select an instance to remove. The built-in default cannot be removed." preferredStyle:UIAlertControllerStyleActionSheet];
        for (NSString *url in instances) {
            if ([url isEqualToString:FX_INSTANCE]) continue;
            [remove addAction:[UIAlertAction actionWithTitle:url style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
                NSMutableArray *left = [instances mutableCopy]; [left removeObject:url];
                NSString *active = [url isEqualToString:gInstance] ? FX_INSTANCE : gInstance;
                FXWriteInstanceConfig(left, active);
                UIAlertController *saved = [UIAlertController alertControllerWithTitle:@"Instance Removed" message:@"Fully close and reopen Fluxer for the change to take effect." preferredStyle:UIAlertControllerStyleAlert];
                [saved addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
                [presenter presentViewController:saved animated:YES completion:nil];
            }]];
        }
        [remove addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
        remove.popoverPresentationController.sourceView = presenter.view;
        remove.popoverPresentationController.sourceRect = CGRectMake(0, 0, 1, 1);
        [presenter presentViewController:remove animated:YES completion:nil];
    }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    menu.popoverPresentationController.sourceView = presenter.view;
    menu.popoverPresentationController.sourceRect = CGRectMake(0, 0, 1, 1);
    [presenter presentViewController:menu animated:YES completion:nil];
}

static void FXShowAddInstance(UIViewController *presenter, NSArray<NSString *> *instances) {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Add Fluxer Instance"
        message:@"Enter the instance origin, such as https://chat.example.com. Only add an instance you trust; signing in sends your credentials to that server."
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"https://your-fluxer-instance.com";
        field.keyboardType = UIKeyboardTypeURL;
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Save & Switch" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *value = FXTrim(alert.textFields.firstObject.text);
        NSURLComponents *parts = [NSURLComponents componentsWithString:value ?: @""];
        if (!FXValidInstanceURL(value) || ![parts.scheme.lowercaseString isEqualToString:@"https"]) {
            UIAlertController *bad = [UIAlertController alertControllerWithTitle:@"Invalid Instance URL" message:@"Use a valid HTTPS origin only, with no path, query, fragment, or login details." preferredStyle:UIAlertControllerStyleAlert];
            [bad addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [presenter presentViewController:bad animated:YES completion:nil];
            return;
        }
        NSMutableArray *updated = [instances mutableCopy];
        if (![updated containsObject:value]) [updated addObject:value];
        FXWriteInstanceConfig(updated, value);
        UIAlertController *saved = [UIAlertController alertControllerWithTitle:@"Instance Saved" message:@"Fully close and reopen Fluxer to connect. Sign out before switching; the app’s stored login token is not isolated per instance." preferredStyle:UIAlertControllerStyleAlert];
        [saved addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [presenter presentViewController:saved animated:YES completion:nil];
    }]];
    [presenter presentViewController:alert animated:YES completion:nil];
}

static void FXInstallInstanceGesture(void) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ FXInstallInstanceGesture(); }); return; }
    for (UIWindow *window in UIApplication.sharedApplication.windows) {
        if (objc_getAssociatedObject(window, &kFXInstanceGestureKey)) continue;
        FXInstanceGestureTarget *target = [FXInstanceGestureTarget new];
        UILongPressGestureRecognizer *gesture = [[UILongPressGestureRecognizer alloc] initWithTarget:target action:@selector(fx_threeFingerHold:)];
        gesture.numberOfTouchesRequired = 3;
        gesture.minimumPressDuration = 0.85;
        gesture.cancelsTouchesInView = NO;
        gesture.delaysTouchesBegan = NO;
        gesture.delaysTouchesEnded = NO;
        [window addGestureRecognizer:gesture];
        objc_setAssociatedObject(window, &kFXInstanceGestureKey, target, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        FXFileLog(@"three-finger hold instance menu installed");
    }
}

#pragma mark - Bundled default avatars (copied from Fluxer's fluxer_static/avatars)

static NSURL *FXDefaultAvatarURL(NSUInteger idx) {
    static NSArray *b64;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ b64 = @[
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACR0SURBVHgB7d1LjN3FvSfwAtsY02d4hIFu8rgJbmt21+3FaCS7vWHhhtVVDFkhcHYMBmXDYHKlq0kcz0MTQrLjIUYaCRtlNUA0q9iWZoXNIlnQ3swgdTsPuJlunsHTjbEN4f5/p33AgA39OH1O/as+H+mo245xBH3Ov771q19VXTV1x2ufJACgKlcnAKA6AgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACo0MYELTPSuTp1OhvS1m2bm69Xp9HRTd1Xp/v7za/HNn36Zy/9/ovm5y50vy4sfJwWF/7WfP1b9/cWFpuv8xea7z/q/v7szIcJoDQCAFkb33ZtM9Bfk8a3bu4O5uPbNn/loL4Svb9nNH393xchIALB7Oy5dGr6bPfXEQ4A2uqqqTte+yRBBmJmv33HdWli+5buQB+Df/xerqJaMDtzLp08sZBOz55XKQBaRQBgaGJwj0F+166RZuDf0v2+zSIQnHr1bDpxcqH5+oEKAZA1AYCBikF/1+5Ompq6PvsZ/lqdfHmhWx2IlzAA5EYAYN1dOuhHib9Gx397Jh07dqZbGQDIgQDAuonBPsr7U3fdUPRMfyVimeDIc++kU9MfdJsKAYZFAKCvYqCfuvOGtGtypNrZ/nJFVeDI4bcFAWAoBAD6Igb+u++5Ke1tXmb7KyMIAMMgALAmMcuPtf09d12fWBtBABgkAYBViYH//n3fUOZfB4IAMAgCACsSp+ftf+iWtHN3J7G+nn/unXTs6PuCALAuBACWxRr/cPR2DRw/eibBeuvdsxGv+L57N8bFuzIojwDA19o5OZIO/Pg2A/8QxYP4Zz/5S/foYeiHS0/i/Lqjt3uXYsX7b/rUWSddFkIA4Iqi3P/oY6PW+TOiP4C1is/znqnr02SzjLeWUN876VJ1qr0EAC4rSv33//Bms/4MWRZgNdarcdf7sb0EAD4nBvwDj41p8muBePAeeOR11QC+0qAqed6P7SMA8KlYB/zpoW92Hxi0R+wWiBkYfNEwKnnej+0hANAVD4oHH74l0U5mX1wqBvwY+ONzPQzRH/DE43MaBTMnANAd+If1oKC/zL6ICt5PD93W7eofptg1cOCRN4SAjAkAFYtZwsGm5K/LvyyqAfWKwf8Xv/p2Nst4QkDetHhXKh4QTz/7XYN/geJne/jXW7slYOqR2+AfogoRJ4eSJwGgQjk+KOi/+5oAcPjXtzc/542J8kXZP8fP9J67brDEmCkBoDIG/7qoBtQh+niGveb/VSKMCqL5EQAqYvCvVzyAl7Z4egiXZu/FOzpy1ulcnR59bCyRFwGgEgZ/du3uNO+B76Sdu0cSZYjPc1u270a/0fYdWxL5EAAqYPCnJ94DBw99y5JAIeJz3SZ779YLkBMBoHAGfy5Hg2D7Rdm/bZ/rqAK4XyQffhKFy7UzmOFbCoffSXvuvD7RLvGz23vPjaltohdg16R7RnIhABQs985ghq97UcyPxywJtMz9+25ubbB39kg+BIBC3TfEc8BpH0sC7RED/5672lu1mZjQCJgLAaBAOydHzOhYsd6SgF0CeYvZf5vF+0wfQB78FAoTH679D9+aYDXsEshbrKGXsJWuIwBkwU+hMDr+6QcHB+Vp52SniM/36Ng1ieETAAoSTX8Gf/qld3CQEJCPKTs26CMBoBCxlUvTH/0WgfKpZ79nq2AG4mehg55+EgAKEA8Ga7asl+457rYKDl1J++fn584nhk8AKECb9wTTHr2+AB3cw7FrspzdGfNzHyWGzye55aI02+Y9wbRL9AU8/ex39QUM2FL3fxnl/4WFvyXyIAC0mNI/w+C8gMHbWVD5//TMh4k8CAAtpvTPsDgvYLBKWv9fWFQByIUA0FJtPw6UMkRfwP6H2nEffVt1L9DZXU4AmJ05l8iDANBSbbsHnHJ9/wc3paee/Tt9AeukpPJ/OC0AZEMAaKFo/FP6Jydx66RDg9ZHaYf/zM/bAZALAaCFrLuSo96hQZoD+6fEw39mNQFmQwBomVhzNfsnV7FerTmwf9p+898XKf/nRQBokRj4nQVOG2gOXLsSG33n5i8k8iEAtIi1f9pEc+DalDb7D6dePZvIhwDQElFaNfunbXrNgePbNieWr9RtvrOzlgByIpq3RCn3gA/C/NyF7l7jOHJ0vik5LjZfFxY//tKfGx3d1D3Xfqz5GgErBivn3PffUnPgd9MzT76VXnrhvcTXK3H2H069+kEiHwJAS2iqurwY7E+cWEinm5lFlBfj12sxcjEIbJ/Ykiaal+tX++fBh2/pBq0jz72TuLI49KfE2b/BPz8CQAtY+/+8eJCcPLHYvBbWPOB/UVQL4u+P1/MXfy8eyFGBiUDg57A20Ry4c3Ik/ewnf3Ej3GVEAH2w0OZJ5f/8CAAtYO1/aWB+sSkfv9IM/IPeR3zy5YXuK0QYi5+HysDq9foCIgQ4Fvbz7i94m2+EdvJy1dQdr32SyFY8DA7/+vZUq97AH2vHixldIxo/l5jNCmdr83yzHGBJYEmEy0d/PJZKdfc/zGT1GUYFIHulNgN9nVwH/p5Yevjlz+e6A5ggsHrdg61GN6Ujh9+uekkgAuX+h29NpYolNYN/frQ8Z277ji2pNvGw2P/AH7uDa+4PjV4Q+Nl//Evf+xFqEQ1vNd8jEIN/XO5V8g6U6Wn7/3MkAGQs1plrajqLwf6JZjA98MgbrZsNRkPivnv/kJ5+8k0znVVYWuraWt1ulxj0f3rotuI/569Y/8+SAJCxqal6ysrR2Bez/uNHz6Q2+80Lf23+Pf6UjrX832NYYkng0cfGqqgGxOAfM/9oiizZ0rkcLgDKkQCQsVrK/7HO/9ADfy5mDbi3LBDVDMsCK9dbEij5/V/L4B+U//MlAGSqlvJ/rPPHCXElimpGLGf0thCyfEvr4t8pckkg/t2efva7VQz+oe1VvZIJAJmqofxfwxawqADEfvfoDWDlYkkgtsGWsiQQwT5m/rX09sT73wmA+RIAMlV6+T9m/TXt/47egGgStCSwcqU0CO6956aqBv+g/J83ASBDW7dtLvohETP/Gi+FicH/oQf+5EKcVepVA9p2s2Bvm1/chVCbCL7ky0FAGZqYKPeY2dpPfosbCqP6MdeEgX0//NduH1yh3s2Cx397JvvDg+Jne3cz67+v0ou8dP/nTwDI0K7JkVSiWAt07OuSmBnF3ujaSsL9EjsF4pVjEOgN/FHyrzng+aznz10AGTr6v/9NKk3MBg488rob4L4grsf99w/f6ijhNYpwGWcvDLPjPLr6I7zXPvD37Lv3tM975lQAMlPqLXMxG/Aw+LJYEvjlxfMCajsFr5/icxOvOE8/tl2eOLkwkPPno3qza7LTHfjdEPmZCGM+7/kTADIzPt6uBqflGPbMrA2iN+L07LnuXfCWBFYvZt695YEQISCuHJ4+dTa92QxIa1mTjr97bOyatH1iS9rafE4ndmzxs7qC5597O5E/ASAzJa7/exgsT8xcY7DSF9A/vcrA3h/c1P11VATm5s5f/PpRmp//bFtmfN8Z2fBp+b4zcnXz/YZm0N/Y/Xn4mSxP3Ith9t8OAkBmSjsdTClwZXpbBf/DY2Np1+5Oor9icO99xrYn1sNLtv61hk6VjMT+/9Kah8z+Vy76AuL0QF3UtE0suTj5rz0EgIyMjZZVYjT7X5voC3CEMG1y5PC7ifYQADKytWUnnH0ds/+1i/MClrZPOkKYvEXgN/tvFwEgIxMT5Zz/Hw8Cs//+OPXq2e6tgkIAORP420cAyEhJXcbHbPvrq6WDlN5Ipx2tSoYs97WTAJCJOBGulAAQTWz2/fdfLwTE8beQi3hfmv23kwCQia0Fbf+LfcCsjwhXTzw+Z4cA2XDKZ3sJAJmIQ0dK8crLAsB6q/1WRfIQs3/VvvYSADJR0g6A6WmdwIMQISCqAet93j1cSexQob0EgEyUcgfAIC5g4TPRD2CbIMPwvNJ/6wkAmegUcgLg9PTZxGDF/QG2CTJI8V6zBNV+AkAmRseuSSU4JQAMRe8OgZP6LxgApf8yCACZGB1r/71MMQg5CWx43CHAICj9l0MAoG+U//PgDgHWy+zMhwJmQQQA+sZ2oHzEHQKxJKAvgH6J91JUmCiHAJCJtpfUlP/zozmQfoqqktJ/WQSATCwutPuDpSyYp15zoLsZWItYVnrlxGKiLAJAJmZmz6e2ikHG8b/5iubAX/7c8cGszksvvOe9UygBIBNtLp/H2r/Df/IXs7hYw7UkwHLZ7182ASATr7R0Bh0PiGNH30+0Q5wToC+A5Vi6ffJ14b5gAkAmokzbxiqAm8DaJx7s++79Q7e0C5fTG/x9tssmAGSkbY1abgJrt2eefMt5AXzJ4sUDpQz+5RMAMhLLAG0qtzkOtP3ivICoBlgSIMTzJz7XsYWU8gkAGYllgMPPvZ3awHGg5bBVkGDwr48AkJmYkeXeCxADhc7gsvS2CsaSgKav+hj86yQAZOiJx+ezfQjHbPEZ68bFigC63xHCVTH410sAyFA8fJ9+Kr9B1ragOvR2CajylC9+1vsf+KPBv1Ibxm//0cFEdk5f/EBO7Lgu5cC2oPqcmj7bvD5IExPXpU5nQ6IscbPfP/3jP/tMV0wAyNipi9frDjsEGPzrFT/zkycW00gTAMa3bU6UIbbv/tf//P/Se+9+nKiXAJC5YYeAOOM/ZgkeFPWKJZ/YohpBMEKAakC7xfkP/+O/v50unP8kUberpu54zbugBbbv2JIefWwsjY5tSoMQD/1YA3ZaHJeK9999P7w5Td15faJdIsBFg7Fru+lRAWiJQZZi4wHxT//4Rvr97zwo+DzVgHaKz3TcAfHGn9t76yj9pwLQQus1C4uHxJHD75ohsCzxPtx7z43N66ZEnlTy+CoCQIv1gsDExJZVLw3EA+LEywvp+LEzBn5WJd57v/jVtwe2PMXyxOf5icfnNO9yRQJAIbbvuC6Nj29O25swMDa2MW3ddu1l/1wM+LH9Z2b2XFPKXex+b18//bCnqUjd3wRSQWC4uueIPPlm9/MNX0UAKNhI5+rPrdE63Y31pklweCLIv9iU+qPcL9SzHAIA0HcRBB58+Ja0a7KTWH9xP8fzz72t3M+KCADAuokAEEHAssD6MPCzFgIAsO70B/RPlPePHn0//aYp9Rv4WQsBABiYCALRH7A9kzsu2sQaP/0mAAADFwGgFwb4arGdLw4BO9bM+g389JMAAAxNLAn0goDlgc/0yvyxlc/5HKwXAQDIQq8qMDnZ6W5hrY1DuRg0AQDIzq7dnbSzCQJrOeWyDS4d9B3KxaAJAEDWojKwc3IkbYuTLgtoHozZ/fT02e5V32b6DJMAALRGLA1MNCHg75vKQASC8W3XZr1c0Dt6uzfgm+WTEwEAaLUIAaNjG7uhYGx001fehbFeYlBfWPg4Tb96Ns3PX+i+TsX3jt8mYwIAUKToHVh6bUyjTTDo3o0xsqEbEEKn+fXIJXdlxL0Z8Wd6g/mlYiBf6P5+81r8OL0591H36+mZ890/a6CnjTYmgALFoGxghiurb68NACAAAECNBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACo0MYELTQ6til1OhvS1m3XpM7IhjQ6ujGNNL/udK7uvuJ/v1T82ZHm9xcX/pYWFj7+9Pfj+/i9MDf3UZqfv9D99dzFr7MzH376vwOURAAgazGQb9+xpRngN3VfE833vcF8NeKfu/SfHU2fBYXtV/hnekFgduZcExA+SrOz5wQDoPWumrrjtU8SZCAG5vFt16aJiS1pe/OK71c70A9ChIDTM+fTiZMLzdcP03xTQQBoCwGAodq+47pPB/z4vs0iEJx69Ww6eXKx+fpBAsiZAMBA9Wb5e6auT5O7O1nP8NcilgdOvrzQrQ680nwFyI0AwEDE7L70Qf9K5ucudCsDL734126VACAHAgDrJgb9XbtG0tRdN1Q36F9JhIEjz72TTp5Y0EQIDJUAQF/FQL9rspOm7ry+9Wv666lXFThy+G3Ng8BQCAD0RQz8d99zU9rbvMz2V+b4b88IAsDACQCsSezT33v3jcr8fSAIAIMkALAqMfDfv+/mtOeu6xP9JQgAgyAAsCIxy7//hzd3S/2sn+gROH70TLdhEGA9CAAsizX+4ejtGogwAIPwxXs04j1ImQQAvlZ08z/62OiXHgwMzumZc+ngT/7ZsgB91TuJc+v45jS+bfMVP+OX3ofhpMtyCABcUcz0Dzw2lnbu7iTy8Jv/+V568cX3BAFWrR/nc/ROujx27Iww0GICAJe1c3IkHfjxbcr9GbIswGrEwH//vm/0/XwO78f2EgD4HE1+7REzsGeeelM1gK8Un+n9D9267jt2vB/bRwDgU7H+94tffdtaf8s838y+7BbgcoZRyXvmybfSSy+8l8ifAEDXnjuvT/sfvlXJv6WiDHvgkdfNvvjUgw/fMrRKXvSqPP3UW4m8CQCk+5qSf5T9aT/VACLEHzz0zaHfxRG7Bg488oZLrzImAFSsuzbYzPpj9k85VAPqFZ/pWMYb33ZtykHsEIgQQJ42jN/+o4OJ6sQ6/3/5b99K//bfjSTK0uls6JZ+r2q+PzV9NlGH3Ab/EM+ZfzVydfr972wVzJEF3wr1mv1yelDQf7G089Szf9f8vDcmyhdl/xw/09//wU12FWVKAKiMTv+6xIDw1LPfs8xTuGj4G/aa/1eJMCqI5scSQEUM/nW65pqr0q7dnTQ2uinNzn6oKaswMbvOvYk33oOdkQ3p5ImFRD5UACph8CcOgvnFr77TPfOdMnSv5W7JDp54/23fsSWRDwGgAgZ/euI98NSz37XtsxBxSVebzu7YNelekZwIAIXrdQYb/LlUrMkuvS+sy7ZV9HXkvO5/OXvuvMFhYxnxkyicwZ8ricEjlgR27rYVtG3aVPq/VKcZ/FUB8iEAFCw6g23146vEQHLw0LcsCbRMzP7bGuzbVrUomQBQqPvc6McKWBJoj7bO/nsmJjQC5kIAKFD33m8zOlaotyRgl0De9t59Y2qzCDD6APLgp1CY+HBFZzCshl0C+YszHdquIwBkwU+hMD89dJumP9YslgT2P3SLmVpm2rz2f6nRsWsSw+fTXZB4aGv6o1/iDPenm2qAvoB8TDnSmT4SAAph3Z/1sHSIlK2COYifhQ56+kkAKIB1f9aTrYJ52F5Q97z7KPIgABTg/n03W/dn3ekLGK6Syv9zc+cTw+eT3HLRFBSXbMAg6AsYjuiaL6X8v9DM/lUA8iAAtFjMxJRlGbReX4DzAgZn+0Q5a/+nZz5M5EEAaLEY/JX+GYbeeQFOmxyMks7PX1g0+8+FANBS8QD28GXY4r4JVaj1V8LhPz2zM+cSeRAAWurgodsS5CCaA3966JuaA9dJ9PmU9N/2tACQDZ/YFooHwlYH/pCRmKFqDlwfpR3+Mz//USIPAkALKbmSI82B/Vfi4T+zmgCzIQC0TClngVMmzYH9FWd8lET5Py8CQIu0/R5w6qE5cO3i817aGR9z8xcS+RAAWiSOAjX7py2iOfAXv/q2voBVKm32H069ejaRDwGgRcyoaJtYv46+ACFgZUqc/YfZWUsAOfGpbAlr/8s3P3chLS58nGZmzqeFxY8/PXY0vsavR0c/++8Y3481g1MctWpnxfpY6gv4XnrmyTfT8aNnEl+vxNl/OPXqB4l8CAAtYfZ/eTGon3h5IZ1uZhYxu4gO47WcMz7ehICYrf59s9yybXyz61f7JALWoz8ea8LWpnTkuXcSV1bq7N/gnx8BoAXiGFCz/8/EIH/yxGI6NX227w+V+LtnZ1I62YSKEAewxH//7qug09iGJfoCtjbB6pmn3mwqNfaDX070TZRI+T8/AkAL7L3nxlS7mNUfPfp+eiUG/gHOJOL/N8rW8eqFAXcwrE0EqTgr4MAjrwsBX3Bfwe8tDYD5uWrqjtc+SWQrHgaHf317qlUMwC++8F56qXnldIVoLA3svftGVYE1eubJt7o/W1LaOTmSDv6nb6VS3f0PM64BzowKQOZqnv3HWnFuA39PVCHiFQHt0cdG9QqsUpwXMDa6MR0+/E7Vg0O8j/Y/fGsqVXxWDP75sQ0wcyVdA7pc8bDYd+/p9Pxz+Q8KsePgwCNvpCd+Ptf9npX7/g9uqvoegVhaWjovodxlJev/eRIAMhazyprWmmOwj5JwDKhtWxuOHoF99/5Bh/sq9bYK1niEcOmDf4imXfIjAGRsaqq8rUBXErPn/Q/8sfXrwVG1iCBgy9PKxVbBWBJ49LGxaq4Wjq2R44WfPxGfbZ+HPAkAGdu+Y0uqQcye9z/wp2I6wnvLAk8/+aZ1z1WIPfClLwlEwDl46JvdA75KNz2t+z9XAkCmain/x4w51s9LHCh/88JfLwYbvQErtbT7ZWuRB2AtXZv87bSzkh0kTn/MlwCQqRrK/zH4l75mHoO/3oDVi33xsQ22lGpAnH8Qg3/pZf8e5f+8CQCZKr38X8Pgf6leb4BqwMqVUg2IBseli5HqaexV/s+bAJChrc0soeSHRG2Df0+vN+CYkuiqtLUa0Cv5R4NjLc2NPcr/eXMQUIYmJso9VKbWwb8nQsAvL54Z4IKnletVA47/9kw6cvjtrBtHY7C/u5n1x8y/toE/KP/nTwDI0K7JkVSiuGjHWviSCEIxO6phD/h6iJ0C8coxCNQ+8Pf4rOfPXQAZevF/bSvuwbFU/nb5yxc5Srg/IggcO3ZmqDNOA//nxWmePu95UwHITAwEJT48YjbgYfBlvb6AWN+2JLB6vYrAUtn57MDCQHxWp+68oVu1E+I+E30uPu/5EwAyMz6+OZXm2MXrdLmy57sB6UL3Qhizx9WLisqeuzZ1w0CcLTEdlzZNn+2eRR9LUGs9byL+/tihM75189LXSrbzrdTzz72dyJ8AkJntE+Vt//MwWJ4ISTFY6QvojwhScV3zpVc2RwCIILAQXy9eUDM//+WtmZ2RDd1/fnR0U/eI4ti/3+lsEM6WISovZv/tIABkZqKwMqJS4Mr0lgQOHrotbTW77LsYwHul+l2VnMQ3aEcOv5toB3E2IzHrK22GYfa/cksXI/259RcjUZ+Y/dv61x4CQEZKW/83+1+buBrZViraxOy/XQSAjMQJgCUx+1+7aA782U/+4lZBsmf23z4CQEYmCmoA1AjUPydfXnCrINl74vG5RLsIABnpFLT+77z7/uo1BwoB5MhyXzsJAJmIwb+Uru/YYmXff//F4P9QUwlQZiUnsTxlua+dBIBMlLTl6+SJhcT6iHAVlQA7BMhFvBfN/ttJAMhEZ6ScH4UZ6vqzQ4AcRFXK+7C9BIBMlLQDQAVgMGKHwNNPvplgWOKCL9pLAMhEKWcAxOzflrXB+c0Lf+32BWgOZNCU/ttPAMhEKTsAeuerMzizM+fsEGCglP7LIABkYnTsmlSCkycWE4PX2yZ4eubDBOvticfnVfoKIABkYnSs/fcyRYe6BsDhcYcAgxC9Jz7nZRAA6BvNf3mwQ4D1ovRfFgGAvnH4Tz7cIUC/LS0z6foviQCQibZ308bDQVkwL+4QoJ9i5q/rvywCQCYWF9r9wVIWzFOvOTDCAKxWVJRU+MojAGRiZvZ8aqvu7H/a7D9X8fOJ5QAhjdWI3h7vnTIJAJk4PdPe/fPH3QTWCjGLe+Lnc/oCWLYIj/GeoUwCQCba2kEfD4hjR99PtEOENX0BLEev6U9gLJcAkIm2NtFpDGqf3rXCx6zpcgWL3VsnX/fZLpwAkJG2naIXA4nGoHaKQ5t+2ZR2re3yRQb/eggAGTnelNLbVG6zJ7j9oi/AZUJcKm6YnG1xTxLLJwBkJGZlh597O7XB80r/xehdJmRJgGj4U9WrhwCQmbjeNfcLXWwLKk9UACwJ1Csqjwb/+ggAGYqbtnJlW1DZorKz794/WBKoSG/N3+BfHwEgQ1GSjXW43NgWVIfeLgG3Cpav95m25l+nDeO3/+hgIjv/9/8sLQNM7Lgu5aD3oLDuX4fz5z9Jv//dB92f+/i2zanT2ZAoS+8z/fqfVXtqJQBk7NT02e7XYYcAg3+9Ts+e625PHWkCQAQByhBnjkTj53vvfpyolwCQuWGHAA8KYsnnlRMLqgGF6B4J/fh8utBUeajbVVN3vOZd0AK7dnfSgw/dkkbHNqVBeebJt6wD8znx/rvvhzenqTuvT7RLBLmDP/mLa7v5lADQIoN6+MYD4pmn3tIYxBXtad6D9zfvxUEGUlYvPtNPPD5nGY/PEQBaaHuzHHD/vm90v/ZTlHiPuPebZVINyF/M+uMzrZLH5QgALRYBIGZik5OdNNJZ/Y7OmB0cOfyu0iCrsqt5/z348C2qAZkx6+frCACFiDCwc3IkbRvfnMa3XXvFQBAzgvm58+nV6bNLHd4vL9jXT19ENSCWBRgus36WSwAoVASA6Nbuzcp6J7s54Y31ZFlguGLQj8FfqGc5BACg77Zu25wOHvqmZYEBUe5nNQQAYN3YLbC+9O+wFgIAsO4Egf4y8NMPAgAwMILA6sW6/ovNGv/xo+8r9dMXAgAwcHGy5d67b+z7WRYlmp35sBn0/3861gz8mvvoJwEAGJreroGJiS2qApeIgf5oM+C/cmJRmZ91IwAAWYiqwJ6p67tfaxWD/bFjZ5zPwUAIAEBW4gyLOF2w+yo8DMQgHyV+gz7DIAAAWesdeb1t/Jq0ddu1qe1ONwN+nMQZ5f0Y/A36DIsAALRG9AmMb9ucdjbVgTYEAkdvkzMBAGi1qBCMj29Ot45t/Nq7MNZTHLMdV2jPzV/oDvanZ853Z/iQKwEAKE4EgLGxa5qKwcY0Orqp++v4Otb8OnSaX490NnS//6rdB5fenRHfLzSz93jNN4N8vJbW8M81v/exmT2tIwAAQIUGXycDAIZOAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAV+hege0mi9Xr1cAAAAABJRU5ErkJggg==",
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACJvSURBVHgB7d3Ljp3FuTfwavfBbofY2TIDI22HQyQYxBJmkAwysZEy+SYf5gowV4C5AvAVAFdguALsyR5FihnsDMLARiIDkD5iIBIeYH3G2XTbfdzree3XMcSn7l6Heuv5/aRWdwObHbzWeutfT1U9NXfjYtkuAEAq+woAkI4AAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkNBCgYGZW/xVKaOv+UMnup/3HXxu9PVsmVv41b3fe/f//HNbK1e779vrN+59ba1eHX3/oft7d34e/bUfrhSA1ggAVG3f4RPdQD9/+OWyb/m50fcTjxzUd/Tv3sG/Z3MUAiIUbN78rGxcv9SFgggHAEM1d+Ni2S5QgZi9zx85VRaePnl30L8zw69VFwhGQWD92sVRMLiiUgAMigDAzHTl+tEgv3j0tbIwGvhjwB+yCAQb31+6EwhGVQIVAqBmAgBTFYP+wtHTZenYG9XP8Pdq/bsLXRjYuHZBGACqIwAwcfcP+gtPnyoZrX3zYVn7x0dlc1QhAKiBAMDEzI8G+yjvLx070/RMfydimeDWF+e6JYL+FALALAgAjFUM9IujAb9b1086239SURW4/eU5QQCYCQGAsYiBf+mFt8r+F86a7e+QIADMggDAnkSZf+k/3yhLvz5T2BtBAJgmAYBdiYH/wIvvKPNPgCAATIMAwI5E97wDv32vLD5zujBZt754t6x/+5EgAEyEAMATscY/G/2pgfVvPywwaf09G3N3v7rwefeeDNojAPBYi0dPl+VXzhv4ZygexCufvt61HoZxuL8T5+Nab0cAiPdetLze+P4TnS4bIQDwUFHuXz5x3jp/RewPYK+6jbvH3uiC/V5Cfd/pUnVquAQAHijK/Qdeetesv0KWBdiNSW3c9X4cLgGAn4gBP2b9NvnVLx68P/7lVdUAHmlalTzvx+HZV+CuWAN86uRlg/9AxIP9l3/8e9n/0jsFHiQqefGZnsYynvfj8KgA0IkHxfLx9wvDZPbF/aKSFwNxnNqZhdgfsHr5zbK9YaNgzQQAyoHj783sQcF4Re+A26P1WPKKmfjB333cVfRmKU4N/PjfrwoBFRMAEotZQjwo7PJvi2pAXjH4/+IPf+6+10AIqJs9AEnFA2Jaa4NMl7XYnGob/ENUIaLCSJ0EgIRqfFAwfnGMM4KA1zmHqObV+FrHRWFLlhirJAAkY/DPRTUgh5hlz3rN/1EOjN5/njn1EQASMfjnFdWAWmeI7E1/R0fN+v4i1EUASMLgT/R3iPdAtIClDV2Tn4Ec3439RvYc1UUASMDgT687Ivb7jy0JNCI+10Oy9PxbhXoIAI0z+PMgNggOX5T+h/b6RQVgbsH9IrUQABpn3ZeH6cPh4rEzhWGJ126IzbtiL8CCVuPVEAAaVvvOYGavWxJ45bwlgYHZ/+Jwd9UvPH2yUAcBoFGz7APO8FgSGI54jeJs/VAtHDlVqIMA0KDY5R0PdNiJe0sCTglULWb/QxbvM/sA6iAANCY+XFpvsltOCdStW0Nv4SjdkgBQAwGgMXb8Mw4aB9UpqjMtvCbz3ldVEAAaEjN/D2zGpW8c5D1Vj8VjbxQYFwGgEUvHztj0x9j1t0Y6Kjh78VropMc4CQAN6M4EW7NlQmLd2VHB2VtoaHPm5srVwuwJAA0Y8plghqPfF2AH92wsHn2ttGJbAKiCADBwUfof8plghiX2BTx16rLAOWXN7P4f2V6/UaiDADBgSv/Mgn4B09fSn/XmD1cKdRAABkzpn1nRL2C6Floq/2/8UKiDADBQQ28HShtiX8CB32o8NUlR/l9s6AIdFYB6CAADNbR7wGnX/t+c7Y4KqkZNRmtLLVsCQDUEgAGKjX8ettQkbp3UNGgyWmv+s7V6tVAHAWCArLtSo3tNg2wOHJsWm/9YAqiHADAwMfibZVGrrmmQzYFjM/Sb/37O4F8XAWBAuo1/WrIyADYH7l2LG323Vr8u1EMAGJBYCzT7ZyhsDtyb1mb/YeP7S4V6CAADEaVVs3+Gpt8cOH/oROHJtXrMd+umJYCaLBQGoZV7wKdha+Vq2Rw9aKLl6NbK13dajz6g/ejc6M8zgtW+g892/e1jsIrfGa9uc+Cpy2X187fL2lfvFx6vxdl/UAGoiwAwEDZVPVgM9uvXLnZnizeuX+p+34sIABEE5o+cKgtHTrp+dYyWj783+vM9XG5/ca7wcAvPnG5y9m/wr48AMADO/f9UPEhi0N+4dmHPA/7PRbUg/v3xdfvuX4subHEVawQCr8PexObAqGatfPr62F+7FkQAXW508+Tmzc8KdREABqC1RiC7EQPz2lcfjAb+C1M/SrT+3YXuK0QYi9dDZWD3+n0BK399vVuq4V9aPuYbgZ26zN24WLYL1YqHwS//+PeSVT/w3x6tHdd0jeidmxjfHQUC4Wwvbn3xriWBuyJcLr9yvrTq5n/9R9necBVwTZwCqFyrm4EeJwb7GBj++afnu0GitjvEo3y9evlM979v7duPCrsTSwLLJ86nX1qJ//4Dx9vtmxBLagb/+ggAlctYao6Hxf988kqVA//P9UEgytnWtHcnNrxlvkcg/rvjv7/lEygb1z8p1EcAqNj8aPDP9FCMwX718pvlx7+8OrjBNPYmdNWKz9+uPrTUqF/qynbapWud/LuPm/+cW/+vkwBQsaX/zLO+HBv7Yta/9u2HZchir8Kd/w7LAruRaUkgBv+uSdLhtpskdX053AFQJQGgYlnK/7HJLwbNVkro/bJAVDMsC+xcvyTQ8vs/y+Afoj8HdRIAKpWl/B8b/VY/P1taFNWMWM5YV/7csX5dvMUlgf7a5AyDf1hXDauWAFCpDOX/GPxjo1/LogIQGwRjbwA7F0sCsTeglTAcwT7Thsd4/+sAWC8BoFKtl/9jQGx98L9f7A2ITYKWBHaulQ2CSy+8VZ5KdtpB+b9uAkCFojTY8kMiZv63E14KE4N/7HW4/dUHhZ3rqwFDK533yxnLx/O959e816smAFQoLqJpVYay/6PEEcFbn591XHCX+vXzIZwUiI1+UbWI0JKxn4fd//XTCrhCre6AjrXA2BTHHf3M0AVDu7f2zYfl9pfnqlpaiYE/yv37Xzib+nrplctvlvWBH+ttnQBQocP/t72XJB7QQ2zwM2kxQBwYlYbdKbA3ES6j98IsB5x9o6WJxaOvpR/4e/a81M9tgJWZb7RUeOuLumZptbjT/fBM2R792WTrgjdOUTGLr+3j7925vfHaxbJ5/dLEl1nmRtWbuN44Bn43RP5LHIH1ea+fCkBllkazh+XGLgWJh0E0xeHRYiCJC2EsCYxPVAbiyuGN7z8pW6tXy9Ye1qRjVh8D/sKRU2X+8Mvdd6/Vg5n9D4MAUJkW1/89DJ6cfQGTFRWBeC923yMQrHx97+/FX+8G+bvl+7nFw93P+5af614Pr8mTierLyl9PF+pnCaAyrXUHUwrcmf6oYNwLHxUBxisG9Cwd+GZlLeER36FyDLAi8WBqbfNQHPtjZ2J2Gt0D/dkxNLHkovPfcAgAFZkblRpbYva/N9EvQQthhiSOZDIcAkBFWitNmsHuXXRMdHySIYjAb/Y/LAJARRaOnCytiAeBQWs8+gZK/jypmcA/PAJARVraZbzmCtCx6hspaa1KjSz3DZMAUInuuFEjASA2sWkBOn59CFj/RriiHvG+NPsfJgGgEvsaWv9fv3ahMBndCYErZzxwqYYun8MlAFRibqGd438b310sTFacEBACmLUY+FX7hksAqERLJwDsBJ6OCAHRYtm1wsyK2z2HTQCoxPyhl0sLYvDf3jAgTUtsvnJCgFm4rfQ/eAJAJVrpALhx/ZPCdMXJACGAaYr3WlSgGDYBoBKtnACIK1iZvv4OARswmQal/zYIAJVoIQDEIGT9f3bcIcA0KP23QwBgbDbM/qvgDgEmJZablP7bIQAwNuu6/1Uj7hCIJQEzNcYl3ksrn75eaIcAUImhP6iV/+tjcyDjFFUl76W2CACVGPpZ7lvWnavUbw50NwN7Eev+Npi2RwCoxObNz8pQdbP/7zwcahXhcvWy9sHsztpXH1j3b5QAUInNAZfPY+1f85/6xUM8Tgko4/KknPdvmwBQiaGW1+IBsaYX+GDE+8y+AJ5Ef/ukVtPtEgAqER+yIW6icxPY8MTr9c8/PV9uj0q78CD94O+z3TYBoCJDO0bnJrBhu/X5Wf0C+DddQ6lPLRVlIABUJMqzQyq3aQc6fNEvIKoBHvaEeP7E5zqOkNI+AaAi8eEbyk5t7UDb4aggweCfjwBQmZiR1b4XIDb92Rnclv6oYCwJ2PSVj8E/p7kbF8t2oSpxMdBTJy9XeUVwP1s0SLQr3n+/+MOfm7mhkkcz+OelAlCh7uxthZuzHAvK4d4pAY2DmtcHeoN/TgJApaLMXtMD2LGgfGKZx2veLndFIABULB7ANYQAg39esR8lXnsbBNuy/s1HPtMIALWbdQiIo4mulc0tXvvYILh6+U3vgwbE8uLKlTOW8rAJcCgWnj5Vlk+cn9rGrP5IYpxKgF68//a/9G5ZOvZGYVi6IHflTdd2c48AMCDTevjGAyIeFGZ7PMzSsTOj9+I7TgoMRHymo7ufWT/3EwAGaFJBIB4St788Z4bAE4n34dILZ8v+F94q1Eklj0cRAAasDwILR07ueiYWD4hY5497CAz87Ia+AXVSyeNxBIBGxB6BfYdOjL6PwsDyc2X+8IkH/nMx4Mfxn82bn5WN0cAfPysLMg6WBerQ9xEZ6hXjTI8A0LDoJHh/N0EzASbNJsHZiSC/9tUHXblfqOdJCADA2EUQOHD8vbJ49HRh8vrGYUI+OyEAABMTASCCgGWByTDwsxcCADBx9geMT1fq//ajUbn/fQM/eyIAAFMTQWDx2BvdplV2xho/4yYAAFMXAWBxFAZsFny8OM63fu1iWR+V+w38jJMAAMxM10zoblXA8sC/9GX+OKqrPweTIgAAVeirAotHX/vJ8dUsNOVi2gQAoDqLz5wuC0dP76nL5RDcP+hrysW0CQBA1aIyEGFg/tDLTWwejNn95vVPysb1S2b6zJQAAAxGLA1ECJg/cqoLBNHyuublgnutt+8O+Gb51EQAAAYtQkAsE0Qo2Hfw2UfehTEpMajHVwzyWytfl+2Vq3d/vlqgVgIA0KQIBd3XKBDMjb7fuRvjcPd7+PldGf3v/WB+vxjItzdu3P17P9wZ2GN2f/POjN5AzxAtFIAGxaBsYIaH21cAgHQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQEAABISAAAgIQWCgzQ3MHnytzir8r8oRPd930Hn+2+zy386u7vz/30n1+889e31290X737f99avVq2Vr7uft9auVq2N0bff7jyk38eoBUCAFWLgX7hyKluQI9BPn7uB/Nd/ft28X8bAWBzFAQ2b17pAkL3XTAABm7uxsWyXaAC3cz98InRIH+yG+jnD5/Y9UA/DV0oGH2tX7tYtrpwcLUADIUAwEzNP33q3oC/MPp5yCIMbFy/1AWCze8vFYCaCQBMVT/LXzr2Rlk8errqGf5exPLA+ncXujCwce1CAaiNAMBUxEy/9UH/YWJpYGNUEbj99w+6vQMANRAAmJgY9BePvjYa+M+kG/QfJsLArS/OdVUBmwiBWRIAGKsY6GOWvzia7Q99TX+S7lUFvjxn8yAwEwIAYxED/9ILb5X9L5w129+htW8+FASAqRMA2JM4nx8DvzL/3gkCwDQJAOxKDPz7X3ynLP36TGG8BAFgGgQAdiRm+ftfeqcr9TM5MfivfTsKAl+cKwCTIADwRKzxz0Z/amB9FAZgGuZ+do/GtkpUswQAHiuO8x08cf7fLthheqLL4Mqnr1sWYKz6TpxxqVa03n7YZ/z++zB0umyHAMBDxUx/eTTwLz5zulCH2//v/bIWDYUEAXZpHP05+k6Xa//4SBgYMAGAB4qz/MuvnFfur5BlAXYjBv4DL74z9v4c3o/DJQDwEzb5DUfMwG797W3VAB4pPtMHfvvexE/seD8OjwDAPbH+94s//Nla/8Dc+uJdpwV4oFlU8lY/f7usffV+oX4CAJ1o3bt8/H0l/4GKWdePf3nV7It7Dhx/b2aVvNirEtUA6iYA0JX8D7z0bmH4VAOIEH/wdx/P/C6OODXw43+/WrY3XHpVKwEgsWmtDTJdqgF5xWc6lvHiSF8N4sKreC9Sp32FlPr1foN/e+K1/eUf/95VdsijtsE/RBUiJhnUSQBIqB/8a3pQMH6xrPPUycs2dSYRZf8aP9P7f3O2LDlVVCUBIBk7/XOJASFCwOKxM4V2xYa/Wa/5P8qBUTXKM6c+AkAiBv+cuk1hr5zvujp67dvT39FRs66/yIuWpGpjE2ASBn9CbAxc+evrXU93hi8+z1HhGcrx3dgQuKF1cDVUABIw+NPrBoxTl20QbERUdYbUu2PhqHtFaiIANK7fGWzw536xQdD7YtjiMp+a1/0fZOnYG2VuQbOxWggAjfOQ52Fi8Ij3x6JZ2eDEZ3qIVZyYkCy4XbQaAkDDYmewo348SgwkB3//sSWBgYnW3UMN9gtPnyzUQQBolBv92AlLAsMRr9GQW3cvHDlVqIMA0KDu3m+9/dmhfklg/pCqUc2Wnn+rDFkEGPsA6iAANKYr6Z44X2A3nBKo32ILa+hLAkANBIDGRDtQZVz2KipI0cPdTK0usfO/hc/3vGdUFQSAhsSszaY/xiV6uEc1QKCsR2z+g3ERABph3Z9J6JtIOSo4e/FaDO3cP3UTABpg3Z9JclSwDi3tnt9ev1GYPQGgAXHJhjItk2ZfwGy1VP7f+vFqYfYEgIGLTUFLvz5TYBrsC5iNroNeI+X/mP1vb6gA1EAAGLDuik1lWaas3xegX8D0zDdU/t/8wU2UtRAABiwGfzMxZqHvF7Ck2+RULB59rbRie+OHQh0EgIHqLgPx8GXGlo+/pwo1BU00/7lLBaAeAsBARcMfqEFsDoz3o82BkxH7fGK5rxVbAkA1BIABigeChj/UJGaoNgdORmvNf7ZWrxbqIAAMkJIrNbI5cPxabP5jCaAeAsDAtNILnDbZHDhe0eOjJQb/uggAA9Jt/DP7ZwBsDty7+Ly31uNja/XrQj0EgAGJVqBm/wxFbA6MJQHv2d1pbfYfNr6/VKiHADAgZlQMTaxfCwE71+LsP2zdtARQk4XCIFj7f3JbK1e7dqObo4fN9voP9y4e6b6Pvubu+3Pcd/DZsm/5ue6YlZMVk9HtCzh5uax+/nZZ//bDwuO1OPsPKgB1EQAGwuz/wWJQX792oWz+8Fk3u4hNRnu5aSxCQAxY0Xp1/tDLrl8dkwhYB185X26NAtftL84VHq7V2b/Bvz4CwAAsHD1t9n+fGOQ3rl0sG9cvjf2hEv/u+Fr/7kL3ewxci6M//4VnXuu+szexLyCOCd7629tdpYZ/F0smLdq8+VmhLgLAAOx/4a2SXczq1779aDTwX5jqTOLO/98Pu68+DLiDYW+iaVBUWn78y6tCwM+0/N7aVAGoztyNi2W7UK14GPzyj38vWXUD8FcflNtfvb+n0v64xdLA0iiYqQrsTewLWBu9tpTuvXTw9+22+L75X//hGuDKqABULnNDlVgrrm3g70UVIr4ioC2fOG+vwC5Fv4B9y3f2BWQeHOJ9dGD0Z9Gq+KwY/OvjGGDlWroG9EnFw+Kff3q+3Pri3SoH//tFCTtK2auX31TO3qX9vzmb+h6BWFpq/aik9f86CQAVm386V+OfGOxvjUrCQ1wbjj0CEVrscN+d/qhgxopXhj4JsXeH+ggAFVv6z7ZuAXuUGPD/55NXupL/kEXVIoKAI087FzPhWBKIJZUsVwvHf2vr/Sfis+3zUCcBoGJZ1pXXv/moG/xbKaH3ywJRzah9CaNGcQa+9SWBri/C7z5u8rz/z8VxXeokAFQqS/k/SuYrV840OVBGNaOlYDNN/emXFhtg9dcmx3HIDNa//ahQJwGgUhnK/zH4R8m8ZTH42xuwe9E4KIJAK2E4yv0x+GdpO638XzcBoFKtl/8zDP736/cGqAbsXCvVgOgbke1iJOX/ugkAFer70bcq2+Df6/cGrCmJ7spQqwF9yX/5+Pvd2n8myv91EwAqFBfRtCrr4N+LELB6+YwlgV3qqwGxe772IBCDfVQt4nhjxkZRyv/10wq4QjFbaPGBEZfsxKY47uhnhu4V2L21bz4st788V9XSSgz8Ue7f/8LZdDP++61cftP1z5UTACp06P/8/+YeHH352xr4T2klPB4RBNb+8dFML5wx8P+UPS/1EwAqE8f/nmrwOlCzgUeL9e0Wj7xNW192nlYY6G6IPHama9ktxP1LdMaM9tjUTQCoTLRCXW7sUhAPgyezNBpI4kIYs8fxiN4S3aVN1z8pmzevlK3REtRe+03MjSo2C0dOlfnDL9/9nuM4306Z/Q+DAFCZ6A7WWoMQD4MnZ1/AZEUA2LwbBPoLah703owQFl/7Dj7btSWOgb7/azxahK5Y7qN+AkBlWlv/N/vfuRj8IwiaXTJEMfjb/T8MjgFWJB78rc0wHHfbuX9djPRBgSHpllwM/oMhAFRk36G2Znwx+1f6371bn58VoBiUOJLJcAgAFWmt5Gvw2rtomrTy19fdKkj1zP6HRwCoyMKRk6UV8SAw+x+P9WsX3CpI9Vav2OszNAJARdra/KcH+DhppETNLPcNkwBQiRj8W1kCiHK1pj/j128OVGalJvF5t9w3TAJAJfY1tP4fJWsmIx62UQlwQoBarI3ei2b/wyQAVCKajbRi4/tPCpPlhAA1iIE/8+2eQycAVKKlEwAb36kATEM8eG99/naBWdHxb9gEgErMH3q5tCDWp7c3HFmblttfve+EADOh9D98AkAlWjkB0PdXZ3qit70TAkyT0n8bBIBKtHL5y4YNgDPRHxOMMACTFmf+NacaPgGgEi0EgP76VWbDHQJMQ2w+9TlvgwDA2Dj+VwcnBJgUpf+2CACMzbruf9VwhwDj1i8z0Q4BoBJD38AV//uVBeviDgHG6daoquS91BYBoBJDn6ndUnKuUj9rszzDXsSSkvbe7REAKjHk43MxyGxev1SoU7w+sRxgXwC7EeHRun+bBIBKDPn4Vqz9Kw3WLx7iq5cd3+LJxec63jO0SQCoxFDPz8cDYk1pcDDitbIvgCfRLx8JjO0SACox1E10NgYNT98vYM2pDR6iv3XSZ7ttAkBF1q9dLEMSDwcbg4YpHvCrl8/YF8C/MfjnIQBUJAbTIZXbnAkevtgXYEmA+8UNk1pK5yAAVCQG/6HMyG4r/Tejv0zIkgCx4c+enjwEgMrE9a61p2/HgtpzZ7e3JYGs7iwJGfyzmbtxsWwXqjJ/+ER56uTlUqN+A5mdwe2Ki6l+8Yc/N3NDJY/Wr/kr++ejAlCh+CDGOlxtHAvKwa2CebhGOjcBoFKxFFBTObZ/UFj3zyFCXtwqGGVhr3mbDP4IABWLdfYaQoDBP69YE7ZBsD3Rc8TpDwSAys06BHhQ0G8QVA1oQzxPLOURbAIciMWjp8uB4+9NdWNW7EOIpQjoxftv/0vvlqVjbxSGJQb8lU9fd2039wgAAzKth288IG79TTMQHm7p2JnRe/EdJwUGIj7Tq1dUcPgpAWCAFp4+Vfa/+E73fZzi4XDLvd88IdWA+vXNxVTyeBABYMAiACyOZmKLR18rc4u/KrsVs4PbX55TGmRXZrE8xeOZ9fM4AkAjIgwsjB7E84de7hoJPSwQxIygu3nw+idla1Tij65+NgMxDgdG1YBYFmC2zPp5UgJAoyIAxFc/K+tnAWYDTJJlgdla++qD7uSQUM+TEACAsYsq1MHffWxZYEqU+9kNfQCAsYsTJP/80/N6B0xYDPxxpl+jLnZDBQCYOMcGx8vGXcZBAACmRhDYvVjXjzX+aM9sts84CADA1C0+c7osPf/W2HtZtCiWU+IuhujPYXMf4yQAADPTnxpYOHJSVeA+3Wx/NOhvXLugzM/ECABAFaIqsHjsja6xUFYx2K/HbF9/DqZAAACqEv0rIgQsPPNa82EgBvko8Rv0mQUBAKha3/K673I5dDHgRyfOKO/HzwZ9ZkUAAAYj9glECLi/7XXNtN6mZgIAMGhRIdh36MSdcPCYuzAmKQb6zZtXRt+/7gb7+NmV2tRMAACa09+DEV9zy8/d/f3Zsm/0c//3+5DwqNMH95+3j5+3N27cndV/Xbbv/t6X8c3sGRoBAAASchcAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACQkAABAQgIAACT0v5FcR8JhLqjHAAAAAElFTkSuQmCC",
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACNlSURBVHgB7d1Nj57VmSfwQ9pG0JhJGcWOCB6wvQCJvNgkkWABskEjhV5kbEu9mNk05hMAu9lhPgHwCcArVi3bkw0REjECjUBKoJwENLZG2NA2dMppqhKbYGEm9HPd5oYisY2r6nk597l+P+lRlc1Lgut57vM/17nOOdeVl174vAAAqXyrAADpCAAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJCQAAkJAAAAAJrSswMHPr1o9e15ed/2Wu+7r1hpvKHaPX3PpLv7/1xpu+/Hvjr13JqQsfd1+XPvu0LF282H099cnH5U+fXez+Wnwfvzd/bqkAtEYAoGo7b54bvTaWHRvmuoE9vr/aoL4SX/17vvnfN39+sQsEx0Zh4OjiwigULI7CwcUCMFTXlZde+LxABWJmv/uWzWXX3OZuoI9X/F6tokoQQeDI2TPdV5UCYEgEAGYmBvcY5Pdsuq0b+Hdu2FiGLALB0Y8WypE/nu6+qhAANRMAmKoY9Pdu3lIeuXVb9TP8tTp89nRXHTi8cFoYAKojADBxywf93Rs3l4ye/+BkOfjhya5/AKAGAgATE4N9lPf3f2970zP9lYhlgqfe/X23RNDvQgCYBQGAsYqBPgb8bl0/6Wz/WkVVIMKAIADMggDAWMTA/9jtd5XHRy+z/ZURBIBZEABYk5jlx9r+/u9tK6yNIABMkwDAqsTA/+T2HyjzT4AgAEyDAMCKxOl5T9/547J3822FyTowCgEHR2FAEAAmQQDgmljjn41+10BUBWDS+ns2+ns1+vswnGPRJgGAbxSz/efuvs/AP0MRBPYde9Vxw4zN8pM4v+no7QgAl467XiyvLC046bIRAgBXFOX+575/r3X+iugPYK36xt04nGstob4/6VJ1argEAC4ryv0Htv/ArL9ClgVYjUk17no/DpcAwNfEgB/lfk1+9YsH74O/flk1gKuaViXP+3F4vlXgC3Eb31v3PWzwH4h4sJ+8/+fdrA4uJyp58ZmexjKe9+PwqADQiQfFM3feUxgmsy+Wi0rek9t/WB6//c4yC9Ef8Ojbb2gUrJwAQLevf1YPCsYrzg6I9Vjyipn4oZ33dxW9WZo/v9iFUiGgXgJAYjFLOLTjAV3+jVENyCsG/1/99KHuaw2EgLrpAUgqHhDTWhtkuqzF5lTb4B+iChEVRuokACRU44OC8YttnBEE/JxziLJ/jT/ruCjMEmOdBIBkDP65qAbkELPsWa/5X028/zxz6iMAJGLwzyuqAYd21DlDZG0u3dFR9ww77hWIswioiwCQhMGfvZu2dO8B5zy0Iz7PQ9m+G/1Geo7qIgAkYPCn120R+9EDlgQaEZ/rIXlML0BVBIDGGfy5HA2Cwxel/6H9/KIC4H6ReggAjau1M5jZ68NhdGkzLPGzG2JnffQCxC2E1EEAaFjtncHMXndRzN33WhIYmCF31e+a0wdQCwGgUfGAsPeWa2VJYDjiZzTkqs3uWwSAWggADYou7wNmdKxQvyRgl0Ddhl6tifeZPoA6CACNiQ+XozdZLbsE6hZr6C3MoOO/g9kTABqj459xcHBQnaI608LPZOuN3lc1EAAaEjN/D2zGpT84yHuqHo/cascG4yMANMKFG0zCpVsjf2arYAXiZ+EkPcZJAGhAPBis2TIp3TnutgrOXEv750998nFh9gSABrhpi2no+wJ0cM/Gnk3t7M44dUEAqIEAMHBRmlWeZVqiL+Ct+x4WOKes6/5vpPy/9NmnhToIAAOm9M8sOC9g+lr6s54/t1SogwAwYEr/zIrzAqZrz3faCQB/UgGohgAwUEM/DpQ2RF+Ag6cmq7ULdFQA6iEADNTQ7gGnXbH9NLYKqkZNRmtLLfPnBYBaCAADFDN/D1tqErdOOjRoMlo7/OfUJ+cLdRAABsi6KzXqDw3SHDg+LR7+YwmgHgLAwGj8o2axXq05cHxa+3NU/q+LADAgGv8YCs2Ba9fi5/095f+qCAAD8oi1fwZEc+DatFhFObq4UKiHADAQUVo1+2do+ubAnTfPFa5dq9U+6/91WVcYhFbuAZ+GOGd8/s9L3ZGj742+X/rs4mWPH40/zzjX/o4bNpS59etHg9RG59xPQNcceO/D5YkTb5Zn3j9R+Gat9lCoANRFABgITVWXF4P9kYXTXXPR0Y8W1nzJSASACALReb1r9HL96vhET8C3R5Wsp979feHK4r6FFmf/Bv/6CAADYN//18WD5MjZM+XwaOAf961iUS2If//yh1U8kPduuq3sumWzn8MaRXNgVLP2zb/mRrjLiAD69F33lBYdO7dYqIsAMACtHQSyGjEwP/v+8XL47OmpryPG/2a8QoSx+HmoDKxe3xew79ir1oT/xpPbf9hsyDw8Cu3U5bry0gufF6oVD4OT9/+8ZNUP/M+MXvF9LeLnErPZRzRmrsmB0XKAJYFLIlw+d/e9pVUbj/5rVZ9h7AKoXta1/3hQxMCw7bX/3Q0StT04ony9/503Rv//flEOfnCysDoRomLQy760Ev/9LZ+bEEtqBv/6CACV231LvlJzPCzuef3FKgf+v9UHgX3HrGmvVsx8M98jEP/d8d/f8g6UVzQAVkkAqFisM2d6KMZg/+jbb5QHf/Py4AbT6BGIakBsdTPTWbl+qStbxSsG/UM772/+c9730FAXAaBimZr/5s8vdrP+5z8cdjk99rnHf4dlgdXJtCQQg393SNKGjaVl3bkcmj2rJABULEv5P5r87nn9l82U0PtlgUdHL8sCK9cvCbS80yLL4B/ifA7qJABUKkv5Pxr9Hj/xVmnR86MqwIO/frkcXrD9aaW6dfGfPNTkksCla5MfTjH4h4MDr+q1TACoVIbyfwz+BxrfAhYVgH2/fbXrDWDlYkkgegNaCcMR7DM1PMb73wmA9RIAKtV6+T8GxNYH/+WiNyCaBC0JrFwrDYKP3X5XV9XI1Nir/F83AaBCOzfMNf2QiJl/xkthYvCPXodnXYizKn01YGg3C/bLGc/c2eYRv1fz7L8dL9RLAKjQ7lu+W1qVoex/NXEr4eOj6oftgqvT3yw4hJ0C0ej35BehJePR0br/6+co4ArFbKHFB0asBcYefy7pD4BxwdDqRaNlhMqallZi4I9y/+OjV+brpWMXzPO2w1ZNAKjQ5//tf5TWxAM6OuKtgX/d3Lrru9KwOwXWJsJldJvPcsCJrv49m29LP/D39LzUz22AlWm1VFjbLK0WsSSw/4vzArLe+zAO8bmJV5ynH9dEH/nj6a4BbdLLLFG92bt5S9mz6TY3RC4TQcznvX4CQGV23tze3uB4GCgFXl30RcR6adwFb0lg9WLmHQcJ7f+iohKVgflzi+WVpYVy6pO1rUnHv3vrjTeNBvrvlh0b5rqdOn5Wl+eGx2GwBFCZFtf/lQKvnb6AyYqKwKkL58vSxYtdIHhv2fsy3qOxJNOX7789+hq/jkG/e/mZXJMjZ0+XvcdeK9RPBaAyrVUAlAJXpt8qGF3ue0fryYxXDO5fnsCX4yC+qcu4xXeobAOsSOz/b615SClw5aIvIE4P9GfH0MSSi5P/hkMAqMjWGzeUlpj9r030BThCmCERWodFAKjI0E44+yYeBmsX5dQ4O0GQonYR+M3+h0UAqMiuhpr/4kFg0BqP7gAlZyhQOYF/eASAikSncStcATpe/UFKjlalRpb7hkkAqES33aiRbUbRxGbf//h1IWC0HCBcUZN4X5r9D5MAUImW1v8PL5wpTEZ3cuDbb3jgUg2nfA6XAFCJqAC04sgfBYBJix0CQgCzFgO/at9wCQCVaKkCcPSjPxQmL0JA3LjmWmFmJfpSGC4BoBJxtngLomPdgDQ9MfuyQ4BZUPofPgGgEnPr21gCeMU+4KmbP78oBDBV8V47YAlq8ASASrSyBdBBILPR3yGgAZNpUPpvgwBQiRa2AMYgJADMjjsEmAal/3YIAIzN0Y8M/jVwhwCTEstNSv/tEAAYGwfU1CPuEIglATM1xiXeS/vmXyu0QwCoxNAf1Mr/9dEcyDhFVcl7qS0CQCWWLg5765x15zr1zYEHHdbCGsTnW4NpewSAShw7t1iGKgaZwwunC3Xqjg9+x/HBrM6z7x+37t8oAaASR5eGWz6P2aXDf+oXD/F9x15TxuWa2e/fNgGgEkMtrzkLfFgOnz2tL4Br0l9BLdy3SwCoRJRph9hEZ0/w8MTPa9trvxiVdk8UuJx+8PfZbpsAUJGhbaMz+x+2x0+86bwA/k7M+GO7n8G/fQJARWIZYEjlNseBDl+cFxDVAA97Qjx/4nMdW0hpnwBQkVgGeOrd35UhUPpvh62CBIN/PgJAZWJGVnsvQJT9dQa3pd8qGEsCmr7yMfjnJABU6NG336j2IRyzRevG7bp0hPCLqjuJGPzzEgAqVOsga1tQDv0uAQcHte/S8s+LBv+kBIBKRZm9pgewbUH5xDLPg7/xM2+VuyL4h/Iv/3ygUKXoBbhu9HX3xs1llgz+ecXP/MjCmbJx3fVl580bC22ILcf/83f/p/z7pxcKeQkAlZt1CIitif/01lEPisRiyefw2TPlvVEYiBAwNwoDDFcsL/6v//fbcuGvfy3kdl156YXPC9WLAPDc9+8tW2+4qUxDPPRjS+IzTotjmXj/Hdj+g/LI97YVhiWqOdFg7NpuegLAgEzr4RsPiHhQKPlzJftH78EnR+/FaQVS1iY+0/uOvaqBl68RAAZoUkEgHhLReGiGwLWI9+Hjt99VHrv9zkKdVPK4GgFgwPogsOuWzaueiXXruwunu6YgAz+rEe+9X/30IdWAyqjk8U0EgEZEj0A0aO2aG4WBG28afT932b8vBvz5c4vl2OgVjV3xvbIg42BZoA79OSJDvWKc6REAGja3bv3XOrbNBJg0TYKzE0H+2fePj8r9x4V6rokAAIxdBIGn77yn7N28pTB5/cFhQj4rIQAAE7N305by9F33WBaYEAM/ayEAABOnP2B8orx/8IN3u85+Az9rIQAAUxNB4JFbt838eOshssbPuAkAwNRFANg/CgKaBb9ZbOc7cvbMqNz/roGfsRIAgJmJJYGuKjB6WR74Sl/mj626zudgUgQAoAp9VWDP5i3dFtZsHMrFtAkAQHVi98DeTbet6ZTLIVg+6DuUi2kTAICqRWUgwsCOmzc20TwYs/tXRq+jX7xgVgQAYDBiaWD3xu+OXpu6QBDHX9e8XNAfvd0P+Gb51EQAAAZt54aN3f0XEQruuGHDVe/CmJQY1Jc++7Qc/WihvHfh425/fnxvnz41EwCAJkXvQISB7jX6PioF3153fffrEPdkzK3/qnrQ/Xr09/SD+XKnPvm4LF289Pt/Gr1OXfhL9/38n5e6rwZ6hmhdAWjQqS9m4mWxAJfxrQIApCMAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJCQAAEBCAgAAJLSuwABtveGmMrd+fdl588Yyt+76cscN/9h9jd+Lr1tvvOlrf3/319atL0ufXRy9Pv3y9+P7pYsXu+9PffJxee/Cx93fc+rC+e73588tdr8GaI0AQNVioN99y+bu6x1ffN8P5qsR/9zX/9llQWHj5f+ZCAARBOL13oW/fPm9YAAM2XXlpRc+L1CBGJhjRr9r4+aye/S6NLtf3UA/DfPnR0Hgz0vlyB9Pd19PjaoHAEMhADBTMdD3A368hiwCwdGPFsqRs2fK0cWFAlAzAYCp6mf5j9y6rezdvKXqGf5axPLA4YXTXXXg8MKZAlAbAYCpiNl964P+lcTSQFQGnv2342X+3FIBqIEAwMTEoL9n021l//e2pxv0ryTCwFPv/r6rDmgiBGZJAGCsYqCPWX7M9oe+pj9JfVUgwoDmQWAWBADGIgb+x26/qzw+epntr8zzH5wUBICpEwBYk9if/9jtdyrzj4EgAEyTAMCqxMD/5PYfjAb+bYXxEgSAaRAAWJGY5T+5/YejUv+dhcmJwb8PAgCTIABwTazxz0a/ayDCAExDVPeWU4lqlwDAN4pu/ue+f+/fPRiYnvnzS2Xf/KsexoxVfxLnzpvnugO6rvQZX34fhpMu2yEAcEUx03/u7vvK3s23FerwzPsnyrPvHxcEWLVxnM/Rn3R58MOTwsCACQBcVgz6Mfgr99fHsgCrEQN/NO6O+3wO78fhEgD4Gk1+w3H47OnyxPG3VAO4qvhMP33njye+Y8f7cXgEAL4U63+/+ulD1voH5sBo9mW3AJczi0reEyfe7JaqqJ8AQCeO7n3mrh8r+Q9UzLoe/PXLZl98KWb9s6rkRQCIIEDdBAC6dcEDoxfDpxpAhPhDOx6Y+V0c8+cXu1Dq0qt6CQCJdWuDo1n//lud5tcS1YC84jMdy3g7N2wsNYgdAg/+5uVCnb5VSKlf7zf4tyd+tifv/3lX2SGP2gb/EFWIWIqgTgJAQv3gX9ODgvGLZZ237vuZps4kouxf42c6+hDsKqqTAJCMTv9cYkCIEODSprbFLHvWa/5XE9Uoz5z6CACJGPxzmlt3fXnu7nu7l599ey7d0VH3DDveg5ak6iMAJGHwJ6oA3dLPzXOFNsTneSg7eOL9V3OVIiMBIAGDP714D7x178NmY42IS7qGdHbH3k3uFamJANC4vjPY4M9yMWv81U+8L4ZsiDPqR0b/nx02Vg8BoHEGf64kBo94f7jtcXjiMz3EKk70AuzdvKVQBwGgYdEZbKsfVxMDyaEfPWBJYGBiJj3UYL9rTh9ALQSARsUD3d5brpUlgeEYUuPf5ey+RQCohQDQoCjtOtufleqXBOwSqFts+xuyCDD6AOogADQmPlzRGQyrYZdA/Vro2YheAGZPAGjMoZ33K+OyZlFBih4SM7W67B/w2v9yW2/0jKqBANCQmLVp+mNcoofkrfseFigr8ojLuxgjAaAR1v2ZhP4QKVsFZy9+Fk7SY5wEgAZY92eSbBWsQ0vd80uffVqYPQGgAW7aYhr0BcxWS+X/U598XJg9AWDgoinIVa9Mi76A2Yiu+VbK/zH7X/rsYmH2BIABi5mYsizT1vcFOC9gelpa+58/t1SogwAwYE9u/6GZGDPRnxfgtMnp2NPQLXp/sv5fDQFgoOIB7OHLrEVPgCrU5LV0gY4KQD0EgIE6tOOBAjWI5sBDO+7XHDgh+xu7Qnf+vABQCwFggOKBYP2VmuzdtEVz4IS0dvjPqU/OF+ogAAyQkis10hw4fi0e/mMJoB4CwMC0chY4bdIcOF6thX3l/7oIAAMSD1ezf4ZAc+Daxee9tTM+3lP+r4oAMCBxFKjZP0MRzYG/+slD3rOr1GKAOrq4UKiHADAgZlQMTaxfR1+AELAyLc7+g/X/uqwrDIK1/2t36sLHZenixdHDZrE7dKQ/djS+xjGky/8c7xh9H3eTx1Grmtcmo+sLuO9n5YkTb5XnPzhZ+Gathn0VgLoIAANh9n95MagfXjhdjp1f6gb8eK3lnPGdGzZ2gWD3xk1lx80bXb86JhGwnrv73i5wPfXu7wtX1urs3+BfHwFgAGKPtdn/V+bPL5YjC2e6B8q4Hyrx747X4bOnu1/HASxxCtue72wZfW3nONZZib6AqLQ8cfytrlLD34slkxYdG4Vz6iIADMBjtlR1s/qDH7w7GpjPTHUmEf+7UbaOVx8GXL+8NhFod46qKw/++mUh4G+0/N46unS2UJfryksvfF6oVjwMTt7/85JVDMDPvn+8PDN61XSFaCwNPPZf71IVWKMnTrw5+tmeKJTuvXToR+0e8b3x6L+6BrgyKgCVe/z2u0pWsVZc28Df65cfIqA99/179QqsUpwXcMcNG0Y/69+lHhzifRR/Fq2Kz4rBvz62AVZuT8IZZjwstr32i3JgFABqf2hECfvB37xcHn3nDeXsVYpTAzPfIxBLS61vlbT+XycBoGIxq8z0UIzBPkrCMaAObTCNHoEILTrcV6ffKpjxCOEM5yRE7w71EQAq1totYFcTA/49r784+PXgqFpEELDlaeViq2CUwWO7YJarhWP5KLaetiw+2z4PdRIAKhZH/2Zw8MOT3eDfSgm9XxaIaoZ1z5WLPfCtLwlEwImGv/0JQv7Rjwz+tRIAKpWl/B8l8/1vv9HkQBnVjJaCzTT1u19aPACrvzY5yw6SCPjUSQCoVIbyfwz+BxpfM4/BX2/A6sXBQREEWgnDUe6Pwb/1sn9P+b9uAkClWi//Zxj8l+t7A1QDVq6VasBjt9+V7mIk5f+6CQAV2rlhrumHRLbBv9f1Bvz65XLQhTirMtRqQFfy/8lD5Zk770nT3NhT/q+bAFCh3bd8t7Qq6+DfixCw/503LAmsUl8NiJ0CtQeBGOyjahENjRkPilL+r5+jgCsUs4UWHxhxyc49r/+ycEnfDOZegdWL8xciTNW0tBIDf5T74xTPbDP+5eJwLNc/100FoEJxUUpr4gG9b/61wlf6JQGzpNWLLYN9RWDWobmf8Z+8/793yxWZB/9g/b9+7gKoTDzEWnxw1DZLq0V/ZkAMGC1ueZuWCALx6srOo4En1p6nEazis7r/e9vLnk23uQ9imZj5+7zXTwCoTIuz//46Xa7swBcBKU7Cyz5zXItYTunDQJwtcXTxD+WVxbNl/txi91rreRPx748dOjs2zHVfs2znWyk9LsMgAFRm19ym0hoPg2sTISlmr/oCxiOC1N5NW7pXLwLApSDwaTl2bqn7vcvNVONY4vjn7xj9HObWr++Cef97XF1UXsz+h0EAqExrOwCUAlem7ws4tOOB0aAzVxivGMD7Uv3yYMD4CPzDoQmwIjHra22G4WGwct3FSG+8WJ4d+MVI5BOzf02twyEAVKS19X+z/7V5/MSbAhSD4v06LAJARVor+XoYrF00B+479ppbBame2f/wCAAV2dXQNiKNQONz+OxptwpSvUfffqMwLAJARaLLuBXOAB+vvjlQCKBGlvuGSQCoRAz+rSwBxBYr+/7Hr2sOfP2XyqxUJZanLPcNkwBQiZbW/w8vnClMRoSrODnQDgFq8ez7x83+B0oAqERL5f9XlsxQJ80OAWoQA3/m2z2HTgCoRFsVgNOFyYsH7xOjIACzEn0pDJcAUIk4W7wFsT5ty9r0PDNaCoi+ACVYpk3pf/gEgErMrW9jCeDYucXCdM2fX7RDgKlS+m+DAFCJrTe2cfnL4bMaAGeh3yY4/8UFNzBJsedfpW/4BIBKtHD7W3So26I2O+4QYBqi+dTnvA0CAGNj+18d7BBgUpT+2yIAMDZO/6uHOwQYt36ZiXYIAJUYegNX/P9XFqyLOwQYp6gqeS+1RQCoxNLFYc/UlJzr1M/aLM+wFvH5drx3ewSASgx5+1w3+//I7L9W8fPZ99tXhTRWJcKjdf82CQCVmD8/3O1bB90ENgjxEH/0Hdu3uHbxuX70ndcLbRIAKjHU43PjAaE0OBzxs9IXwLXol48ExnYJAJUYahOdxqDh6a8VPii4cQUx6Dtdsn0CQEWODOwUPbP/4YpDm/aPlgP0BfC3DP55CAAVicF0SOU2e4KHL/oCXCbEck8cf7O7X4L2CQAViVnZU+/+rgyB0n87+suELAkQZ/w/70CvNASAysT1rrVf6GJbUHsizFkSyCsqjwb/fASACsUHsVa2BbUtgt22136hupNIv+Zv8M9HAKhQlGSfOPFmqY1tQTn0uwTcKti+L6+Rtuaf0j+Uf/nnA4XqvP6n/yjXjb7u3ri51KB/UJgZ5nDhr/+/vPgfH5b3Rj/vnTdvLHPrri+0pf9M/9+//LmQkwBQsTgXoIYQYPDPK/pRjiycKRtHASCCAG2IZ8uDv3m5/PunFwp5CQCVm3UI8KAglnwOnz2jGtCIp744EvrCX/9ayO268tILnxeqt3fTlvL0XfeUrTfcVKYl+hCesQ7MMvH+O7D9B+WR720rDEsEuX3HXnVtN19SARiIWKebVik2HhD7jr3WzfpgOdWAYYrP9D+99cqgLx1j/FQABiiWA54czcLGvSwQa/zu/eZaqQbULwJbHC6mksflCAADFgFg/63byp7NW0YzsfVltWJ2EAO/0iCrMYvlKb5ZfJ7jTBHNu1yJANCICAN7N91WdozKspdKs5cPBDEjOPXJx+WVxT905cC4hti+fsYhqgFRmWK2zPq5VgJAoyIAxPrs1hsvzcpi0O++mg0wQZYFZuvZ9493pzkK9VwLAQAYu50b5sqhnQ9YFpgS5X5WQwAAJmb/qBIQywKCwGTo32EtBABg4gSB8TLwMw4CADA1gsDqxbp+rPHHNl2lfsZBAACmLrYOPnb7ndVcdlWzuKnv4AenRgP/u5r7GCsBAJiZftfArls2qwosEwP9wdGAH6cuKvMzKQIAUIWoCjxy67ayd/NtJasY7A9+eNL5HEyFAABUJc6w2Lt5S9nznS3Nh4EY5OfPLRr0mQkBAKhaf+T1pVMu58rQzZ9b6k7ijPJ+DP4GfWZFAAAGI/oE4qjrr469rjsQOHqbmgkAwKBFhSBCwdYb/vEb78KYpNiaN//npfLehfPdYB/fRwc/1EoAAJoTAWDrDRu6uzDiFb++44abvrwbI+7JmFt/KSRcbffB8v32MZNfunhxNIP/dDTIf9z9tfj1pTL+p2b2DI4AAAAJfasAAOkIAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAkJAACQkAAAAAn9JwE7KIYji7r8AAAAAElFTkSuQmCC",
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACAySURBVHgB7d09rJ3VuSfwFy6FC2y5ukJ24w6PaCgAWbfyxFLiDks3kShgRFIluVJCRZBAgiJIYZohKQJVghQXFClMR6LBuBnJghTWaIqDNNK4GFsuUlhOCu4oksf/7PNeHxx/nI/9sdZ6fj9p6xw+E87Z+13/9axnrfXYM2/fvj0BAKU8PgEA5QgAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABQkAAFCQAAAABT0xQWeOHJqmJ++8/tNT03T4ztdjRxev/Pn88fGjd//eY0cf/O+5fnPx9dbX0/SX7de1m4uv+Wvz91s3JoDhCAA07eRTi9fTTy0G9nz/sEF9L+Z/z7Fd/L0JAQkF+frl1Wn66sYiOAD06rFn3r59e4IGZAb//Ilpeu7E3YE/M/pWzYHg4tbiq0oB0BMBgI3JgJ+Z/bdOLgb+DPg9SyD44uo0fb61qBKoEAAtEwBYqwz6GfBffLb9Gf5BpTIwv4QBoDUCACu3c9DPTL+iC1em6ZMri8oAQAsEAFYmg30G/nPPjj3T34ssE/z60iIIXLs5AWyMAMBSZbafmf68rs+DpSrwwSVBANgMAYClyMD/8qlpeuWU2f5eCQLAJggAHEhm+Znxp8zPwQgCwDoJAOxLBv4fn1bmXwVBAFgHAYA9yWl8Pzu7WONntdIsmJ0DggCwCgIAu2KNfzPmXQOpCsCqzfdszPdqJHz+9WvnWIxKAOCRztyZ7f/8nIF/kxIEfvKx44ZZnp0ncT7q6O35Uqy8/nTVSZejEAB4oJT7M/Bb52+H/gAOam7cTbA/SKifT7lUneqXAMB9pdz/b6fN+ltkWYD9WFXjrvdjvwQAviFlwcz6Nfm1Lw/e73+kGsDDrauS5/3YHwGA/5A1wF+9NE3Hjk50JLOvvOBem6jkeT/2QwDg7/KgeOPsRKfMvtgplbwfnV7s2tmE9Aa8dUGjYOsEAP6+r39TDwqWy+yLlPx/+dKiordJ2THwg4+EgJYJAIVllpAHhS7/sagG1JXB/7evtrOMJwS07fGJkvKg+P0PDf4jysP/D68tOr6po7XBP1KFeN3SYrMEgIJafFCwfAkAf3xt8ftmfL9stIE3F4VZYmyTAFCMwb8W1YAa0sez6TX/h8n7TxBtjwBQiMG/rjyAs8XTQ3g88x0dLTu8fb4IbREAijD4k8Od8h4445CnYeRz3cv23fQb6TlqiwBQgMGf2bHtLWKWBMaQz3VP9AK0RQAYnMGf+9Eg2L+U/nv7XKcCcMT9Is0QAAbXamcwm3dsOxymS5u+JLj9lw5n0+kFcM9IOwSAgbXeGczmHdu+KMaSQF9yzG+vwf65ExONEAAGlQe69TZ2y5JAP/I76rlq88KJiUYIAANKl7cZHXs1LwnYJdC2zP57lveZPoA2CACDyezgZ47eZJ/sEmhb1tBHmEE/KQA0QQAYjI5/lsHBQW1KdWaEz7f3VRsEgIFk5m/wZ1nmg4M8rNvxoh0bLJEAMAgXbrAKx7ZvjbRVcPMSxJykxzIJAAPIg8GaLasyn+PuPbZZ/3mg5sxrNycaIAAMoOc9wfRj7gvQwb0ZI+3OuC4ANEEA6FxKs8qzrEv6ArIkoC9gvVKFGaX8/5evJxohAHRM6Z9NcF7A+o30s966MdEIAaBjSv9sivMC1muk9X8VgHYIAJ3q/ThQxpAA4OCp1Ur5XwWAVRAAOtXbPeCMK9tP9QWszmhLLV8JAM0QADqUmb/SPy3JrZMODVqN0Q7/sQWwHQJAh6y70qL50CDNgcsz4uE/lgDaIQB0JoO/2T+tynq15sDl6f3mv3sp/7dFAOiIxj96oTnw4Eb8vCv/t0UA6MiL1v7piObAgxlt9h9fXp1oiADQiZRWzf7pzdwcmK/s3qjVPuv/bXlioguj3AO+DjlnPA+aW18vvs/BI/c7fCQ/zwSr49tfM0gdds790s3Nge99Ok2/uzyxCyPO/kMFoC0CQCc0Vd1fBvjPthbNRV9cPfglI7no5umnFp3X84vlSE9AAtavL008RO5bGHH2b/BvjwDQAfv+vykPkotbi4F/2beKpWqQf//Oh1UeyHm9cMLv4aASZPOz/OnHGsLuJwH0jUGbJ+0AaI8A0IHRDgLZj5TwUz7OwL/udcT8b+YVCWP5fagM7N/cF/CTj60J32vk+z0+25pozGPPvH379kSzsj79h9emsuaB//zlxey8Ffm95GGtMfNgshxgSWAh76Wfn5uG9S+/aOszjApA80ZtBnqUVgf+WcrXb12Ypg8uCQIHMR9slZ9j5SWBBMqRz03IkprBvz22ATYu687V5GHx3Q8XM8PWHxpzEEg5+3rhAewgEp4q3yOQ/+7894+8A0UDYJsEgIZlnblS01lm/W/eGUy//1F/s8H0CHz7/cVWNzOdvTu2vdRVbbfLke2jk0f/nF+0/t8kAaBhlZr/0gyWWf8nV6auZdnie3f+Oy50/t+xKQkAWQevUA3I4P+bV8c/JGk+l4P2CAANq1L+zzp/Bv9R1oDnZYG8LAvs3bwkMPJOiyqDf+R8DtokADSqSvk/6/y/+HQaUqoAWc5Q/ty7Y9vr4iMuCRzfPhmxyvHIvVf1RiYANKpC+b/CFrBUA9Ig+N6gIWfVEgD++No4SwIJ9gk2VXp7UgHTANguAaBRo5f/MyBW2v+d3oDvvG9JYD9GaRB8+VStwT+U/9smADQopcGRHxIZ+CteCpNqwL9+6EKc/ZqrAb2VzudtfqMe8fsw573Xm+YgoAY9d2IaVvWT37LVMdWPVAJygNARtw/uyXyzYPorWj88KL/bzPqrbW2c6f5vnwDQoFz9O6KsBVYe/Hea7zWoVhJeluwUyKvFIDAP/K+cqn29tM96+9wF0KD/9c40nMwGejzgZ9UyQOQIWEcJH0zCZbrNN3n+QpYmctNh9YF/lp4Xn/e2qQA0ZtS9z5kNeBj8oywJzOcFVC0VL0M+N3klTOXWuc+31nP+fKo3Z7avi3ZD5F0JYj7v7RMAGvP0gHuDL1xxMt6jJCBlvTSNYpYE9i8z73l5IBIC8nP909XFgHSQNemU9vO7yUCfz2l26vhd3V+WZWifANCYEdf/PQx2Jz0BX93QF7BMc2UgZflIxSVBYP66c1tmvk+AmMv38/fp4s/L72R38j42+++DANCY0SoASoF7M28VfPfcoqzMcmVAn7cRPj+xCra59sM5AA3Jg2m0bWFm/3uX2WlOD9RFTW+y5OLkv34IAA0ZrcRo9n8wCQCOEKYnQmtfBICGjHY5iNn/waWcmu2TjhCmdQn8Zv99EQAaMtI2ojwIzP6XIz9LIYDWCfz9EQAaMsqNZ+EK0OW6tn2QkqNVaZHlvj4JAI04fGicHoA0sdn3v3xzCBCuaEkqU2b/fRIAGjHS+n9OYmM1Eq7evKDZinY45bNfAkAjRjo7/HMBYOWq36pIGzL7V+3rlwDQiJEqADqB1yMBIPcIrPq8e3iQLEnRLwGgEaOcALiOC1i4K7OvH3xkhwDrp/TfPwGgEaOcAGj2v37ZGWCbIOuU95olqP4JAI0YZQugALAZ8x0CF/VfsAZK/2MQABoxwhbAzAoEgM1xhwDroPQ/DgGApfni6kQD3CHAqmS5ScAchwDA0jigph25Q+C7H+oLYHnyXvrpxxMDEQAa0fuDWvm/PZoDWaZUlZT+xyIANKL3rXPKgm2amwMd1sJB5PPthM/xCACN6PmSl8wwdZ+3K82Bbzk+mH06f9l7Z1QCQCP+dHXqVmaXDv9pXx7i2SVgSYDdst9/bAJAI3otr+UBofmvH6nU6AtgN65v3z4p3I9LAGhEyrQ9NtHZE9yf/L6+/f5ipwDczzz4+2yPTQBoSG8zaTeB9S1d3c4L4F7zgVIG//EJAA3JMkBP5TbHgfYvVYDvvG9JgIUM/vlc99yUzO4JAA3Jh++DS1MXlP7HYasgYfCvRwBoTGZkrfcCZKDQGTyWeatglgQ0fdVj8K9JAGhQHsStPoRTKv6v1o2HlQD6PUcIl2Lwr0sAaNC1RgdZ24JqmHcJqPKML5/p3Blh8K9JAGhUa2V224LqyfvPmQHjmu+K8Jmu65/++fQ770w0ae4FeP7EtFEG/7rmY54PH5qmk09NDCJbjl///TT9+a8ThQkAjdt0CMjD/4fnPSgqyxpx3gcJAwkBCQP0K42e/+2/T9O//22iuMeeefv27YnmJQC8e26ajh2d1iIP/ZSAnRbHTsfvvP9+dHqazj070ZkEuDcvuLabuwSAjqzr4ZsHRHYiKPnzIHkP/vj0+gIpB5PP9E8/1sDLNwkAHVpVEMhDIrN+MwR2I+/Dl09N0yunJhqlksfDCAAdm4PACyf2PxPLAyJHEKcpyMDPfuR9+NtXVQNao5LHowgAg0iPQBq08jUP4gd1bGfAz/afvNLY9dUNZUGWw7JAG7LWn0a/Xq8YZ30EgIEdOTRNT+7o2Lafm1XTJLg5Cfcp9Z+/LNSzOwIAsHQJAq+fnaYzJyfWIAeH5SIx5X72QgAAVuZbdwLAG2ctC6yKgZ+DEACAldMfsDwp9WfgT6nfwM9BCADA2iQIvPjs5o+37pE1fpZNAADWLgEgQUCz4KNlO9/F7a26Bn6WSQAANibNgnMQsDxw11zmz8DvfA5WRQAAmjBXBbJzoOKFQw7lYt0EAKA52T2Q10FOuezBzkHfoVysmwAANC2VgYSB+aTL3mV2v/MFm/LEBNCwnQNlTrd87sTdo6/zanm5YD56e/5vMMunJSoAQNcSArJMkFCQpsKH3YWxKhno8/ri6uLI7bzm76FVAgAwpASB40fvhoJUCvI6vt1TkO+P7KgezH99Hsx3yoE7+XO3tv/a9Zt3Z/e3vjbQ0ydLAMCQ5pn4lxNwP49PAEA5AgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBAgAAFCQAAEBBT0zQoWNHp+nIoWk6+dQ0HT60+ON8zZ/L1+NHv/n3H97+83/5evGa3drxx9duTtP1m4s/ztf8ta9uLL4CjEYAoGkZ2F84sfg6fz8P5vtx7z97bMdfe/4B/0wCwdaNxSvBIF8FA6B3jz3z9u3bEzQgs/en78zonz+xeM2z+1bNoeDzrcXXVBAAeiEAsFHzYD+/epYQ8OXVabq4tfgK0DIBgLWaZ/kvPjtNZ062PcM/iCwbfLa1qA7kK0BrBADWIrP70Qf9B0nfwBdXp+n85UWVAKAFAgArk0H/W3cG/HPP1hv0HyRh4NeXFssEmgiBTRIAWKqU+DPoZ7bf+5r+Ks1VgQ8uaR4ENkMAYCky8L98appeOWW2v1cXrggCwPoJABxIDtzJwK/Mf3CCALBOAgD7koH/R6cXAz/LJQgA6yAAsCcp9WfgT6mf1UmPQIJAGgYBVkEAYFes8W/GvGsgYQDW4dg992hcV4kalgDAI6Wb/91z//hgYH1y98BPPrYswHLtPHY7rwd9xnfeh+Gky3EIADxQZv0/P7fY1kcbfnd5caCQIMB+LeN8jvmky0+uCAM9EwC4r5zYl8Ffub89lgXYjwz8Pz69/PM5vB/7JQDwDZr8+pFS7HufqgbwcPlMv3529Tt2vB/7IwDwH7K177evWuvvTWZfdgtwP5uo5CUEZKmK9gkA/F2O7n3jrJJ/r1KG/f5HZl/c9bOzm6vkJQAkCNA2AYC/rwvmRf9UA0jJ/5cvbf4ujuwY+MFHLr1qmQBQWB4UmSW86DS/oagG1JXP9G9eXWzpa0F2COS9SJsenygp6/15UBj8x5Mejj+8pqpTTWuDf6QKkUkGbRIACpqb/Vp6ULB8CQC//+Hi9834UvZv8TP9yim7ilolABSj07+WDAgJAS5tGltm2Zte83+YhFFBtD0CQCEG/5oOb5/omJeH8Hhe7mCGfXj7fBHaIgAUYfAnVQBLP2PJ5/rfTk9dyPuv5SpFRQJAAQZ/ZnkPZElAg+AYejuu+4x7RZoiAAwuncEGf+6VAJD3hSWBfvU4o86uoyMOG2uGADC4bAsy+HM/GTwSAszK+pPg1mMVJ9UKt4u2QwAYWDqDrffyMAmH2T5mSaAvmUn3GuyfOzHRCAFgUHmg23vLblkS6Eevs//ZCycmGiEADGi+9xv2Yl4SUDVq28udB/tULvQBtEEAGExmB++em2Bf7BJo3wg9G08KAE0QAAaT9VxNfxxUAkB6SMzU2nKu47X/nSw1tUEAGEge2sq3LEt6SNwl0BaXd7FMAsAgrPuzCseO2irYigQxJ+mxTALAAKz7s0q2CrZhpMH/L19PNOCJie7lkg3r/qxaAkAOcvng0jTd8gBfu5HK/9dvTjRABaBzaQpy1Svroi9gMxK8RqkAZPYvQLZBAOhYOrSVZVm3uS9Aw+n6jFT+37ox0QgBoGNK/2zKfF6A0ybXY6Tz863/t0MA6FRKsB6+bFrOClCFWr2RAoAKQDsEgE6lKxtakADwq5ccGrQq5wa7QvcrAaAZAkCH8kCw/kpLMkPVHLgaox3+c80OgGYIAB1ScqVFmgOXb8TDfywBtEMA6MwoZ4EzJs2By5VG35Eo/7dFAOhI7/eAU4fmwIPL5320Mz6U/9siAHQkpUCzf3qRAJAlAX0B+zPa7D++vDrREAGgI2ZU9CahVQjYuxFn/2H9vy3uAuiEtf/dyznjOWo0D5scOjIfPDJ/v/PnmO/zsM1Rq5rXVmPuC3jv02m6cGViF0ac/YcKQFsEgE6Y/d9fBvTPthbNRRnw8/Ug54wnBBzb7rzO965fXY4ErJ+fW/xsf31p4iFGnf0b/NsjAHQge6zN/u/KQH9xa/FAWfZDZevG3X9/5ACW/PznFweTIJtglWqAhrD7y5LJiOwAaI8A0AFbqhYz/ZSP54F/XW5t/+/mNYeBDGIC2f7lZ5gQ8P2PhIB7jfzeUgFoz2PPvH379kSzUg78w2tTWRn4f3d5ms5fbusK0SwNJJipChxMKgH5/TJNZ06OfcT3v/zCNcCtUQFo3MuFZ/9ZK25t4J/Nyw8JaFnb1iuwPzkvIDPeDy7VHhzyPsrPYlT5rBj822MbYOPOFJxh5mHxnfcXAaD1h0ZK2Cllv3VhsfuAvUslpfI9Allayrr/yMtK1v/bJAA0rNrBPyn3pyTc49pwegS+/b4O9/2qfITwb14d/3P+2dZEgwSAho12C9jDZPb83Q/7Xw9OAEj1QsPT3mWrYMrgWVKpcrXwu+fGP38in22fhzYJAA174cRUwidXFoP/KB3h87JAqhnWPfcue+BHXxJIwPnVSzVC/hdXJxolADSqSvk/M+Y3L4w5UKaa8b0P9Qbsx7Ht3S8jHoCVYJOyf5UdJJ84/bFZAkCjKswMMviPvmaeaoDegP1LAPjja+NUA1LuT8NflWOnlf/bJgA0avTyf4XBf6e5N0A1YO9GqQZkS+/o3f73Uv5vmwDQoPk8+lFVG/xnc2+AC3H2p9dqQP7/ZuB/4+yi0bES5f+2CQANeu7ENKyqg/8sISBnBlgS2J+5GpCdAq0HgTT6JbSkobHiQVHK/+1zEmCDRj38J5fsGPgW8nPI7KhaSXhZslMgr1RTcopgSztIMvCn3J8zDarN+HfyWW+fANCgpwdsEMps4KcfT+wwLwk4Snj/dgaBBKpNzjgN/N9k9t8+AaAxGQhGPAQlswE3v/2jOQSkVDzilrd1mYNAgmYaz9YVBvJZzY6dbOkT4u5KIPN5b58A0JgRZ//zdbo8WAJSBq/Xz9Y5BW8Vspwyh4EcLT1f2pTlp5xHf9DzJvLvzw6dfE4z4FfZzrdXWZahfQJAY0acRXgY7M6F7VmrvoDlSBk+M/OdB+4kFCQMzF/jflsz88/mld9DAlkG+vnP8XB5D5v990EAaMxoAUApcG/mJYHcC292uXwZwOfPWJWT+NZN818/bANsyPGj45V/zf737togFyNRz7zkQh8EgIaMtv5v9n8wuUzIbIqeeL/2RQBoyGglX7P/g8sD9Scfu1WQ9pn990cAaMhI6/8agZbn4pZbBWlfTrikLwJAQ0bqMHYG+HLNzYFCAC2y3NcnAaARhw+NswSQLVb2/S9fHrD/+qEyK23J591yX58EgEaMtP7/2dbEiuRhm0qAHQK0Iu9Fs/8+CQCNGKn8/6erEytmhwAtyJKU92G/BIBGjFQBuKgCsBZ58CYIwKakGkW/BIBGjHIGQNanbVlbn5Rfv2uHABtwXum/ewJAI0Y5AfCrGxNrljPt7RBgnZT+xyAANOL4IJe/aADcjHmb4JYAxhq8eUGlbwQCQCNGuP1tvn6VzXCHAOuQmb/P+RgEAJbG7L8NdgiwKkr/YxEAWBqn/7XDHQIs2/Wbuv5HIwA0ovcGrvz/VxZsizsEWKaESl3/YxEAGtH7TE1ZsE1zc6CzGTiIfL4d7z0eAaARPXdvm/23LSEgywFCGvuR8Oi9MyYBoBE9BwA3gfUhD/G3bN9iDxLuXfM7LgGgEZ93WqLNA0LzXz8S1vQFsBtz05/AOC4BoBHXOi2jawzqz3ytsDVdHmS+ddJne2wCQEN620efGYJBpE95wKe0a22Xexn86xAAGpJSek/lNnuC+5cA4DIhdvrFp46UrkIAaEiS9weXpi4o/Y9jvkxINYec8a+npw4BoDE5x7319G1b0Hiu3bQkUFkmHwb/egSABrW87ca2oLElAHznfUsClcxr/gb/egSABqUCkAtdWmNbUA3zLgG3Co7vumukS/unfz79zjsTzfmf/3fx9fkTUxPmB4V1/xr+39+m6X/878Xv/eRT03T40MRg5s/0//nzRFECQMPmcwE2HQIM/nVlZpiejwSABAHGkGfLDz6apj//daIwAaBxmw4BHhRkjTghQDVgDPOR0P/+t4niHnvm7du3J5r3rZPT9MbZaTp2dFqb9CFYB2an43fefz86PU3nnp3oTIJcLoVycRczAaAj63r45gHxnsNAeIi8B398er2BlP3LZzqzfst47CQAdCjLAXn4LntZICVe936zW6oB7cusP59plTzuRwDoWALAi3cevmdOHmxdNrODPCSUBtmPTSxP8Whm/TyKADCIhIE8iNOk9bBGrcwI5psHv9ru8Lavn2VIVSovNsusn90SAAZ15E4AePLQokwb8yzACW+skmWBzTp/eTH4C/XshgAALF2qUL96ybLAuij3sx8CALAydguslv4dDkIAAFZOEFguAz/LIAAAayMI7F+a+9LYl1v7lPpZBgEAWLvsWHnlVDuXXbUsB3Jl0M9Lcx/LJAAAGzPvGnjhhKrATpnt50CubNNV5mdVBACgCakKZIkgX6vKYP/JFedzsB4CANCUnGGREDC/RpaZ/lziN+izbgIA0LT5yOv5lMveZcDPTD8Dfk7jNOizKU9MAA3LYDmvg6dn4OmnvnnsdcscvU3LVACArqVCkCCQJsJH3YWxSjlmO7P7DPgZ7LduuFKbtqkAAF3bWSGYpY8ggSCvVA0OH7r7feSPj2yHhIftPth5d0YG9szoM4PPn8/r1vYa/l+/NrOnPwIAMJwMxrfMwOGhHp8AgHIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIIEAAAoSAAAgIL+P1tKf0g6ESEYAAAAAElFTkSuQmCC",
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACDJSURBVHgB7d09rJ3FuS/wlwgoMJJd2BfMkQCBTwHSsQsogCgpToSVMqQOaS+kvVAHakgbUkNakki3SYJyikTYKYJ0cREagw4p+DhQ2BKmCIXv+u/FizfENvtjfczM8/tJS3vbBALea73zn2eembnl9bNXr04AQCnfmQCAcgQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAggQAAChIAACAgm6doDO3HVm87pymow8svx65a/nK93ndcde1/+3u77/p84+XX7/4bPG6svx65eNrX/PX8/uX350AhiMA0LSjDy4H+mMPLgf5/Ppmg/p+fPXP2cM/LyEggeDS4usnF5a/TjgA6NUtr5+9enWCBmRmf/z0NJ04sxzwM9jn91qVQJAg8MG5RTB4T6UA6IsKAFuTwT2D/D1PLAb908vve5IKQl4nn1j+OoEg1YEP3pymTy+oEABtUwFgozLoZ8C8/2z7M/zD+vDcsjqQlzAAtEYAYO12D/op8Vf0/huL1x+XlQGAFggArE0G+5T37zs79kx/P7JM8M5ry6WCeRcCwDYIAKxUBvoM+Bn4q8729ypVgYQBQQDYBgGAlcjAf+rHi9dTZvv7JQgA2yAAcCiZ5WfGf9+TE4ckCACbJABwIBn4H35amX8dBAFgEwQA9iX73k8/u1jjf3xizd759XLngCAArIMAwJ5Y49+OeddAqgKwbvM9GzuvI1/eh/GZcyxGJQDwrU4uZvuPPm/g36Y8iM+/6LhhVmf3SZzfdvT2fCnWzl0YbzvpchQCADeUcv+jz1nnb4n+AA4rn+f7n1wE++8eLtTPJ12qTvVLAOC6Uup/6Gmz/hZZFuAg1tW46/3YLwGAr8mA/8jzmvx6kAfvn59XDeDmNlXJ837sjwDAV7IG+PjPlw8M+pHdApmBwTdto5Ln/dgPAYAdeVCcfmaiU2Zf7JYBPwN/PtfbkN6At17WKNg6AYCdgX9bDwpWy+yLVPAe+/mys3+bsmPgL88LAS37zkRZmSV8/yWD/0ge+sk0/fBVyzhV5eeez/S2B//Iv8P3XtJI3DIBoKg8KH7wii1+I8rPNiEgJWDqmAf/lsJfQkBODqVNAkBBLT4oWD3VgFoea7SBNxeFqTK2SQAoxuBfi2pADenjaaHsfyMJo5457REACjH415UHcKszRA4ns+vWZ9i5W+CR5yYaIwAUYfAnZ77nPXDSIU/D2Lmds5PtuydO6zlqjQBQgMGfWd4Dj79gSWAU+Vz3RC9AWwSAwRn8uR4Ngv3LYNrbzy9VANsC2yEADM66Lzcyh8N0adOX/Ox6nE2nFyBLUbRBABhY653BbF8GkjRnWRLoS35evQb7E/oAmiEADColXutt7JUlgX7kZ9Rz1eb4mYlGCAADSpe3GR37NS8J2CXQtt4/23mf6QNogwAwmHy4zjh6kwOyS6BtWUMfoYSe/w62TwAYjI5/VsHBQW1KdWaEn4n3VRsEgIGk6c8Hi1WZDw7ynmrH/WcnWBkBYBD3unCDNdi5NfKXtgq2ID8LJ+mxSgLAAPJgeNiaLWsyn+OuL2C7Rto///nHEw0QAAbQ855g+jH3Bejg3g4BgFUTADqX0r/yLJuSQegHrwicm5YqzCjl/y8+m2iEANAxpX+2wXkBmzfSn/Xl9yYaIQB0TOmfbXFewGaNVP7/pwpAMwSATvV+HChjSF/AaQdPrdVoF+hcfneiEQJAp3q7B5xxnfrRNP3nL1Wj1mW0pRZLAO0QADqUxj8PW1qSWycdGrQeox3+c8UOgGYIAB3S+EeL5kODNAeuzoiH/1gCaIcA0JmsuZpl0aqsV2sOXJ3R/hwvKf83RQDoyE7jn7PA6YDmwMMbsdH3848mGiIAdOQ+a/90RHPg4YxYRfn0wkRDBIBOpLRq9k9v5ubAow9O7MOo23wvWf9vyq0TXRjlHvBNyDnjaTTKkaPpOP7iyvUPHzly1/Jc+yN3LwNWBinn3K/e3Bx44VfTdPG3E3swag+FCkBbBIBO6Py/vgz2H7y5bC7Kw+Wwl4wkACQInDi9eJ1x/eoqnX5mGbTeeW3iJk4+Mebs3+DfHgGgA/b9f10eJB+cW75WfatYqgX55+f1zq+Xv5cH8j2PLwOBn8PhpDkw1ay/vuhGuOtJAD3zzDQk5f/2CAAdGO0gkIPIwHzxN4tB//zm9xF/eG75ioSx/DxUBg5u7gs4/6I94d808v0eH5ybaIwA0LgRDwLZj3ngz9pxvt+2f7yxfOXnktmsxsyDmfsCUmWxJLCUcHnqqWlYwl57BIDGVT1QpbWB/5tSvn7rF8sBTBA4uPlgq4SAyksC+TM4M/C5CVlSa/FzXJ0A0LgTBWf/eVj87eU+BoQ5CGRpImu3egT2Lw1veZ//+fmaISDvmSyJjLwD5ZO3JxrkHICGpfRfaUDJDOGtl/scCNIj8PufTtOFV8x0DiLv8x++Wq/ilUH/sZ+P/zlPQKY9KgANq1RWTofwCJ3hF3+3fNhZFjiYSksCGfy/99KyKXJk87kctEcFoGFVyv9Z5/+vn43zwJ+XBXpZxmhNlgRSEh+5+bXK4B/K/+0SABpVpfyfJrqcEDei7BbIcobtT/s3r4uPuCSwswPilRqDf7z/xkSjBIBGVSgfV9gClgpAljbSG8D+ZUkgvQGjhOEE+wSbKr09ef87AbBdAkCjRi//Z9Zfaf93egPSJGhJYP9GaRDMHv9Kg38o/7dNAGjQsQfGfkhk5l/xUpgM/n/6mQtxDmquBvR2s+C8nHF60CN+bybBl3bZBdCg42emYVU/+S03FKb68flHiwHtp24f3K/5BMGsK7e+UyA/21M/XgaXinT/t08AaNA9T0xD2rlgx7GvO+btgtVKwquSnQJ5tRgE5oE/Jf/KAc9nvX0CQING3P6UB3S2xXHNvCRw+n87M+Cg5iCQcPn+H7fbcZ6liYT36gP/7BPNf80TABoz6t7n6me930iWBHJmQP5sqt77sAr53OR1+tkvr4p+czPnz6d6k0E/LzdEXpMw5vPePgGgMSPuDd72zKwH6Y249J77BA4rM++5KhAJATllMt3on//P4dak88++4+7lDp006qZXx8/q+vJ+pn0CQGNGXP/3MNib3CeQAUpfwOrMlYH5mt1UBNKAOX+9smuWmu9vv/Na+f62xfe3fzno5+fhZ7I3qcCY/fdBAGhMb1ucvo1S4P7MfQGP/J9xm0G3KYP7V58xJfu1sM21H84BaEjKiqM1D5n971/6AnJ6oC5qepMlFyf/9UMAaEhKjSMx+z+cnXsSHCFMR/4utHZFAGjI0QemoZj9H17OC8iFQoIUrUvgN/vviwDQkBMDnQCYB4FBazXyZykE0DqBvz8CQENG6jLObIDVyeCfEJCtgtAay319EgAakS1HowSANLHZ9796ecD+5Xl/trQl70uz/z4JAI0Yaf0/+4BZj52TA1+2Q4B2OOWzXwJAI3IAySg+PD+xZtVvVaQNGfhVpPolADRipApAjl1l/RICcsHSus+7hxtJXwr9EgAaMcoJgJu4gIVr/vGGHQJsRwKo913fBIBGjLIEYPa/ebk/QAhgk3Ya/yxBdU8AaMQoOwDcAb4d8x0CGjDZBKX/MQgAjRghAGQQchLY9rhDgE1Q+h+HAMDKKP+3wR0CrMuldwXMkQgArIztQO3IHQJZEjBTY1XyXkqFiXEIAI3o/UGt/N8ezYGs0tuveC+NRgBoRO9b55QF2zQ3B7qbgcPIspIDvsYjADTi0sWpWxlkdJ+3a+f44F8IaRzMxd9674xKAGhEz9vnsvbv8J/2ZRZ3/kVlXPbOfv+xCQCN6LW8tnMWuPJyNz48py+AvZmvoBbuxyUANCJl2h6rAG4C609+Xr//6bK0C9czD/4+22MTABrS20zaTWB9u/Ar5wXwrzLjt1RUgwDQkCwD9FRucxxo/3JeQKoBHvZEnj/5XGcLKeMTABqSZYB3Xp264DjQcdgqSBj86xEAGpMZWeu9ABkodAaPZd4qmCUBTV/1GPxrEgAa9NbL7T6EM1vM2jFj2jlC+FnVnUoM/nUJAA3Kw/ftBpuzbAuqYd4loMozvp3ln2cN/lUJAI36xxttPYBtC6onfR5+5uO65K6I8gSAhuUB3EIIMPjXlQue8rPXIDiWbN/9i890ebe8fvbq1YmmPfSTxevpaStyxn/LPQlszr1PTtPDi/fhHXdNdCw9PA6BIgSAThw/PU2PPre5h28G/FQfPCjYLe+/BNL7zk50JrP9v73s2m6uEQA6sqmHbx4QeVAoD3IjqgF9yWf6/AsqeXydANChdQWBPCT+/poZAnuT9+Gpp5Yv2qSSx80IAB2bg8CJMwefieUB8eGb0/Tfbxj4OZi8977/kmpAa1Ty+DYCwCDSI3DswUUYWHy94+5pOvrA9f93GfCz5/fSxWn64Pzye2VBVsGyQBvmc0R6vWKczREABnbbkcXrzmu/NhNg3TQJbk+C/MXfLMv9Qj17IQAAK5cgcPqZabrniYkN2LmfwwVd7JMAAKzNyUUAOPOMZYF1MfBzGAIAsHb6A1Yn5f33/7C8uMnAz2EIAMDGJAjcf3bZtMr+WONn1QQAYOMSAO57UrPgXmQ7X47kTrnfwM8qCQDA1mRJYA4Clgeumcv82arrfA7WRQAAmjBXBe757nILazUO5WLTBACgOdk9cM/jhzvlsge7B32HcrFpAgDQtFQGEgaOnRqjeTCz+0/eXrwumOmzXbdOAA37dNdAmaWB44uqwIn/WAaCow+2vVwwH709D/hm+bREBQDoWkJAlgkSCo7cffO7MNYlg/oXny2CymKgv/Lx8pXQYp8+LRMAgCElFMyvI3ctKwW337kMCJF7MnZXD+Zfz4P5bhnI83t5/XPx+vx/ll8vv7f8PQM9PbIEAAwpg7KBGW7sOxMAUI4AAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUNCtE3Tojrum6bY7p+noA9N0+53LX99+ZPl7t3356912fn/x17+4snh9du33831+Lz7/aJqufLz89ZWPll8vv3vtrwOMRACgaRnIj5+epiN3LV/Hz1wbzA8if9/X/t7dQeH09f+eOQhcWrw+/3j5VTAAeicA0IwMzEcfnKYTi0H+xOnl9wcd6Fcp/w4JIce/ERB2QsF70/TBm4vv31uGA4Be3PL62atXJ9iSDKrzgH/89NS1BIJPLiwCwblp+vTCBNA0AYCNmmf59z85TSe/28YMfx2yPJAgkOrAh+cngOYIAGxEZvejD/o3kqWBVAYu/nZZJQBogQDA2mTQv+eJabrvbL1B/0YSBt55bVkd0EQIbJMAwEploD+5GPTvP9v/mv46zVWBhAHNg8A2CACsRAb+Uz9evJ4y29+v998QBIDNEwA4lOzTz6CvzH94ggCwSQIAB5KB/6GnFwP/kxMrJggAm+AgIPYls/wM/Jn1sx4JVTkXYQ4CAOugAsCeWOPfjnnXQMIAbMI379FQiRqXAMC3Sjf/o8/964OBzcmRw399wcOY1ZpP4jz2wPKArht9xnffh+Gky3EIANxQZvqPPD9N9zw+0YiLv1u8fiMIcHCrOJ9jPuny/T8KAz0TALiuk4tB/9HnlftbZFmAg8jA//DTqz+fw/uxXwIAX6PJrx+ZgV34lWoAN5fP9Oln179jx/uxPwIAX8n63/dfstbfm3d+bbcA17eNSl5CQO69oH0CADsyO8gsQcm/T5l1/fl5sy+uOf3M9ip56VW58MpE4wQApod+siz70z/VABLiH39h+3dxZMfAX5536VXLvjNR1k6X/3MG/5EkzP3wVcs4VeUz/b2X2riI69iD0/TYCxMNEwCKygCRB4WjfMeTn21CgGBXyzz4Z+BtRU60zNIibRIACpqb/Vp6ULB6qQb85y9VA6pI2b/Fz/SpH9lV1CoBoBid/rVkQPjBL1V6RpeGvxbK/jeSMOqZ0x4BoBCDf0233bns9XjEcc5Dyuy69Rl23oOWpNojABRh8CdVgLwHjlr6GcZ8LXcP8v5ruUpRkQBQgMGfWd4DWRIwGxtDLunq6eyO3EFAOwSAweXhYPDnm7Im+z3vi67d2+GMOlUAh421QwAYnIc8N5ItWgmHJ9322J18ph/usIqTXgBVgHYIAANLZ7CtftxMBpJsH7Mk0JfMpHsN9if0ATRDABhUSrz23rJXlgT60VPj3/UcPzPRCAFgQFkXNKNjv+YlAbsE2tZ7sE+A0QfQBgFgMPlwpTMYDsIugfaNsIaeXgC2TwAYzGM/V8bl8LIk4Hro9tzb8dr/bp5RbRAABpKHtqY/ViVnuP/gFQ/rltx/doKVEQAGYd2fdZgPkbJVcPvys3CSHqskAAzAuj/rZKtgG0Ya/L+4MtEAAWAAeTAr07Ju+gK2a6Ty/+cfTTRAAOhcmoJc9cqm6AvYjnTNj1IB+OIzFYBWCAAdy0ysx+NA6dvcF+C8gM0Z6fS8y+9NNEIA6JjSP9synxfgtMnNODnQ+fn//GyiEQJAp/IA9vBl23LfhObA9RvpAp3L7040QgDoVLqyoQVpDswBVJoD1+Pewa7QtQTQDgGgQ3kgHH1ggmZkhqo5cD1GO/znyscTjRAAOqTxjxZpDly9EQ//sQTQDgGgM6OcBc6YNAeu1mj9FZeU/5siAHQkD1ezf3qgOfDw8nkf7YwPBwC1RQDoSEqBZv/0Is2B33vJe/agRgxQn16YaIgA0BGzf3qTA2y+LwTs24iz/7hk/b8pt050wdr/3n3+8fKo0csXl4eOzMeO5mt+fWTXn2O+v+Pu5VGrdlasx9wXcOFX0/T+GxN7MOryiQpAWwSATpj9X18G9Q/fXDYXZXaRDuPDnDOeDvYMWCf+Y5qOnXL96qokYD3y3DJsvfPaxE2MOvs3+LdHAOhA9lib/V+TQf6Dc9P0yYXVP1QufxkiPjy3/HUOYMkxrP/2xFjHsW5L+gJSaUk14HP7wa8rSyYjUv5vjwDQAVuqlrP69/+wGPjPb3Ymkf/ff7yxfM1h4GF3MBxKAu2xRaXlz88LAd+UgDTqe0sFoD23vH726tWJZuVh8MNXp7IyAF/8zeL127auEM3SwL8/pSpwWKkE5GfL4r30+NhHfP/fH7sGuDUqAI2rPPvPWnFrA//s0y+XHxLQHn1Or8BB5byAnb6AV2sPDnkfnXl2GlY+Kwb/9tgG2LiRbgHbqzwsfv/TxaDw6/YfGilhp5T9t5eVsw/q1I9q3yOQpaXRt0pa/2+TANCwagf/ZLBPSbjHteH0COyEFh3uB1L5COEKhyV9cG6iQQJAw+4b7Bawm8mA/6dn+18PTtUiQeATDU/7lq2CWRLIdsEqVwvnv/XY4Jcn5bOtAbBNAkDDThRZV87hMBn8Rymh57/jL4sqxoVXrHseRPbAj74kkIDz2Atj7vf/pk/enmiUANCoKuX/zJjfennMgfLi78YKNps0734Z8US8/Lel7H/P41MJTn9slwDQqArl/wz+o6+ZZ/DXG3Bw2RefIDBKGM5Jk2n4G73sP1P+b5sA0KjRy/8VBv/d5t4A1YD9G6UakAbHahcjKf+3TQBo0LEHxn5IVBv8Z/OWwff/OHEAvVYD8u+bgT8NjlWaG2fK/21zEFCDjp+ZhlV18J8lBLz1i+XXUW98W6e5GpCBJe+jlisqGexP/Xg586828Ifyf/sEgAaNevhPDgOxFr6UIJRBrFpJeFXSPZ9Xi0Gg+sA/81lvnwDQoKMDNgjlAf3XFyd2mZcEshe8ypbPVdsdBLK0ss0Zp4H/65yF0T4BoDHZ/jfiw6P1cu22zGcGZH3bksDBzUEgf54ZeDYVBvJZzY6dVO3cB3FN/vx93tsnADRmxO1BeRhoBrq5LAlc+Xh5IYzZ48FlOWUOAzlb4tO3l4Egy0+X3z38eRP552egz+c0VZsRq3WrkPcz7RMAGjPiLMLDYG9yn0BmrfoCViNBKtc1776yOQFgJwh8du2CmivXmanefufy7z9y1/KI4gz0t90pnO1F3sNm/30QABpzYrAdAEqB+zP3BeSY2GwHZbUygM8h+2TBmzY34e+a/7rhHICGZNY32gzD7H//EgL+a4CLkagns39b//ohADRktPV/s//DydXItlLRE7P/vggADTk6WMnX7P/w8md4/kW3CtI+s//+CAANGWn9XyPQ6nx4zq2CtO9vL090RgBoSLqMR+G8+9WamwOFAFpkua9PAkAjdrYaDbIEkC1W9v2vXh6wf/qZE9ZoS5anLPf1SQBoxEjr/x+cm1iThKucHGiHAK3Ie9Hsv08CQCNuH6j8rxFo/ewQoAUZ+L0P+yUANEIFgP1K2fXCKxNsTfpS6JcA0IhRzhTP7N+Wtc25+LtlX4ASLJum9N8/AaARoywBzOerszk5294OATZJ6X8MAkAjRrn8Rfl/O+Ztgpfem2Dtsudfpa9/AkAjRggA6VDXALg97hBgE9J74nM+BgGAlTH7b4MdAqyL0v9YBABWxuE/7XCHAKs2LzMxDgGgEb03cOXfX1mwLe4QYJUy8/deGosA0IjeZ2rKgm2aZ22WZziMVJRU+MYjADTi0sWpWxlknE/frvx8/vqikMbBJDx674xJAGjE5Y63b2VmoDTYvszibN9iP/K5fss1v8MSABrRa4k2DwhX//bjH2/oC2Bv5uUjgXFcAkAjei2jawzqz3ytsODGjWTQd7rk+ASAhnzYWRVgZ/avMahLObTprV9Y2+VfGfzrEAAaksG0p3KbPcH9S1+Ay4TYLTdMXnanRwkCQEMyK3vn1akLGTgMGmOYLxOyJEAa/lT16hAAGpPrXVu/0MW2oPHsdHtbEigrlUeDfz0CQINa3nZjW9DYUtn5/U9VdyqZ1/wN/vUIAA1KSTbrcK2xLaiGeZeAWwXHN3+mrfnXJAA0KksBLZVj5weFmWEN6UfJrYI5OMjPfEwGfwSAhqUc20IIMPjXlYODNAiOJxd3ORCKW14/e/XqRNMe+sni9fS0FXlQnH9B2Z9puvfJaXp48T68466JjrUysWD7BIBOnHxims48s9mHb0rA1oHZLe+/BNL7zk50JiE+Yd613cwEgI5s6uGbB8Tbv7I2yI2pBvQln2n9HHyTANCh46eXD998XaU8HFIatB2IvVANaF9m/flMq+RxPQJAxxIA7lvMxO757jTddmQ6sMwO/v6a0iAHs43lKb6dWT/fRgAYRMLAPY9P07FT03T0wRsHgswIdm4e/H/LEwdzAZEGP1Zhm82qXGPWz14JAINKALjtzmuzsnkWYDbAOlkW2K4M+hn8hXr2QgAAVu7YA9P02AuWBTZFuZ+DEACAtbFbYL3073AYAgCwdoLAahn4WQUBANgYQeDgsq5/8TfLbbpK/ayCAABsXLYO/vtTqz/LYkQ5kCuDfu5j0NzHKgkAwNbMuwZOnFEV2C0D/ft/mKYPzivzsz4CANCEVAXuf3L5taoM9v/9R+dzsBkCANCUnGGREPBvT4wfBjLIp8Rv0GcbBACgafOR1zunXD4wde/ye8uTOFPez+Bv0Gdbbp0AGpay+LwOnj6BHHX91bHXjQcCR2/TMgEA6EYG07wykM5SITi2CAV3/K9vvwtj3f9umdFf+Wg52Gem70ptWiYAAF3bXSGYJQDccfeyYnDkruWv8zW/t/PX77wWEm62+2D3fvt8/8Vny9eVj5eveQ1/5/fN7OmMAAAMZx6YzcDhxr4zAQDlCAAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAFCQAAUJAAAAAF/X+VZHU75JUf9wAAAABJRU5ErkJggg==",
    @"iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACcASURBVHgB7d1/rN5VnSfwU8XQ28wM0Jpp01umOLSFKLQmWgrZpVBnUybtDkzWH4MOTFaTrRnMKGHmHzMzxpA4/rMz0ZhhIk4WI2RFhaxg2kmbDEhNNqCY2IKOlDbCcG+3JdMWdKa3xBr3+/m2X7jWFtp7n/s853vO65U8ubeAWG6f53ve53M+55x5t91x5y8TAFCVNyUAoDoCAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKjQeQl6ZsH889PY2FgaH1/cfD0/LbrowrRo4YVpwdj85tfz08KFF7z6z8bfO5NDR15qv05NHWter7RfDx1+KR2Nr83fO3z45favTew/mABKIwCQtWVLF7cD/cVLl7SDfHz/eoP6uXj133PRG/+zE/sPtIHghckD6dl9z6fJ5uvRY68kgL4SAMhGzOxXrLgkrbp0eVo2viSNN4N/zOpzsKwJIPFafcVlr/61qBZMNtWBXU8/kyaaQKBSAPSJAMDIxIA/3gz0a5pBdeWK5e0A2ydRkYhXFwoiEER1IALB3r3PqRAAWRMAGKoY9K+88rJ0zdp3ZjXDH4QuEFy9dk37691NEIgwsPupHwsDQHbm3XbHnb9MMIemD/orm/J+jR7/3q72FRUCgByoADBnYrCP8v66ZkZc0kx/JqIqEK9YJti2Y2d6tlkiOHTk5QQwKgIAAxWz/XVXvfPEun6ls/3XE0sEt958Y/t9VAS2bX9MEABGQgBgIGLg33Dd1en6a6+qfrZ/trqqgCAAjIIAwKzELL8byJgZQQAYBQGAGYmBf/MN1ynzD5AgAAyTAMA5WXTRBem9f3hDu8bP3OiCQDQLPv7dHwgCwJwQADgr1viHb9PG9Wndu1efCAJNVQDmWnfPRtyxEfdqnLgPY8o5FoVyDgBvKGb7t9x8o4F/hGL74N33fN1xwwzM9JM43+jo7bggK469jiOv9+x73kmXhRAAOKMo99/6wZus82dEfwCz1TXuxhHWswn13UmXqlP9JQBwWhvWr2tL0Gb9+ekOE/Lg5VzMVeOu92N/CQD8iigL3tLM+jX55S8evJ+/6yuqAbyuYVXyvB/7581rr9nw6QQprrxdnD5x25+kty1flshfVGeiUjNv3jx3DHBa8f748K3/LS357bemueb92D8CAK344H70wx9Q8u+hbk031mSnNGaRTlTybvqv/yVtbpbx3vKW4W72ivfjxeNL0o+e2ZuOH/9FIl8CAOl9f3hD+6Cgv8y+6ETJ/2NbPjTSZbzFTcXh7Zdfmr7/gx8KARkTACoWs4SPbfnj9K53viNRBtWAusXgH8t4SxbPfcn/jfzWb/6GEJA5AaBS8aD4i098pN3/S1lUA+rUDf5x42QuIgTEKwIp+REAKpTjg4LBUw2oy+2ZzPxPFZOMY8377yfPTyby8qZEVQz+dYk/5zv/6uPt/m/KFX08OVfz4kyRePaQFwGgIgb/esUDOHZ5eAiXJ5Z7Nlx7VcpZ3CsQZxGQFwGgEgZ/4ujXeA+sdshTMeJz/b6bNqY+iCUpx4rnRQCogMGfTrwHohJgSaAM8bnuk/c01QryIQAUzuDP6cSSwJ1/+WeWBHosSv99+1xHBSCuGiYPAkDhtsS6r8Gf04j3RYTD2ClAv0Rwy33d/3SiF2D1Oy5P5EEAKFjuncGMXoSAW2++0ZJAz2xq/rz6GuxXrdAHkAsBoFCbbljfyxkCo2FJoD/iz6jPVRuNgPkQAAoUZ4Bv3mhGx7nplgTsEsjbpp5Xa+J9pg8gDwJAYWJ28N6ebAsiP3YJ5C3W0EuYQS+YP5YYPQGgMDr+GQQHB+UpqnslfL4XLvS+yoEAUJBo+jP4MyjdwUFCQD7WrV2dYFAEgEJEU5CmPwYtAuUn/3yLrYIZiCC26tJLEgyKAFCAeDBEyRbmQnuOu62CI7f6inL2zx8+/HJi9ASAAvR5TzD90fUF6OAejdVXrkqlOHTkpcToCQA9F6VZ5VmGJfoCPnnHFn0BQxZVmFLK/1NTxxJ5EAB6TOmfUXBewPCtKehnPTF5MJEHAaDHlP4ZFecFDFdJAWDqmApALgSAnur7caCUISpQfbmPvq/aC3QKCgAvTB5I5EEA6Km+3QNOueJa2k/++f/QFzBHSpr9h4n9lgByIQD0UMz8lf7JybKlSxwaNEdKO/zn8GE7AHIhAPSQxj9y1B0apDlwcEo8/EcFIB8CQM/ENb9m/+Qq1qs1Bw5O32/+O9WE9f+sCAA90jb+vVvjH/nTHDh7JTb6Hj7iBMCcCAA9su4qa//0h+bA2Slt9h/27H0ukQ8BoCeitGr2T990zYHLli5OnL1St/la/8/LeYleKOUe8GE4dPil9rSxOHI0zhyfOvZKOjo19Wv/3KKLLkwLmmC1sPka59tfPL6kDVoMVtcc+OBDO9IjO59IvLESZ//h2X3PJ/IhAPSEzv/Ti8F+99PPpBf2H0h79/7rrC8ZiUAw3sxWV166vH2tWnFJYjDee9PGNmBt3f5Y4sxiF0WJs/9n9xr8cyMA9IB9/78q1hF3/3BP2v3UMwO/VexoUzWIWcr0mUo8kKMCs6oJBAv9OcxKBNnVV6xKd/+vrzd/dhrCTrVg/vnFNk9O7LcDIDcCQA+UdhDITEQ5P8rHMdsf9jpi/H/GK0QYW/fu1SoDs9D1Bdx9z9etCZ9i0+9fX2zY33XyM0Q+BIDMlXgQyLnoBv5vf+e77ex81B7/3q72FQ/pmM26j2Fmur6AbTt2WhI4Kd5LG669KpVKBSA/AkDmSm0GeiO5Dfynit6De+9/uB3ABIGZi5/dwibkbmtCQM1LAhH031vwuQmx/j819UoiLwJA5qIRrTaxxn/f177VDrK564JAlDff3zzA9QicuwhP8T7//F1fqTIExOAfSyILCt6Bsmffc4n8vHntNRs+nchSPBTfs35dqkXM+u9/YFt68OEd7fd9cvDFQ+nRploRWw7ftnw8veUtsvW5iMEvDg6aN29eVVvFounvY1s+lJYsfmsqWWwB/enP/iORF0+pjNVUVp6cPJC++OVv9GLW/3oePdmoaFlgZmpaEojBvz0kaXxJKlnc/qfZM08CQMZqKf/HoPlAM0MoRbcsEDPZzTGgWRY4J92SQPczLFEtg3/Y4/CfbFkCyFQt5f9t23emh7Y9kkoUs544ryACwJLfLrvEO2ixJBBBoMQlgVjz/4tPfKT4sn8nwr1LgPLkLoBM1VA+jsF/646yt4BFNSD2u5dU4RimWBK48y//rJgLhSLYx8y/loO9ovzv+N98CQCZKr38/8A3txc/+E8Xyxyf+swX2gci5yYGyzv/6uNpc8+3xEaT4+0VDf5B+T9vlgAyFDenbfy9/5RKFTP/HY/+31Sb2Nnw+JO703nnnZfetnxZ4txEKI7KWMwo+9RRHtWLj37kj9K117wr1Sb6OHT/50sTYIZWFnzyXw1l/9cTIeDBk2ui0SDo9sFz050gGKcx5r5TIBr9Nlx3dbUXeen+z58AkKHVV65KJYoDfmoe/Kfrtgve/qe32iUwA1EJiFeOQaAb+K+/9qqiD/d5I1t37EzkTQDIUIln/8dsIE734zXRIPg3f/el9vY3ZwbMTBcEYlmgu6dhVOKSozVXXlb9wN/R/Jc/ASAzpTb/xWyg74f8zIVYEoh10vjZ9L3JbZTicxOvOE8/KitxNPPepuJ09Njcnj+/6KILm4rdieuiazy2+0wiiPm8508AyEzMIkoz6plZH8SlQrFe6j6B2enOD+gqKjELnZg80Hajz3ZNOkr78WezcsUlbaPuyhXL2wDAr9um/N8LAkBmSlz/9zA4OzFznWwGKH0Bg9NVBjacPFQrbpY8fOSl9ma6mKFOn6Ueav76grGxNNYM9CHCRDRpRuPhwoUXGOzPUryPzf77QQDIzMWFVQCUAs9N1xdw6803tmVlBisG9QVjJz5jSvZzI67xph8cBJSRKCuWti3M7P/cRV9AnB64dbsdE/TLs3uf1/zXIwJARkor+5r9z06EJ0cI0ye2+faLAJCRqACUxOx/9uK8gM/d9RVHCJO9CPxm//0iAGQkuopLEaVAs//BiIfq5/7hXiGArAn8/SMAZKSkLuPHn7Ttb5AiTEUIcLQqObLc108CQCa67UYlaC+9se9/4NoQ0CwH+NmSk6hMmf33kwCQiZLW/+MUNuZGd3KgHQLkwimf/SUAZKKk7X8CwNyLGZcQwKjF7F9Fqr8EgEyUVAF4dt9zibkXISCqAVEVgFGIvhT6SwDIxMXjZZwAGN3/ccwqwxGzr8/dZYcAw7dtu9J/3wkAmZg/dn4qwR6z/6Gb2H/ANkGGKt5rDv3pPwEgE6VsAXQQyGh0dwjov2AYlP7LIABkooQtgDErEABGxx0CDIPSfzkEAAZmj8E/C+4QYK5MTh5Q+i+IAMDA2A6Uj7hD4LN/+yV9AQxMvJe++OVvJMohAGSi7yU15f/8aA5kkKKqpPRfFgEgE33fy73VUaBZ6poDVWeYjVj312BaHgEgE32+5CVmmLue/nEiT44PZjZiOcm6f5kEgEz0ef/849/b7fCfHojmwC/e83VLApw1F/2UTQDIxO6n96Q+as8Cd/Vvb+xuyrj6Ajgbh09eQX3UUdPFEgAyEWXaPlYB3ATWP/Hn9def+UJ6pCntwul0g7/PdtkEgIw80ZTS+8RNYP324EM7nBfAr4nJSGz3M/iXTwDISHTZ9mk3gONA+y8avD7VVAMsCRDi+ROf64nJA4nyCQAZiQ9fX7bTOQ60HLYKEgz+9REAMhMzstx7AWKgsC2oLN1WwVgS6PuZFJw7g3+dBIAM3Xf/t7J9CEep+EHrxsVqjxD+O0cI18TgX683r71mw6cTWYkP5E9/9h9pzRWXpZx0ncE//dm/J8oV779Hv/Pd9vtVKy5JlCs+0//zC/ekgy/+W6I+AkCmupMBc3kA2xZUn7jbIV6rLl2exsbmJ8oSN/v9/T9+1We6YgJAxrrLdUYdAgz+9Tp85OW0+4d72gCwbHxJogzRx3PPff9HNa9yAkDmRh0CYmviXV/6qgdFxWJJIE4QjDBw8dLFqgE998A3t6eHtj2Sfn78eKJuAkAPjKIUGw/9h7b+c9vw50FBiGUp1YD+ikpe3AXx/R/8KEEQAHpimKXYPXufS3c1a4M/emZfgulUA/opPtOfb5bxDr54KEFn3m133PnLRK8sWnhh2rRxfbp67Zo0SPGQiJu/umUHeD3xPrz+2qvSe9avS+SpPVxs+2Ov7uqA6QSAHuuCQCwNLGy+n4l4QOx66pn2Rj8DPzMR78Pb//TWGb8HmRsR6O/72rc073JGAkAhVjYhIJYGVv7u8uaBfMEZlwliwH9h8kCabNZzo8Evvrruk0GIitTmJpAKAqMVa/1xomN8vuH1CAAFW9Csz47Nf22N9tARMwHm1lwtT/HGItzHFc/fbsr9Qj1nQwAABi6CwPtu2phWZ3aaZaliX3/07yj3cy7OSwADdujklrMIAO9vgoBlgblh4Gc2BABgzsSWwXjpDxicKPXHwB+d/QZ+ZkMAAOZcDFjxiiCw7t2rXTI0A9b4GTQBABiaLgjErpUIA5oF31hs54tDwJ5ofm4GfgZJEyAwMtEsGBWBa5ogYHngNV2ZP7byOZ+DuSIAAFnoqgJrrrisyiOGHcrFsFkCALLQXXp1b/N97B6IIDCbUy77YPqg71Auhk0AALLT7R4IURmIMDC+dHERzYOxpt+FHTN9RkkAALI2faCM0y1XNIEgKgMRCC4eX5L1ckF39Hb332CWT04EAKA3jp68jnj3tHPuly1d0iwTXHBiueCiC1/3Loy5EgN9/N6e3ft8e+R2vPbu/VfHb5M1AQDotYn9B9rX7lMuv1nUhIEIBvGK77u7MeLXof31tOpB9+tuMJ8uDtyZmnql/XtTx441A/vLzT8zlSYnX2z/moGePhIAgCJ1M/G0LwGn8aYEAFRHAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUKHzEvTQoosuTGNj56fx8cVpwdhY8+sLml/Pb76f335duPCCX/nnx+af+HtHp46lqWPHXv3rU/HrqVfa7w8dfql9TR175cTX5u9NTh5IR4+9kgBKIwCQtRjoV6z4nfbrooUXppUrlr86mM/EgrFT/rcXvfbtykuXn/Z/E6Fhcv/BNNGEgUNHXm6/CgZA3wkAZGPB/JjRL0mrVlzSDsbjSxfPeKAfpPg9xO/n1IAwsf9AEwYOpl1PP9MGgggHAH0hADBSMah2A/6ZZuC5WrZ0Sfu6eu2a9tcRCJ7d+3wbCJ7d93wCyJkAwFB1s/wYNFdfcVkWM/xB6QLBhvXr2mWD3U0QiDAQXwFyIwAwFDG7L3HQP5P4b4z/3nhFQ2FUBB7d+URTJTiYAHIgADBnYtBf0wz465pBsIZB/0yieTFeXRjYtmNn2v3UjzURAiM177Y77vxlggGJEv/qKy9vB7u+rekPU1cV2Lb9Mc2DwEioADAQMfBvuO7qdP21V1U92z9b06sCj39vlyAADJ0AwKzEATzR9FZ7mX82ul4BQQAYJgGAGYmBf9MN1726BY7ZEwSAYRIAOCdR6t/0+9enDU2pn7nR9U888eTutLUJAgBzQRMgZ8Ua/2h0uwaiKgDDEMduT3foyEuJMgkAvKGYjd56841t0xqjEfcP3H3P1y0LMFDdSZzLli5uL9Y6dfDvTL8Pw0mX5RAAOKOY9d/ywZvavfzkIQ4TipcgwEwN4nyO7qTLqEwJA/0lAHBa8YC4pZn1K/fnx7IAMxED/+Ybrhv4+Rzej/0lAPArNPn1R8zAHvjmdtUAXld8pt/7hzfM+Y4d78f+EQB4VWzt+8Rtf2Ktv2di9mW3AKczikregw/tSI80y1Tk781rr9nw6UT1Ynaw5cMfSBf81m8k+qW7aClmYFPuF+Ck9zWz/vfdtDG95S3D3e399ssvbQPHj57Zl8ibAEDadMP65kFxw9AfFAxOPHDjRMZ58+ZpyqpclPw/tuWP07ve+Y40Km9bviytufKy9P0f/DAdP/6LRJ4EgIrFg+Lm929O77l2XaIMqgF1i890LOPFADxqv/Wbv9H+PjQH5ksAqFSs939sy4eact2KRFlUA+rUDf7LxpekXEQ/keWAfAkAFeqa/ZYsfmuiXO1+76YM+y8/3qcaUIEo++cw8z9V/J6ONe+/nzw/mcjLmxJV0elfl2VLl6RP/vkWlzYVLhr+Br2/f5A2bVzfPnvIiwpARQz+dYrmztgOFn/uk5MHVAMKE8s9m5sBNmfxHhxrlgKiN4V8qABUwuBPVAHaNeKlixNlaK/lznzw73S3XJIPAaACBn868R6IJYE4Epb+u/WDN/XquG73iuRFAChc1xls8Ge6mDXeHu8L67K91ccZdfyex8bOT+RBACicwZ8zicEj3h+rzcp6p0+l/+miD2D1Oy5P5EEAKFh0Bue0J5j8RDj86Ic/YEmgZ9Zdtaa3wX7VCn0AuRAAChXH+7rRj7NlSaA/4s9o88b+BjaNgPkQAArU3vvd4wcEo9EtCdglkLfr1/f76O6oXOgDyIMAUJiYHdx6840JZsIugfyV0Em/YP5YYvQEgMLElb6a/pitWBKIq2TN1PISXfQlfL4XLrTUlAMBoCCx7q/pj0GJE+Y+eccWfQEZWbd2dYJBEQAKYd2fuRCzTVsF8xBBbNWllyQYFAGgANb9mUu2CuZh5YpLUimmpo4lRu+8RO9tah7M1v2Za9EXMDb//LR1x2PNA9yFQsNWUvn/0JGXEqOnAtBz0RTkqleGRV/AaMQJeqWU/2P2L0DmQQDosTjnv4/HgdJvXV+A8wKGp6TDcyYmDybyIAD02Kbfv17pn5Hozgt4T88PpemLkm7Rmzpm/T8XAkBPRQnWUb+M2ntv2qg5cAhKCgAvTB5I5EEA6KktH/mjBDmIZajYJeDQoLlx4grd+akUE/stAeRCAOiheCBYfyUncU6A5sC5UdrhP4cP2wGQCwGghzT+kSPNgYNX4uE/KgD5EAB6ppSzwCmT5sDB2lRYf8WE9f+sCAA9ErMBs3/6QHPg7MXnvbQzPg4feTmRDwGgR+IoULN/+iLC6u3NkoC+gJkpbfYf9ux9LpEPAaBHzP7pmzjA5hNCwDkrcfYfrP/nxV0APWHt/+wdOvxSe9xonDgWh44cPXnxyNSxV5rvp5qH62s/x/g+7iZfMDbfVcpzpOsLeOChHenx7+1KvLESZ//h2X3PJ/IhAPSE2f/pxUC/66ln0sT/O9g2GE02M4yjs7hpbNnSJW0gWNXMXMeXLk6rCrqBbZRiH3vcWBlhYOv2xxJnVurs/9m9Bv/cCAA9EHuszf5fEwP9rqefaWcTg55RTOw/0L52N//+EJWB+Pmvfsdlac2V5ZzGNioRZGOb4APf3J4OaQg7rVgyKVF8rsiLANADG9Y78jdm+lE+7gb+YTl68v83Xl0Y2NwMYgsFshmLn2FUVz5/11eEgFNsumF9sWF/j/J/dgSAzJV4EMi5iIH/kZ1PpG9/57uzKu0PwvQwEM1tG65dpyowQzHI3flXH08PPrSj/fPlxHn/mzeWu3Xy2X3PJfIiAGTu+ooPVIm14hwG/tPplh9iILvlj/5Ar8AMxXkBC5uQu3XHY1XfER9BP34WpYr1/5r/fHMlAGSupFvAzlbsFb7va99qu/lzF7/Hz//DvW3TlqWBmdnQhNxYFqh1SWDB/PNPbJUs+L1j/T9Pb157zYZPJ7IUZeaajlSNcv9DW/853f/gP7Xf90nsb360qVYE1YBzF/0VEaKOH/9F+snzk6kmf/Hxj6Qli9+aSvbQ1kecApghFYCMlbgV6EzihrDPNTPpPsz6X8+2HTvTE0/uTrfc/AdV927MRGwVjDJ4NAg+8ND2KkrGt37wxuLPn4jPtv3/eXISYMaiAlCDaKr77N99qfeDf6ddFrjr3vbgm75VMnIQwbf0q4Wj7L/lwx9IV7+7/JCv+z9flgAyVUv5f9v2ne1A+fPjx1NpnmtK2d//wY/aPo6Y3XL2YkkgegPmzZtX3Owxgs3HtnyomqWi+Hwr/+dJBSBTNZT/Y/CP7u+SRTXgrz/zBaffzVAcHHTnX/5ZMdWAOAQpGv5qOXZa+T9vAkCmSi//1zD4Txe9AZ9qgsDhQpY5hqk7M6Dv1wtHRaP0bv9TKf/nTQDIUMwSSn5I1Db4dw6dbHR0Ic7M9LUaEL/fuBb5fTdtbJc2auK9njc9ABl61zuvSG+//NJUoloH/040BXb3DNgueO663oAIyJOTB9obHnMVjX4bf+8/p1tuvjEt+e2yt/mdTlS7Yv2ffNkGmKHVV65KJYoHds2D/3TddsHb//RWhwfNQPTIxCtmmNu2P5bVAUIx8G+47up0/bVXVTfjn25r8x4nbwJAhi5eWl6DUMwGvvjlbyRe0y0JODNg5qYHgXiNsuHMwP+rNP/lTwDITDT/lbhlLGYDpezzH6TuzIBY3+57k9sodUHg0Mmu82GFgRj01131znarZy3ndpyN+Pn7vOdPAMjMsgJn/93sjDOLJYHYKx2NYs4MmLnoDYhXhIG4RGpvEwKiE32iWX6KJaijs+wZWHTRhWnFit9pq3QrVywv8vM6CNuU/3tBAMjMqhXlzSI8DM5ON2vVFzAYUYaPS4ZWT7tQK0LB5P6DbTPmC5MnLqg5dOSl0/xvx9JYM7uPMBH/nvHxxc2v5yvtn4W4+c/svx8EgMyUVkZUCjw3XV9AHBMb20EZrBjAu8/Y6gpv2hwGjb794RyAjMR+4dLKv2b/5y5CwGf/9u70yM4nEvRJzP41//WHAJCR8cKOBzX7n50HH9rhCGF6xey/XwSAjJRW8jX7n734GX7xnq+7VZDsmf33jwCQkZUFNQBqBBqcODkwrkt2jwA5u/drDyf6RQDIyIL55az/P/6kbX+D1DUHCgHkyHJfPwkAmYjmv1KuCI1ytX3/gxcP2L9pKgF79j2XIBfxebfc108CQCZKWv/fdfKyGwYvHrZxcqAdAuTi0Z3fNfvvKQEgEyVt/9MINPfsECAHsSSl87+/BIBMlFUB+HFi7kXZ1XWrjFL0pdBfAkAmLi5k/T+6/6em8r2jvTSPNksBn/1bOwQYvnjvKf33mwCQiflj56cSTOw/kBiu+JnbIcAwxXtN41//CQCZiFvGSqABcDS6bYIT+w8mmGtfuf/h9mIl+k0AyMSiAm5/iw51DYCj4w4BhmHb9p0+54UQABgYs/882CHAXNH1XxYBgIFx+E8+3CHAoB0+ucxEOQSATPS9mzYeDsqCeXGHAIO0tQmVuv7LIgBkou8zta06grPUNQdanmE2Yt1fha88AkAm+ty9bfaftwgBdzfLAfoCmIkIj9b9yyQAZGJisr8B4PHv7VYa7IHoC7j3/of1BXDWItzfd79rfkslAGRi9w/7WaKNB4Srf/sjyrj6AjgbXdOf/f7lEgAyETPoPl7zqjGof7prha3pciZRJYrB32e7bAJARnY/tSf1STv7N4j0UjzgYzlAXwCnMvjXQwDISJTS+7Q+a09w/0VfgMuEmO6Bb+5IE5Pu9KiBAJCRGPz7sp0utgWZIZShu0xINYd7v/qwnp6KCACZiSs2c98SaFtQeSLMWRKoV7skZPCvjgCQofgg5sq2oLLFksCnPvMFSwIV6db8Df71efPaazZ8OpGVn/7s39PUsVfS2y+/NOWk2xYUvz/KFQPC40/uTuedd1562/JliXLFZ/rv//Gr1vwrJQBk6rnnJ9uvq1ZcknLQDf7W/etw/Pjx9C/P7EuHj7ycLl66OI2NzU+UpftMH3zx3xJ1EgAy1h2vO+oQYPCvV/Sj7P7hnjYALBtfkijDnr3Ppc+r5lVPAMjcqEOABwWxJBA3C6oGlCF28Nz7tYfTz5sqD3UTAHogQkDMxH53+fhQH74PfHN7uv/Bf/KgoKUa0G8R5P7+S/9bsx+vEgB64uCLh4b28I1Z/91f/kY764PpVAP6KT7Td0WzX49vHWXw5t12x52/TPTKykuXp00b1w98WSDW+uMgIgfCcDYWLbywfR9evXZNIk/t4WLbH0uPfue7CU4lAPRYBIF4+K654rJZzcRidhD7v7t+AzgXq5v33/tv2pgWNoGAfMTn+r6vfUvzLmckABQiwkAEgfGmLHtxs0RwpkAQM4J4IMRg/8L+A+mpp/e47pOBiGrA5huuS4yWWT9nSwAo1IImAIzNn9/Myi5of3348Mvt10NHzAaYO5YFRiuOEo9qnlDP2RAAgIGLRtWP/vf3WxYYEuV+ZkIAAOZMVAI2NxUBQWBu6N9hNs5LAHMkdpTESxAYLAM/gyAAAHNOEJi9aO57pFnjf+LJ3Ur9DIQAAAxNFwRi6+CGa6/K5rKrnMVNfXE74xPNz01zH4MkAABDF6cJxqvbNbDq0uWqAtO0VzI3A/6u5mekzM9cEQCAkYlS9r33P9x+H1WBq9+9Jq258rJUq1jbj7P6nc/BMAgAQBa6qkCcYRFhYPU7Lis+DMRM/4W2xG/QZ/gEACArR0+Wv7s7Kbojr5ctXVzELYSxph9l/SjvT+4/aNBnZAQAIGsxWHbr4NEzEMddx7HXfQgEjt4mZwIA0BsxmMZr+lXVUSGIILDoogve8C6Muf69TUweTIePvNQO9pOTL6aJ5ivkSgAAem16haATfQQLL7qwvQsjqgZj889vAsKFr96N0d6VcTIkLHqd3QfT99vH91NTr5yY1TeDfLzi15PNoD917JiZPb0jAADFicH46NQBM3B4HW9KAEB1BAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQIQEAACokAABAhQQAAKiQAAAAFRIAAKBCAgAAVEgAAIAKCQAAUCEBAAAqJAAAQIUEAACokAAAABUSAACgQgIAAFRIAACACgkAAFAhAQAAKiQAAECFBAAAqJAAAAAVEgAAoEICAABUSAAAgAoJAABQof8PHli4CZ+4iOUAAAAASUVORK5CYII="
    ]; });
    return [NSURL URLWithString:[@"data:image/png;base64," stringByAppendingString:b64[idx % 6]]];
}

#pragma mark - URL conversion

static BOOL FXHostIs(NSString *h, NSString *d) {
    return [h isEqualToString:d] || [h hasSuffix:[@"." stringByAppendingString:d]];
}

static NSURL *FXBuild(NSString *base, NSString *suffix, NSString *query) {
    if (!base.length) return nil;
    NSURLComponents *c = [NSURLComponents componentsWithString:base];
    if (!c) return nil;
    NSString *bp = c.percentEncodedPath ?: @"";
    while ([bp hasSuffix:@"/"]) bp = [bp substringToIndex:bp.length - 1];
    c.percentEncodedPath = [bp stringByAppendingString:suffix ?: @""];
    c.percentEncodedQuery = query.length ? query : nil;
    c.fragment = nil;
    return c.URL;
}

static NSString *FXFilterQuery(NSString *q, NSSet *allowed) {
    if (!q.length) return nil;
    NSMutableArray *keep = [NSMutableArray array];
    for (NSString *pair in [q componentsSeparatedByString:@"&"]) {
        NSString *k = [[[pair componentsSeparatedByString:@"="] firstObject] lowercaseString];
        if ([allowed containsObject:k]) [keep addObject:pair];
    }
    return keep.count ? [keep componentsJoinedByString:@"&"] : nil;
}

static NSURL *FXGatewayURL(NSURL *orig) {
    if (!gGateway.length) return nil;
    NSURLComponents *c = [NSURLComponents componentsWithString:gGateway];
    if (!c) return nil;
    NSString *wantCompress = nil;
    for (NSURLQueryItem *i in [NSURLComponents componentsWithURL:orig resolvingAgainstBaseURL:NO].queryItems ?: @[])
        if ([i.name isEqualToString:@"compress"]) wantCompress = i.value;
    BOOL keepZstd = gKeepZstd && [wantCompress isEqualToString:@"zstd-stream"];
    NSMutableArray *items = [NSMutableArray array];
    for (NSURLQueryItem *i in c.queryItems ?: @[]) {
        if (![@[@"v", @"encoding", @"compress", @"stream"] containsObject:i.name]) [items addObject:i];
    }
    [items addObject:[NSURLQueryItem queryItemWithName:@"v" value:@"1"]];
    [items addObject:[NSURLQueryItem queryItemWithName:@"encoding" value:@"json"]];
    // Fluxer supports compress=zstd-stream or none (zlib-stream is not supported). The app decides how to
    // decode inbound frames from what IT asked for, so only drop compression when it asked for something else.
    if (keepZstd) [items addObject:[NSURLQueryItem queryItemWithName:@"compress" value:@"zstd-stream"]];
    c.queryItems = items;
    FXFileLog(@"gateway: app asked %@ -> %@", orig.absoluteString, c.URL.absoluteString);
    return c.URL;
}

static void FXInitBadgeURLRegistry(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gBadgeURLLock = [NSObject new];
        gBadgeURLInfo = [NSMutableDictionary dictionary];
    });
}

static NSString *FXRegisterCustomBadgeURL(NSString *badgeKey, NSString *assetURL) {
    if (![assetURL isKindOfClass:NSString.class] || !assetURL.length) return nil;
    NSURLComponents *u = [NSURLComponents componentsWithString:assetURL];
    if (![u.scheme.lowercaseString isEqualToString:@"https"] || !u.host.length) return nil;
    NSString *seed = [NSString stringWithFormat:@"%@|%@", badgeKey ?: @"badge", assetURL];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(seed.UTF8String, (CC_LONG)strlen(seed.UTF8String), digest);
    NSMutableString *token = [NSMutableString stringWithString:@"fxcustom_"];
    for (NSUInteger i = 0; i < 12; i++) [token appendFormat:@"%02x", digest[i]];
    FXInitBadgeURLRegistry();
    @synchronized (gBadgeURLLock) {
        gBadgeURLInfo[token] = assetURL;
        if (gBadgeURLInfo.count > 512) [gBadgeURLInfo removeObjectForKey:gBadgeURLInfo.allKeys.firstObject];
    }
    return token;
}

static NSURL *FXBadgeImageURL(NSString *iconKey, NSString *query) {
    if (!iconKey.length) return nil;
    FXInitBadgeURLRegistry();
    NSString *custom = nil;
    @synchronized (gBadgeURLLock) { custom = gBadgeURLInfo[iconKey]; }
    if (custom.length) {
        if (!gStatic.length) return nil;
        NSURLComponents *c = [NSURLComponents componentsWithURL:FXBuild(gStatic, [NSString stringWithFormat:@"/badges/%@.svg", iconKey], nil) resolvingAgainstBaseURL:NO];
        if (query.length) c.percentEncodedQuery = query;
        return c.URL;
    }
    if (!gStatic.length) return nil;
    NSCharacterSet *hex = [NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdefABCDEF"];
    if ([iconKey rangeOfCharacterFromSet:hex.invertedSet].location != NSNotFound) return nil;
    return FXBuild(gStatic, [NSString stringWithFormat:@"/badges/%@.svg", iconKey], query);
}

static NSURL *FXMediaURL(NSURLComponents *o) {
    static NSSet *assets, *allowedQuery;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        assets = [NSSet setWithArray:@[@"avatars", @"icons", @"banners", @"splashes", @"role-icons",
                                       @"emojis", @"stickers", @"guilds", @"attachments", @"external"]];
        allowedQuery = [NSSet setWithArray:@[@"size", @"animated", @"format", @"fmt", @"width", @"height",
                                             @"quality", @"download", @"effort", @"ex", @"is", @"hm", @"uc"]];
    });
    NSString *p = o.percentEncodedPath ?: @"";
    if ([p hasPrefix:@"/badge-icons/"]) {
        NSString *icon = [[p lastPathComponent] stringByDeletingPathExtension];
        NSURL *badgeURL = FXBadgeImageURL(icon, FXFilterQuery(o.percentEncodedQuery, allowedQuery));
        if (badgeURL) return badgeURL;
    }
    if ([p hasPrefix:@"/embed/avatars/"]) {                // Discord default avatars
        NSInteger n = [[p lastPathComponent] integerValue];   // "3.png" -> 3
        return FXDefaultAvatarURL((NSUInteger)MAX(n, 0));       // served locally, no network
    }
    NSArray *seg = [p componentsSeparatedByString:@"/"];
    NSString *first = seg.count > 1 ? seg[1] : @"";
    if (![assets containsObject:first]) return nil;
    return FXBuild(gMedia, p, FXFilterQuery(o.percentEncodedQuery, allowedQuery));
}

static NSURL *FXWebURL(NSURLComponents *o) {
    static NSRegularExpression *apiRe;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        apiRe = [NSRegularExpression regularExpressionWithPattern:@"^/api(?:/v[0-9]+)?(/.*)?$" options:0 error:nil];
    });
    NSString *p = o.percentEncodedPath ?: @"";
    NSTextCheckingResult *m = [apiRe firstMatchInString:p options:0 range:NSMakeRange(0, p.length)];
    if (m) {
        NSRange r = [m rangeAtIndex:1];
        NSString *rest = r.location == NSNotFound ? @"" : [p substringWithRange:r];
        return FXBuild(gAPI, [@"/v1" stringByAppendingString:rest], o.percentEncodedQuery);
    }
    if ([p hasPrefix:@"/invite/"]) {
        NSString *code = [p substringFromIndex:8];
        return FXBuild(gInvite, [@"/" stringByAppendingString:code], nil);
    }
    for (NSString *pre in @[@"/channels", @"/login", @"/register", @"/app"]) {
        if ([p isEqualToString:pre] || [p hasPrefix:[pre stringByAppendingString:@"/"]])
            return FXBuild(gWebapp, p, o.percentEncodedQuery);
    }
    return nil;
}

// block == YES: unmapped Discord hosts get sent nowhere instead of leaking to Discord.
static NSURL *FXRewriteURLInner(NSURL *url, BOOL block) {
    NSString *host = url.host.lowercaseString;
    if (!host.length) return nil;
    BOOL discordish = FXHostIs(host, @"discord.com") || FXHostIs(host, @"discordapp.com") ||
                      FXHostIs(host, @"discordapp.net") || FXHostIs(host, @"discord.gg") ||
                      FXHostIs(host, @"discord.media") || FXHostIs(host, @"discord.gift") ||
                      FXHostIs(host, @"dis.gd") || FXHostIs(host, @"discordstatus.com");
    if (!discordish) return nil;
    FXEnsureResolved();

    NSString *scheme = url.scheme.lowercaseString;
    NSURLComponents *o = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
    NSURL *out = nil;
    if ([scheme isEqualToString:@"ws"] || [scheme isEqualToString:@"wss"]) {
        out = FXGatewayURL(url);
    } else if (FXHostIs(host, @"discordapp.net") || [host isEqualToString:@"cdn.discordapp.com"]) {
        out = FXMediaURL(o);
    } else if ([host isEqualToString:@"discord.gg"] || [host isEqualToString:@"www.discord.gg"]) {
        NSString *code = o.percentEncodedPath ?: @"";
        if (code.length > 1) out = FXBuild(gInvite, code, nil);
    } else if (FXHostIs(host, @"discord.com") || FXHostIs(host, @"discordapp.com")) {
        out = FXWebURL(o);
    }
    FXLog(@"%@ -> %@", url.absoluteString, out.absoluteString ?: (block ? @"(blocked)" : @"(unchanged)"));
    if (out) return out;
    return block && gBlockUnmapped ? [NSURL URLWithString:@"https://discord-blocked.invalid/"] : nil;
}

static NSURL *FXRewriteURL(NSURL *url, BOOL block) {
    @try { return FXRewriteURLInner(url, block); }
    @catch (NSException *e) { FXFileLog(@"rewrite exception for %@: %@", url, e); return nil; }
}

#pragma mark - Captcha: Fluxer ALTCHA (PBKDF2/SHA-256) proof of work
// Fluxer gates login/register/forgot/recover behind an ALTCHA challenge: the request must carry
// X-Captcha-Token = base64(JSON{challenge:{parameters,signature}, solution:{counter,derivedKey}}).
// The Discord app can't produce that, so before such a request leaves the device we fetch a
// challenge, solve it natively and attach the header. Nothing from the request body is logged.

static NSObject *gCaptchaLock;
static int gAltchaVariant = -2;   // -2 = not detected yet, -1 = no variant accepted, >=0 = working variant

static NSData *FXHexData(NSString *hex) {
    if (![hex isKindOfClass:NSString.class] || hex.length % 2) return nil;
    NSMutableData *d = [NSMutableData dataWithCapacity:hex.length / 2];
    for (NSUInteger i = 0; i < hex.length; i += 2) {
        unsigned v = 0;
        if (![[NSScanner scannerWithString:[hex substringWithRange:NSMakeRange(i, 2)]] scanHexInt:&v]) return nil;
        uint8_t b = (uint8_t)v; [d appendBytes:&b length:1];
    }
    return d;
}

// Bytes fed to PBKDF2 as the "password" for a given counter. Variant 0 is what altcha-lib v2 is
// expected to use (nonce || counter as 4-byte big-endian); the others are fallbacks that are only
// tried if the server rejects variant 0 (see FXObtainCaptchaToken).
static size_t FXBuildPassword(uint8_t *buf, NSData *nonce, long c, int variant) {
    size_t n = nonce.length;
    uint32_t u = (uint32_t)c;
    switch (variant) {
        case 0: memcpy(buf, nonce.bytes, n);
                buf[n] = u >> 24; buf[n+1] = u >> 16; buf[n+2] = u >> 8; buf[n+3] = u; return n + 4;
        case 1: memcpy(buf, nonce.bytes, n);
                buf[n] = u; buf[n+1] = u >> 8; buf[n+2] = u >> 16; buf[n+3] = u >> 24; return n + 4;
        case 2: memcpy(buf, nonce.bytes, n);
                return n + (size_t)snprintf((char *)buf + n, 16, "%ld", c);
        default: buf[0] = u >> 24; buf[1] = u >> 16; buf[2] = u >> 8; buf[3] = u;
                memcpy(buf + 4, nonce.bytes, n); return n + 4;
    }
}

// Brute-forces the counter on all cores. Returns the derived key (hex) and the counter, or nil.
static NSString *FXSolveAltcha(NSDictionary *p, int variant, long *outCounter) {
    NSData *nonce = FXHexData(p[@"nonce"]), *salt = FXHexData(p[@"salt"]);
    NSString *prefix = [p[@"keyPrefix"] isKindOfClass:NSString.class] ? [p[@"keyPrefix"] lowercaseString] : nil;
    NSUInteger cost = [p[@"cost"] isKindOfClass:NSNumber.class] ? [p[@"cost"] unsignedIntegerValue] : 0;
    NSUInteger keyLen = [p[@"keyLength"] isKindOfClass:NSNumber.class] ? [p[@"keyLength"] unsignedIntegerValue] : 0;
    if (![p[@"algorithm"] isEqual:@"PBKDF2/SHA-256"] || !nonce || !salt || !prefix ||
        cost < 1 || cost > 1000000 || keyLen < 1 || keyLen > 128 || prefix.length > keyLen * 2) return nil;

    unsigned workers = (unsigned)MIN(MAX(NSProcessInfo.processInfo.activeProcessorCount, 1), 6);
    const long kMaxCounter = 1000000;
    const CFAbsoluteTime deadline = CFAbsoluteTimeGetCurrent() + 90;
    const char *pref = prefix.UTF8String;
    const size_t prefLen = prefix.length;
    atomic_long *found = malloc(sizeof(atomic_long));
    atomic_init(found, -1);
    __block NSString *foundKey = nil;
    NSObject *lock = [NSObject new];

    dispatch_apply(workers, dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^(size_t w) {
        uint8_t *pw = malloc(nonce.length + 16);
        uint8_t out[128];
        char hex[257];
        for (long c = (long)w; atomic_load(found) < 0 && c < kMaxCounter; c += workers) {
            if ((c & 31) == 0 && CFAbsoluteTimeGetCurrent() > deadline) break;
            size_t pl = FXBuildPassword(pw, nonce, c, variant);
            if (CCKeyDerivationPBKDF(kCCPBKDF2, (const char *)pw, pl, salt.bytes, salt.length,
                                     kCCPRFHmacAlgSHA256, (unsigned)cost, out, keyLen) != 0) break;
            for (size_t i = 0; i < keyLen; i++) snprintf(hex + i * 2, 3, "%02x", out[i]);
            if (strncmp(hex, pref, prefLen) == 0) {
                @synchronized (lock) {
                    if (atomic_load(found) < 0) { foundKey = [NSString stringWithUTF8String:hex]; atomic_store(found, c); }
                }
                break;
            }
        }
        free(pw);
    });
    long c = atomic_load(found);
    free(found);
    if (c < 0 || !foundKey) return nil;
    if (outCounter) *outCounter = c;
    return foundKey;
}

// The raw "parameters":{...} text exactly as the server sent it. The token must carry the
// parameters unchanged (the signature covers them), so we don't re-serialize the dictionary.
static NSString *FXRawParameters(NSString *raw) {
    NSRange a = [raw rangeOfString:@"\"altcha_challenge\""];
    if (a.location == NSNotFound) return nil;
    NSUInteger from = NSMaxRange(a);
    NSRange p = [raw rangeOfString:@"\"parameters\"" options:0 range:NSMakeRange(from, raw.length - from)];
    if (p.location == NSNotFound) return nil;
    NSUInteger i = NSMaxRange(p);
    while (i < raw.length && [raw characterAtIndex:i] != '{') i++;
    if (i >= raw.length) return nil;
    NSUInteger start = i; int depth = 0; BOOL inStr = NO;
    for (; i < raw.length; i++) {
        unichar ch = [raw characterAtIndex:i];
        if (inStr) { if (ch == '\\') i++; else if (ch == '"') inStr = NO; continue; }
        if (ch == '"') inStr = YES;
        else if (ch == '{') depth++;
        else if (ch == '}' && --depth == 0) return [raw substringWithRange:NSMakeRange(start, i - start + 1)];
    }
    return nil;
}

// Blocking JSON POST on a private session. Returns the HTTP status (0 on failure).
static NSInteger FXSyncPost(NSURL *url, NSString *body, NSString *token, NSString **outBody) {
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:url];
    r.HTTPMethod = @"POST";
    r.timeoutInterval = 10;
    [r setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    if (token) [r setValue:token forHTTPHeaderField:@"X-Captcha-Token"];
    r.HTTPBody = [body dataUsingEncoding:NSUTF8StringEncoding];
    NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    cfg.timeoutIntervalForRequest = 10;
    NSURLSession *s = [NSURLSession sessionWithConfiguration:cfg];
    __block NSInteger status = 0;
    __block NSString *text = nil;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    [[s dataTaskWithRequest:r completionHandler:^(NSData *data, NSURLResponse *resp, NSError *e) {
        if ([resp isKindOfClass:NSHTTPURLResponse.class]) status = ((NSHTTPURLResponse *)resp).statusCode;
        if (data) text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        dispatch_semaphore_signal(sem);
    }] resume];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 15 * NSEC_PER_SEC));
    [s invalidateAndCancel];
    if (outBody) *outBody = text;
    return status;
}

@interface FXChallenge : NSObject
@property (nonatomic, strong) NSDictionary *params;
@property (nonatomic, copy) NSString *rawParams, *signature;
@property (nonatomic) BOOL invalid;
@end
@implementation FXChallenge
@end

// Parses a 400 CAPTCHA_REQUIRED / INVALID_CAPTCHA reply. Returns nil if it holds no challenge.
static FXChallenge *FXParseChallenge(NSInteger status, NSString *raw) {
    if (status != 400 || !raw.length) return nil;
    id j = [NSJSONSerialization JSONObjectWithData:[raw dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    if (![j isKindOfClass:NSDictionary.class]) return nil;
    NSString *code = j[@"code"];
    if (![code isEqual:@"CAPTCHA_REQUIRED"] && ![code isEqual:@"INVALID_CAPTCHA"]) return nil;
    NSDictionary *ch = j[@"altcha_challenge"];
    if (![ch isKindOfClass:NSDictionary.class] || ![ch[@"parameters"] isKindOfClass:NSDictionary.class] ||
        ![ch[@"signature"] isKindOfClass:NSString.class]) return nil;
    NSString *rp = FXRawParameters(raw);
    if (!rp) return nil;
    FXChallenge *c = [FXChallenge new];
    c.params = ch[@"parameters"]; c.rawParams = rp; c.signature = ch[@"signature"];
    c.invalid = [code isEqual:@"INVALID_CAPTCHA"];
    return c;
}

static NSString *FXMakeToken(FXChallenge *c, int variant) {
    CFAbsoluteTime t0 = CFAbsoluteTimeGetCurrent();
    long counter = 0;
    NSString *key = FXSolveAltcha(c.params, variant, &counter);
    if (!key) return nil;
    long ms = (long)((CFAbsoluteTimeGetCurrent() - t0) * 1000);
    NSString *json = [NSString stringWithFormat:
        @"{\"challenge\":{\"parameters\":%@,\"signature\":\"%@\"},\"solution\":{\"counter\":%ld,\"derivedKey\":\"%@\",\"time\":%ld}}",
        c.rawParams, c.signature, counter, key, ms];
    NSString *tok = [[json dataUsingEncoding:NSUTF8StringEncoding] base64EncodedStringWithOptions:0];
    FXFileLog(@"captcha solved variant=%d cost=%@ counter=%ld in %ldms", variant, c.params[@"cost"], counter, ms);
    return tok.length <= 4096 ? tok : nil;
}

static FXChallenge *FXFetchChallenge(NSURL *probe, NSInteger *statusOut) {
    NSString *body = nil;
    NSInteger st = FXSyncPost(probe, @"{}", nil, &body);   // captcha is checked before the body is validated
    if (statusOut) *statusOut = st;
    return FXParseChallenge(st, body);
}

// Returns a solved token for the endpoint, or nil (captcha off, rate limited, unsolvable...).
// The first time, the PBKDF2 input layout is verified against the server: a wrong layout is answered
// with INVALID_CAPTCHA plus a fresh challenge, so the next layout is tried until one is accepted.
static NSString *FXObtainCaptchaToken(NSURL *probe) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{ gCaptchaLock = [NSObject new]; });
    NSInteger st = 0;
    FXChallenge *ch = FXFetchChallenge(probe, &st);
    if (!ch) {
        FXFileLog(@"captcha: no challenge from probe (HTTP %ld), sending request without token", (long)st);
        return nil;
    }
    @synchronized (gCaptchaLock) {
        if (gAltchaVariant == -2) {
            for (int v = 0; v < 4 && gAltchaVariant == -2 && ch; v++) {
                NSString *tok = FXMakeToken(ch, v);
                if (!tok) continue;
                NSString *body = nil;
                NSInteger rs = FXSyncPost(probe, @"{}", tok, &body);
                FXChallenge *next = FXParseChallenge(rs, body);
                if (next) {
                    if (!next.invalid) { FXFileLog(@"captcha: probe asked for a token again, giving up detection"); return nil; }
                    FXFileLog(@"captcha: variant %d rejected by server", v);
                    ch = next;                                  // rejected: try the next layout
                } else if (rs == 0 || rs == 429 || rs >= 500) {
                    FXFileLog(@"captcha: variant check inconclusive (HTTP %ld)", (long)rs);
                    return nil;                                 // try again on the next request
                } else {
                    gAltchaVariant = v;                         // accepted (the {} body then failed validation)
                    FXFileLog(@"captcha: variant %d accepted", v);
                }
            }
            if (gAltchaVariant == -2) { gAltchaVariant = -1; FXFileLog(@"captcha: no PBKDF2 layout was accepted"); }
            if (gAltchaVariant >= 0) ch = FXFetchChallenge(probe, &st);   // detection spent its challenge
        }
    }
    if (gAltchaVariant < 0 || !ch) return nil;
    return FXMakeToken(ch, gAltchaVariant);
}

// Adds X-Captcha-Token to Fluxer's captcha-gated POST endpoints (called on already rewritten requests).
static void FXAttachCaptcha(NSMutableURLRequest *m) {
    if (!gSolveCaptcha || ![m.HTTPMethod.uppercaseString isEqualToString:@"POST"]) return;
    if ([m valueForHTTPHeaderField:@"X-Captcha-Token"].length) return;
    NSString *path = m.URL.path ?: @"";
    NSURL *probe = nil;
    if ([path hasSuffix:@"/v1/auth/login"] || [path hasSuffix:@"/v1/auth/forgot"] || [path hasSuffix:@"/v1/auth/recover"]) {
        NSURLComponents *pc = [NSURLComponents componentsWithURL:m.URL resolvingAgainstBaseURL:NO];
        pc.query = nil; pc.fragment = nil; probe = pc.URL;
    } else if ([path hasSuffix:@"/v1/auth/register"] || [path hasSuffix:@"/v1/auth/register/handoff"]) {
        // Register validates its body before the captcha, so a bare probe can't get a challenge from it;
        // forgot-password hands out an equivalent one.
        probe = FXBuild(gAPI, @"/v1/auth/forgot", nil);
    }
    if (!probe) return;
    FXFileLog(@"captcha: solving for %@", [path lastPathComponent]);
    NSString *tok = FXObtainCaptchaToken(probe);
    if (tok) [m setValue:tok forHTTPHeaderField:@"X-Captcha-Token"];
}

// SocketRocket-style handshakes send no User-Agent; some servers reject that.
static NSString *FXUA(void) {
    static NSString *ua; static dispatch_once_t o;
    dispatch_once(&o, ^{
        NSString *build = NSBundle.mainBundle.infoDictionary[@"CFBundleVersion"] ?: @"1";
        NSString *cfn = [NSBundle bundleWithIdentifier:@"com.apple.CFNetwork"].infoDictionary[@"CFBundleVersion"] ?: @"1494.0.7";
        struct utsname u; uname(&u);
        ua = [NSString stringWithFormat:@"Discord/%@ CFNetwork/%@ Darwin/%s", build, cfn, u.release];
    });
    return ua;
}

static BOOL FXIsWSScheme(NSURL *u) {
    NSString *sc = u.scheme.lowercaseString;
    return [sc isEqualToString:@"ws"] || [sc isEqualToString:@"wss"];
}

static NSURLRequest *FXRewriteRequest(NSURLRequest *req) {
    NSDictionary *uploadInfo = FXUploadInfoForURL(req.URL);
    NSString *method = req.HTTPMethod.uppercaseString ?: @"GET";
    if ([method isEqualToString:@"PUT"] || uploadInfo) {
        NSString *host = req.URL.host.lowercaseString ?: @"-";
        NSString *ct = [req valueForHTTPHeaderField:@"Content-Type"] ?: @"-";
        NSRange semi = [ct rangeOfString:@";"];
        if (semi.location != NSNotFound) ct = [ct substringToIndex:semi.location];
        FXFileLog(@"upload transport request method=%@ host=%@ signed_destination=%@ content_type=%@ body_bytes=%lu body_stream=%@",
                  method, host, uploadInfo ? @"yes" : @"no", ct,
                  (unsigned long)req.HTTPBody.length, req.HTTPBodyStream ? @"yes" : @"no");
    }
    NSURL *n = FXRewriteURL(req.URL, YES);
    NSURL *eff = n ?: req.URL;
    BOOL needUploadHeaders = uploadInfo != nil;
    BOOL needUA = NO;
    if (FXIsWSScheme(eff) && ![req valueForHTTPHeaderField:@"User-Agent"].length && gGateway.length) {
        NSString *gh = [NSURLComponents componentsWithString:gGateway].host.lowercaseString;
        needUA = gh.length && [eff.host.lowercaseString isEqualToString:gh];
    }
    if (!n && !needUA && !needUploadHeaders) return req;
    NSMutableURLRequest *m = [req mutableCopy];
    if (n) m.URL = n;
    for (NSString *h in @[@"Origin", @"Referer"]) {
        NSString *v = [m valueForHTTPHeaderField:h].lowercaseString;
        if ([v containsString:@"discord"]) [m setValue:nil forHTTPHeaderField:h];
    }
    if (needUA) { [m setValue:FXUA() forHTTPHeaderField:@"User-Agent"]; FXFileLog(@"added User-Agent to websocket handshake"); }
    if (needUploadHeaders) {
        [m setValue:nil forHTTPHeaderField:@"Authorization"];
        [m setValue:nil forHTTPHeaderField:@"Proxy-Authorization"];
        [m setValue:nil forHTTPHeaderField:@"Cookie"];
        NSString *contentType = [uploadInfo[@"content_type"] isKindOfClass:NSString.class]
            ? uploadInfo[@"content_type"] : nil;
        if (contentType.length) [m setValue:contentType forHTTPHeaderField:@"Content-Type"];
        FXFileLog(@"upload: signed destination headers sanitized; MIME %@", contentType.length ? contentType : @"unchanged");
    }
    @try { FXAttachCaptcha(m); } @catch (NSException *e) { FXFileLog(@"captcha exception: %@", e); }
    return m;
}

static id FXXformReq(id r) { return [r isKindOfClass:NSURLRequest.class] ? FXRewriteRequest(r) : r; }
static id FXXformURL(id u) {
    if (![u isKindOfClass:NSURL.class]) return u;
    return FXRewriteURL(u, YES) ?: u;
}
static id FXXformURLNoBlock(id u) {
    if (![u isKindOfClass:NSURL.class]) return u;
    return FXRewriteURL(u, NO) ?: u;
}

#pragma mark - Gateway payload conversion (Discord -> Fluxer)

static NSString *FXS(id v) { return [v isKindOfClass:NSString.class] ? v : ([v isKindOfClass:NSNumber.class] ? [v stringValue] : nil); }

// Discord subscription (op 37 / legacy op 14) -> Fluxer Lazy Request guild subscription.
static NSDictionary *FXSub(NSDictionary *s) {
    NSMutableDictionary *o = [@{@"active": @YES, @"threads": @YES} mutableCopy];
    if ([s[@"typing"] isKindOfClass:NSNumber.class]) o[@"typing"] = @([s[@"typing"] boolValue]);
    if ([s[@"channels"] isKindOfClass:NSDictionary.class]) {
        NSMutableDictionary *mc = [NSMutableDictionary dictionary];
        for (id cid in s[@"channels"]) {
            NSString *k = FXS(cid); id rs = s[@"channels"][cid];
            if (!k.length || ![rs isKindOfClass:NSArray.class]) continue;
            NSMutableArray *ok = [NSMutableArray array];
            for (id r in rs) {
                if (![r isKindOfClass:NSArray.class] || [r count] != 2) continue;
                long a = [r[0] longValue], b = [r[1] longValue];
                if (a < 0 || b < a || b > 100000 || b - a > 99) continue;
                [ok addObject:@[@(a), @(b)]];
                if (ok.count >= 10) break;
            }
            if (ok.count && mc.count < 10) mc[k] = ok;
        }
        if (mc.count) o[@"member_list_channels"] = mc;
    }
    if ([s[@"members"] isKindOfClass:NSArray.class]) {
        NSMutableArray *m = [NSMutableArray array];
        for (id x in s[@"members"]) { NSString *k = FXS(x); if (k.length && m.count < 1000) [m addObject:k]; }
        if (m.count) o[@"members"] = m;
    }
    return o;
}

// Returns the Fluxer-shaped frame, nil to leave the frame untouched. *drop = YES: Fluxer has no equivalent, don't send.
static NSData *FXFixGatewayDataEx(NSData *data, BOOL *drop) {
    if (drop) *drop = NO;
    id j = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![j isKindOfClass:NSDictionary.class] || ![j[@"op"] isKindOfClass:NSNumber.class]) return nil;
    int op = [j[@"op"] intValue];
    id dd = j[@"d"];
    NSDictionary *d = [dd isKindOfClass:NSDictionary.class] ? dd : @{};
    NSDictionary *out = nil;
    switch (op) {
        case 1: case 6: case 15: case 16: case 28: return nil;
        case 2: {
            NSDictionary *pr = [d[@"properties"] isKindOfClass:NSDictionary.class] ? d[@"properties"] : @{};
            NSMutableDictionary *nd = [NSMutableDictionary dictionary];
            nd[@"token"] = d[@"token"] ?: @"";
            // Fluxer uses bit 2 (CHANNEL_THREADS) to opt a user session into
            // forum/media channels and thread dispatches. Discord's Identify
            // does not carry this Fluxer-specific flag.
            nd[@"flags"] = @4;
            nd[@"properties"] = @{
                @"os": [pr[@"os"] isKindOfClass:NSString.class] ? pr[@"os"] : @"iOS",
                @"browser": [pr[@"browser"] isKindOfClass:NSString.class] ? pr[@"browser"] : @"Discord iOS",
                @"device": [pr[@"device"] isKindOfClass:NSString.class] ? pr[@"device"] : @"iPhone",
                @"mobile": @YES,
            };
            NSDictionary *pres = [d[@"presence"] isKindOfClass:NSDictionary.class] ? d[@"presence"] : nil;
            if ([pres[@"status"] isKindOfClass:NSString.class])
                nd[@"presence"] = @{@"status": pres[@"status"], @"afk": @NO, @"mobile": @YES};
            out = @{@"op": @2, @"d": nd};
            break;
        }
        case 3: {   // presence: Fluxer closes on an unknown status string, so rebuild it
            NSString *st = [d[@"status"] isKindOfClass:NSString.class] ? d[@"status"] : @"online";
            if (![@[@"online", @"idle", @"dnd", @"invisible", @"offline"] containsObject:st]) st = @"online";
            out = @{@"op": @3, @"d": @{@"status": st, @"afk": @([d[@"afk"] boolValue]), @"mobile": @YES}};
            break;
        }
        case 4: {   // voice state
            NSMutableDictionary *nd = [NSMutableDictionary dictionary];
            for (NSString *k in @[@"guild_id", @"channel_id", @"connection_id"]) if (d[k]) nd[k] = d[k];
            for (NSString *k in @[@"self_mute", @"self_deaf", @"self_video", @"self_stream"])
                if ([d[k] isKindOfClass:NSNumber.class]) nd[k] = @([d[k] boolValue]);
            out = @{@"op": @4, @"d": nd};
            break;
        }
        case 8: {   // request guild members: Discord allows guild_id as an array
            NSMutableDictionary *nd = [NSMutableDictionary dictionary];
            id g = d[@"guild_id"];
            if ([g isKindOfClass:NSArray.class]) {
                NSMutableArray *ids = [NSMutableArray array];
                for (id x in g) { NSString *k = FXS(x); if (k.length) [ids addObject:k]; }
                if (ids.count) nd[@"guild_ids"] = ids;
            } else if (FXS(g).length) nd[@"guild_id"] = FXS(g);
            if (d[@"guild_ids"] && !nd[@"guild_ids"]) nd[@"guild_ids"] = d[@"guild_ids"];
            nd[@"query"] = [d[@"query"] isKindOfClass:NSString.class] ? d[@"query"] : @"";
            nd[@"limit"] = @(MIN(100, MAX(0, [d[@"limit"] intValue])));
            if ([d[@"user_ids"] isKindOfClass:NSArray.class]) {
                NSMutableArray *u = [NSMutableArray array];
                for (id x in d[@"user_ids"]) { NSString *k = FXS(x); if (k.length && u.count < 100) [u addObject:k]; }
                if (u.count) nd[@"user_ids"] = u;
            }
            if ([d[@"presences"] isKindOfClass:NSNumber.class]) nd[@"presences"] = @([d[@"presences"] boolValue]);
            if ([d[@"nonce"] isKindOfClass:NSString.class] && [d[@"nonce"] lengthOfBytesUsingEncoding:NSUTF8StringEncoding] <= 32) nd[@"nonce"] = d[@"nonce"];
            out = @{@"op": @8, @"d": nd};
            break;
        }
        case 14: case 37: {   // Discord guild subscriptions -> Fluxer Lazy Request (op 14)
            NSDictionary *subs = [d[@"subscriptions"] isKindOfClass:NSDictionary.class] ? d[@"subscriptions"] : nil;
            NSMutableDictionary *ns = [NSMutableDictionary dictionary];
            if (subs) {
                for (id gid in subs) {
                    NSDictionary *sv = [subs[gid] isKindOfClass:NSDictionary.class] ? subs[gid] : nil;
                    if (!sv || !FXS(gid).length) continue;
                    if ([sv[@"active"] boolValue]) {
                        NSMutableDictionary *alreadyFluxer = [sv mutableCopy];
                        alreadyFluxer[@"active"] = @YES;
                        alreadyFluxer[@"threads"] = @YES;
                        ns[FXS(gid)] = alreadyFluxer;
                    } else {
                        ns[FXS(gid)] = FXSub(sv);
                    }
                }
            } else if (FXS(d[@"guild_id"]).length) {
                ns[FXS(d[@"guild_id"])] = FXSub(d);        // legacy op 14
            }
            out = @{@"op": @14, @"d": @{@"subscriptions": ns}};
            break;
        }
        default:
            if (op == 13) FXFileLog(@"voice call signaling requested (Discord op 13); Fluxer has no compatible Discord call-connect opcode, leaving it disabled rather than sending an invalid frame");
            if (drop) *drop = YES;
            return nil;
    }
    return [NSJSONSerialization dataWithJSONObject:out options:0 error:nil];
}

static NSData *FXFixGatewayData(NSData *data) {       // heartbeat swap for stacks that can't drop a frame
    @try {
        BOOL drop = NO;
        NSData *o = FXFixGatewayDataEx(data, &drop);
        if (drop) return [NSJSONSerialization dataWithJSONObject:@{@"op": @1, @"d": NSNull.null} options:0 error:nil];
        return o;
    } @catch (NSException *e) { FXFileLog(@"gateway fix exception: %@", e); return nil; }
}

static id FXXformWSMessage(id msg) {
    if (@available(iOS 13.0, *)) {
        if (![msg isKindOfClass:NSURLSessionWebSocketMessage.class]) return msg;
        NSURLSessionWebSocketMessage *m = msg;
        BOOL isStr = m.type == NSURLSessionWebSocketMessageTypeString;
        NSData *raw = isStr ? [m.string dataUsingEncoding:NSUTF8StringEncoding] : m.data;
        NSData *fixed = raw ? FXFixGatewayData(raw) : nil;
        if (!fixed) return msg;
        if (isStr) {
            NSString *s = [[NSString alloc] initWithData:fixed encoding:NSUTF8StringEncoding];
            return [[NSURLSessionWebSocketMessage alloc] initWithString:s];
        }
        return [[NSURLSessionWebSocketMessage alloc] initWithData:fixed];
    }
    return msg;
}

static id FXDropSentinel(void) {
    static id sentinel; static dispatch_once_t o;
    dispatch_once(&o, ^{ sentinel = [NSObject new]; });
    return sentinel;
}

static id FXXformSendPayload(id p) {                    // SocketRocket-style send: (may return FXDropSentinel())
    BOOL isStr = [p isKindOfClass:NSString.class];
    if (!isStr && ![p isKindOfClass:NSData.class]) return p;
    @try {
        BOOL drop = NO;
        NSData *f = FXFixGatewayDataEx(isStr ? [(NSString *)p dataUsingEncoding:NSUTF8StringEncoding] : p, &drop);
        if (drop) { FXFileLog(@"WS SEND dropped (no Fluxer equivalent)"); return FXDropSentinel(); }
        if (!f) return p;
        return isStr ? [[NSString alloc] initWithData:f encoding:NSUTF8StringEncoding] : f;
    } @catch (NSException *e) { FXFileLog(@"gateway fix exception: %@", e); return p; }
}

#pragma mark - Hook plumbing

typedef id (*FXXform)(id);

static BOOL FXIsObjectLikeType(const char *type) {
    if (!type) return NO;
    while (*type && strchr("rnNoORV", *type)) type++;
    return type[0] == '@'; // object or block; reject scalar/pointer/struct ABIs
}

static void FXHook(Class cls, SEL sel, FXXform xf) {
    if (!cls || !sel || !xf) return;
    @try {
        static NSMutableSet *done;
        static dispatch_once_t once;
        dispatch_once(&once, ^{ done = [NSMutableSet set]; });
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) return;
        NSValue *key = [NSValue valueWithPointer:m];
        @synchronized (done) {
            if ([done containsObject:key]) return;
            [done addObject:key];
        }
        unsigned n = method_getNumberOfArguments(m) - 2;
        if (n < 1 || n > 4) {
            FXFileLog(@"hook skipped %@ %@: unsupported argument count %u", NSStringFromClass(cls), NSStringFromSelector(sel), n);
            return;
        }
        char returnType[32] = {0};
        method_getReturnType(m, returnType, sizeof(returnType));
        BOOL returnsVoid = returnType[0] == 'v';
        if (!returnsVoid && !FXIsObjectLikeType(returnType)) {
            FXFileLog(@"hook skipped %@ %@: unsupported return type %s", NSStringFromClass(cls), NSStringFromSelector(sel), returnType);
            return;
        }
        for (unsigned i = 2; i < n + 2; i++) {
            char *argType = method_copyArgumentType(m, i);
            BOOL ok = FXIsObjectLikeType(argType);
            if (argType) free(argType);
            if (!ok) {
                FXFileLog(@"hook skipped %@ %@: argument %u is not object/block", NSStringFromClass(cls), NSStringFromSelector(sel), i - 2);
                return;
            }
        }
        IMP orig = method_getImplementation(m);
        IMP repl = NULL;
        if (returnsVoid) {
            switch (n) {
                case 1: repl = imp_implementationWithBlock(^void(id self, id a) { ((void (*)(id, SEL, id))orig)(self, sel, xf(a)); }); break;
                case 2: repl = imp_implementationWithBlock(^void(id self, id a, id b) { ((void (*)(id, SEL, id, id))orig)(self, sel, xf(a), b); }); break;
                case 3: repl = imp_implementationWithBlock(^void(id self, id a, id b, id c) { ((void (*)(id, SEL, id, id, id))orig)(self, sel, xf(a), b, c); }); break;
                case 4: repl = imp_implementationWithBlock(^void(id self, id a, id b, id c, id d) { ((void (*)(id, SEL, id, id, id, id))orig)(self, sel, xf(a), b, c, d); }); break;
            }
        } else {
            switch (n) {
                case 1: repl = imp_implementationWithBlock(^id(id self, id a) { return ((id (*)(id, SEL, id))orig)(self, sel, xf(a)); }); break;
                case 2: repl = imp_implementationWithBlock(^id(id self, id a, id b) { return ((id (*)(id, SEL, id, id))orig)(self, sel, xf(a), b); }); break;
                case 3: repl = imp_implementationWithBlock(^id(id self, id a, id b, id c) { return ((id (*)(id, SEL, id, id, id))orig)(self, sel, xf(a), b, c); }); break;
                case 4: repl = imp_implementationWithBlock(^id(id self, id a, id b, id c, id d) { return ((id (*)(id, SEL, id, id, id, id))orig)(self, sel, xf(a), b, c, d); }); break;
            }
        }
        if (repl) {
            method_setImplementation(m, repl);
            FXFileLog(@"hooked %@ %@", NSStringFromClass(cls), NSStringFromSelector(sel));
        } else FXFileLog(@"hook skipped %@ %@: no compatible wrapper", NSStringFromClass(cls), NSStringFromSelector(sel));
    } @catch (NSException *e) {
        FXFileLog(@"hook exception %@ %@: %@", NSStringFromClass(cls), NSStringFromSelector(sel), e);
    }
}

static void FXHookMany(Class cls, NSArray<NSString *> *sels, FXXform xf) {
    if (!cls) return;
    for (NSString *s in sels) {
        @try { FXHook(cls, NSSelectorFromString(s), xf); }
        @catch (NSException *e) { FXFileLog(@"hook-many exception %@ %@: %@", NSStringFromClass(cls), s, e); }
    }
}

#pragma mark - Websocket class discovery (hooks whatever socket class the app really uses)

typedef uintptr_t (*FXGen1)(id, SEL, id);

static void FXHookGeneric(Class cls, Method m) {
    SEL sel = method_getName(m);
    IMP orig = method_getImplementation(m);
    unsigned n = method_getNumberOfArguments(m) - 2;
    IMP imp = NULL;
    if (n == 1) imp = imp_implementationWithBlock(^uintptr_t(id s, id a) {
        return ((uintptr_t (*)(id, SEL, id))orig)(s, sel, FXXformReq(a));
    });
    else if (n == 2) imp = imp_implementationWithBlock(^uintptr_t(id s, id a, uintptr_t b) {
        return ((uintptr_t (*)(id, SEL, id, uintptr_t))orig)(s, sel, FXXformReq(a), b);
    });
    else if (n == 3) imp = imp_implementationWithBlock(^uintptr_t(id s, id a, uintptr_t b, uintptr_t c) {
        return ((uintptr_t (*)(id, SEL, id, uintptr_t, uintptr_t))orig)(s, sel, FXXformReq(a), b, c);
    });
    if (imp) class_replaceMethod(cls, sel, imp, method_getTypeEncoding(m));
}

static NSString *FXWSURL(id ws) {
    @try {
        if ([ws respondsToSelector:@selector(url)]) {
            NSURL *u = ((id (*)(id, SEL))objc_msgSend)(ws, @selector(url));
            if ([u isKindOfClass:NSURL.class]) return [NSString stringWithFormat:@"%@%@", u.host ?: @"?", u.path ?: @""];
        }
    } @catch (__unused id e) {}
    return @"?";
}

// Summary of a frame without its contents (frames can hold your token).
static NSString *FXFrame(id msg) {
    if ([msg isKindOfClass:NSData.class]) return [NSString stringWithFormat:@"binary %lu bytes", (unsigned long)[(NSData *)msg length]];
    if (![msg isKindOfClass:NSString.class]) return @"?";
    NSString *m = msg;
    NSString *head = m.length > 400 ? [[m substringToIndex:200] stringByAppendingString:[m substringFromIndex:m.length - 200]] : m;
    int op = -1; NSString *t = nil;
    NSRange r = [head rangeOfString:@"\"op\":" options:NSBackwardsSearch];
    if (r.location != NSNotFound) op = [[head substringFromIndex:NSMaxRange(r)] intValue];
    r = [head rangeOfString:@"\"t\":\""];
    if (r.location != NSNotFound) {
        NSString *rest = [head substringFromIndex:NSMaxRange(r)];
        NSRange q = [rest rangeOfString:@"\""];
        if (q.location != NSNotFound) t = [rest substringToIndex:q.location];
    }
    NSMutableString *o = [NSMutableString stringWithFormat:@"op=%d", op];
    if (t.length) [o appendFormat:@" t=%@", t];
    [o appendFormat:@" size=%lu", (unsigned long)m.length];
    if (op != 0 && op != 2 && op != 3 && m.length < 120) [o appendFormat:@" %@", m];
    return o;
}

// Fluxer's READY is not shaped like Discord's v9 READY, and the app drops the socket when fields it needs
// are missing. Convert it (client-side only) and log key NAMES (never values).
#define FXDEF(k, v) do { id _x = d[k]; if (!_x || _x == NSNull.null) d[k] = (v); } while (0)
#define FXDEFM(m, k, v) do { id _x = (m)[k]; if (!_x) (m)[k] = (v); } while (0)

static NSMutableDictionary *FXMut(id x) { return [x isKindOfClass:NSMutableDictionary.class] ? x : nil; }

static NSMutableDictionary *FXUserCacheDict(void) {
    static NSMutableDictionary *c; static dispatch_once_t o;
    dispatch_once(&o, ^{ c = [NSMutableDictionary dictionary]; });
    return c;
}
static void FXApplyNitroPreview(NSMutableDictionary *u) {
    if (!u || !gNitroPreview || !gSelfUserID.length) return;
    NSString *uid = FXS(u[@"id"]);
    if (![uid isEqualToString:gSelfUserID]) return;
    // Client-side presentation hint only. Do not synthesize billing, purchase, or API entitlements.
    u[@"premium_type"] = @2;
}

static void FXNormalizeUserBadgeFlags(NSMutableDictionary *u) {
    if (!u) return;
    id raw = u[@"flags"];
    if (![raw respondsToSelector:@selector(unsignedLongLongValue)]) return;
    unsigned long long f = [raw unsignedLongLongValue];
    unsigned long long discord = 0;
    if (f & (1ULL << 0)) discord |= (1ULL << 0);
    if (f & (1ULL << 2)) discord |= (1ULL << 1);
    if (f & (1ULL << 3)) discord |= (1ULL << 3);
    u[@"public_flags"] = @(discord);
}

static void FXCacheUser(id u) {
    if (![u isKindOfClass:NSDictionary.class] || ![u[@"username"] isKindOfClass:NSString.class]) return;
    FXNormalizeUserBadgeFlags(FXMut(u));
    FXApplyNitroPreview(FXMut(u));
    NSString *i = FXS(u[@"id"]);
    if (!i.length) return;
    NSMutableDictionary *c = FXUserCacheDict();
    @synchronized (c) { if (c.count > 6000) [c removeAllObjects]; c[i] = [u copy]; }
}
static NSDictionary *FXCachedUser(NSString *i) {
    if (!i.length) return nil;
    NSMutableDictionary *c = FXUserCacheDict();
    @synchronized (c) { return c[i]; }
}
static void FXAddFeature(NSMutableDictionary *c) {   // Discord only draws role icons when the guild has ROLE_ICONS
    NSMutableArray *f = [c[@"features"] isKindOfClass:NSArray.class] ? [c[@"features"] mutableCopy] : [NSMutableArray array];
    if (![f containsObject:@"ROLE_ICONS"]) [f addObject:@"ROLE_ICONS"];
    c[@"features"] = f;
}
static void FXFixRole(NSMutableDictionary *rm) {
    if (!rm) return;
    FXDEFM(rm, @"flags", @0);
    FXDEFM(rm, @"managed", @NO);
    FXDEFM(rm, @"mentionable", @NO);
    FXDEFM(rm, @"hoist", @NO);
    FXDEFM(rm, @"position", @0);
    FXDEFM(rm, @"color", @0);
    FXDEFM(rm, @"icon", (id)NSNull.null);
    FXDEFM(rm, @"unicode_emoji", (id)NSNull.null);
}
static void FXFixMember(NSMutableDictionary *m) {
    if (!m) return;
    FXCacheUser(m[@"user"]);
    FXDEFM(m, @"roles", @[]);
    if (!m[@"joined_at"] || m[@"joined_at"] == NSNull.null) m[@"joined_at"] = @"2020-01-01T00:00:00.000000+00:00";
    FXDEFM(m, @"deaf", @NO);
    FXDEFM(m, @"mute", @NO);
    FXDEFM(m, @"flags", @0);
    FXDEFM(m, @"pending", @NO);
    FXDEFM(m, @"premium_since", (id)NSNull.null);
    FXDEFM(m, @"communication_disabled_until", (id)NSNull.null);
}
static void FXFixPresence(NSMutableDictionary *p) {   // Fluxer {status,mobile,afk,custom_status} -> Discord {client_status,activities}
    if (!p) return;
    FXCacheUser(p[@"user"]);
    NSString *st = [p[@"status"] isKindOfClass:NSString.class] ? p[@"status"] : @"offline";
    if (![p[@"client_status"] isKindOfClass:NSDictionary.class])
        p[@"client_status"] = [st isEqualToString:@"offline"] ? @{} : @{([p[@"mobile"] boolValue] ? @"mobile" : @"desktop"): st};
    if (![p[@"activities"] isKindOfClass:NSArray.class]) {
        NSMutableArray *acts = [NSMutableArray array];
        NSDictionary *cs = [p[@"custom_status"] isKindOfClass:NSDictionary.class] ? p[@"custom_status"] : nil;
        if (cs && ([cs[@"text"] isKindOfClass:NSString.class] || [cs[@"emoji_name"] isKindOfClass:NSString.class])) {
            NSMutableDictionary *a = [@{@"id": @"custom", @"type": @4, @"name": @"Custom Status", @"created_at": @0} mutableCopy];
            if ([cs[@"text"] isKindOfClass:NSString.class]) a[@"state"] = cs[@"text"];
            if ([cs[@"emoji_name"] isKindOfClass:NSString.class]) {
                NSMutableDictionary *e = [@{@"name": cs[@"emoji_name"]} mutableCopy];
                if (cs[@"emoji_id"] && cs[@"emoji_id"] != NSNull.null) { e[@"id"] = cs[@"emoji_id"]; e[@"animated"] = @([cs[@"emoji_animated"] boolValue]); }
                a[@"emoji"] = e;
            }
            [acts addObject:a];
        }
        p[@"activities"] = acts;
    }
}

// Discord's JS reads emoji.roles.length etc.; Fluxer's emoji/sticker objects don't carry every field.
static void FXFixExpressions(NSArray *emojis, NSArray *stickers) {
    for (id e in (emojis ?: @[])) {
        NSMutableDictionary *em = FXMut(e); if (!em) continue;
        FXDEFM(em, @"roles", @[]);
        FXDEFM(em, @"available", @YES);
        FXDEFM(em, @"managed", @NO);
        FXDEFM(em, @"require_colons", @YES);
        FXDEFM(em, @"animated", @NO);
    }
    for (id e in (stickers ?: @[])) {
        NSMutableDictionary *sm = FXMut(e); if (!sm) continue;
        FXDEFM(sm, @"available", @YES);
        FXDEFM(sm, @"tags", @"");
        FXDEFM(sm, @"type", @2);
        FXDEFM(sm, @"format_type", @1);
        if (!sm[@"description"] || sm[@"description"] == NSNull.null) sm[@"description"] = @"";
    }
}

static void FXPatchGuild(NSMutableDictionary *g, NSString *uid, NSMutableArray *merged) {
    if ([g[@"unavailable"] boolValue] && !g[@"properties"]) { [merged addObject:@[]]; return; }
    NSMutableDictionary *pr = FXMut(g[@"properties"]);
    if (pr) {
        FXDEFM(pr, @"id", g[@"id"] ?: @"");
        FXAddFeature(pr);
        for (NSString *k in @[@"premium_tier", @"premium_subscription_count", @"verification_level", @"default_message_notifications",
                              @"explicit_content_filter", @"mfa_level", @"nsfw_level", @"system_channel_flags"]) FXDEFM(pr, k, @0);
        FXDEFM(pr, @"preferred_locale", @"en-US");
    }
    FXDEFM(g, @"threads", @[]);
    FXDEFM(g, @"stage_instances", @[]);
    FXDEFM(g, @"guild_scheduled_events", @[]);
    FXDEFM(g, @"activity_instances", @[]);
    FXDEFM(g, @"application_command_counts", @{});
    FXDEFM(g, @"large", @NO);
    FXDEFM(g, @"lazy", @YES);
    FXDEFM(g, @"data_mode", @"full");
    FXDEFM(g, @"version", @0);
    FXDEFM(g, @"premium_subscription_count", @0);
    FXDEFM(g, @"emojis", @[]);
    FXDEFM(g, @"stickers", @[]);
    FXDEFM(g, @"roles", @[]);
    FXDEFM(g, @"channels", @[]);
    FXDEFM(g, @"voice_states", @[]);
    FXFixExpressions([g[@"emojis"] isKindOfClass:NSArray.class] ? g[@"emojis"] : nil, [g[@"stickers"] isKindOfClass:NSArray.class] ? g[@"stickers"] : nil);
    for (id c in ([g[@"channels"] isKindOfClass:NSArray.class] ? g[@"channels"] : @[])) {
        NSMutableDictionary *cm = FXMut(c); if (!cm) continue;
        FXDEFM(cm, @"permission_overwrites", @[]);
        FXDEFM(cm, @"flags", @0);
        FXDEFM(cm, @"position", @0);
    }
    for (id r in ([g[@"roles"] isKindOfClass:NSArray.class] ? g[@"roles"] : @[])) FXFixRole(FXMut(r));
    NSDictionary *mine = nil;
    for (id m in ([g[@"members"] isKindOfClass:NSArray.class] ? g[@"members"] : @[])) {
        if (![m isKindOfClass:NSDictionary.class]) continue;
        NSDictionary *u = [m[@"user"] isKindOfClass:NSDictionary.class] ? m[@"user"] : nil;
        if ([FXS(u[@"id"]) isEqualToString:uid]) { mine = m; break; }
    }
    NSMutableDictionary *mm = mine ? [mine mutableCopy] : [NSMutableDictionary dictionary];
    [mm removeObjectForKey:@"user"];
    mm[@"user_id"] = uid ?: @"";
    FXDEFM(mm, @"roles", @[]);
    FXDEFM(mm, @"joined_at", ([g[@"joined_at"] isKindOfClass:NSString.class] ? g[@"joined_at"] : @"2020-01-01T00:00:00.000000+00:00"));
    FXDEFM(mm, @"flags", @0);
    FXDEFM(mm, @"mute", @NO);
    FXDEFM(mm, @"deaf", @NO);
    FXDEFM(mm, @"pending", @NO);
    FXDEFM(mm, @"premium_since", (id)NSNull.null);
    FXDEFM(mm, @"communication_disabled_until", (id)NSNull.null);
    [merged addObject:@[mm]];
    [g removeObjectForKey:@"members"];      // Discord's READY carries only merged_members; partial {"id"}-only users confuse the app
}

static void FXAddUser(NSMutableArray *users, NSMutableSet *have, id u) {
    if (![u isKindOfClass:NSDictionary.class]) return;
    NSString *i = FXS(u[@"id"]);
    if (!i.length || [have containsObject:i]) return;
    [have addObject:i];
    [users addObject:u];
}

static NSString *FXPatchReady(NSString *m) {
    if (m.length < 100) return m;
    NSString *head = [m substringToIndex:MIN(m.length, (NSUInteger)200)];
    NSString *tail = [m substringFromIndex:m.length > 200 ? m.length - 200 : 0];
    if ([head rangeOfString:@"\"t\":\"READY\""].location == NSNotFound && [tail rangeOfString:@"\"t\":\"READY\""].location == NSNotFound) return m;
    @try {
        id root = [NSJSONSerialization JSONObjectWithData:[m dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
        NSMutableDictionary *d = [root isKindOfClass:NSMutableDictionary.class] ? root[@"d"] : nil;
        if (![d isKindOfClass:NSMutableDictionary.class]) { FXFileLog(@"READY: could not parse"); return m; }
        FXFileLog(@"READY d keys: %@", [[d.allKeys sortedArrayUsingSelector:@selector(compare:)] componentsJoinedByString:@","]);
        NSMutableDictionary *u = FXMut(d[@"user"]);
        if (u) FXFileLog(@"READY user keys: %@", [[u.allKeys sortedArrayUsingSelector:@selector(compare:)] componentsJoinedByString:@","]);
        NSArray *gs = [d[@"guilds"] isKindOfClass:NSArray.class] ? d[@"guilds"] : @[];
        if ([gs.firstObject isKindOfClass:NSDictionary.class])
            FXFileLog(@"READY guild[0] keys: %@ (guilds=%lu)", [[[gs.firstObject allKeys] sortedArrayUsingSelector:@selector(compare:)] componentsJoinedByString:@","], (unsigned long)gs.count);

        NSString *uid = FXS(u[@"id"]);
        if (uid.length) gSelfUserID = uid;
        if (u) {
            u[@"verified"] = @YES;
            id em = u[@"email"];
            if (!em || em == NSNull.null || ([em isKindOfClass:NSString.class] && ![(NSString *)em length]))
                u[@"email"] = [NSString stringWithFormat:@"%@@fluxer.local", [u[@"username"] isKindOfClass:NSString.class] ? u[@"username"] : @"user"];
            FXDEFM(u, @"discriminator", @"0");
            FXDEFM(u, @"global_name", u[@"username"] ?: (id)NSNull.null);
            FXDEFM(u, @"avatar", (id)NSNull.null);
            FXDEFM(u, @"banner", (id)NSNull.null);
            FXDEFM(u, @"accent_color", (id)NSNull.null);
            FXDEFM(u, @"bio", @"");
            FXDEFM(u, @"phone", (id)NSNull.null);
            FXDEFM(u, @"bot", @NO);
            FXDEFM(u, @"system", @NO);
            FXDEFM(u, @"mfa_enabled", @NO);
            FXDEFM(u, @"nsfw_allowed", @YES);
            for (NSString *k in @[@"flags", @"public_flags", @"premium_type", @"purchased_flags", @"premium_usage_flags"]) FXDEFM(u, k, @0);
            FXNormalizeUserBadgeFlags(u);
            FXApplyNitroPreview(u);
        }

        // users: everyone referenced by the payload
        NSMutableArray *users = [d[@"users"] isKindOfClass:NSArray.class] ? [d[@"users"] mutableCopy] : [NSMutableArray array];
        NSMutableSet *have = [NSMutableSet set];
        for (id x in users) if ([x isKindOfClass:NSDictionary.class]) { NSString *i = FXS(x[@"id"]); if (i) [have addObject:i]; }

        // relationships: Discord keys them by user_id
        for (id r in ([d[@"relationships"] isKindOfClass:NSArray.class] ? d[@"relationships"] : @[])) {
            NSMutableDictionary *rm = FXMut(r); if (!rm) continue;
            FXDEFM(rm, @"user_id", rm[@"id"] ?: @"");
            FXDEFM(rm, @"nickname", (id)NSNull.null);
            FXDEFM(rm, @"since", @"2020-01-01T00:00:00.000000+00:00");
            FXAddUser(users, have, rm[@"user"]);
        }
        // private channels: Discord lists recipient_ids and resolves users from `users`
        for (id c in ([d[@"private_channels"] isKindOfClass:NSArray.class] ? d[@"private_channels"] : @[])) {
            NSMutableDictionary *cm = FXMut(c); if (!cm) continue;
            NSMutableArray *ids = [NSMutableArray array];
            for (id ru in ([cm[@"recipients"] isKindOfClass:NSArray.class] ? cm[@"recipients"] : @[])) {
                NSString *i = FXS([ru isKindOfClass:NSDictionary.class] ? ru[@"id"] : nil);
                if (i) [ids addObject:i];
                FXAddUser(users, have, ru);
            }
            FXDEFM(cm, @"recipient_ids", ids);
            FXDEFM(cm, @"flags", @0);
            FXDEFM(cm, @"last_message_id", (id)NSNull.null);
        }
        // presences -> merged_presences
        NSMutableArray *friends = [NSMutableArray array];
        for (id p in ([d[@"presences"] isKindOfClass:NSArray.class] ? d[@"presences"] : @[])) {
            if (![p isKindOfClass:NSDictionary.class]) continue;
            NSString *i = FXS([p[@"user"] isKindOfClass:NSDictionary.class] ? p[@"user"][@"id"] : p[@"user_id"]);
            if (!i) continue;
            FXAddUser(users, have, p[@"user"]);
            NSString *st = [p[@"status"] isKindOfClass:NSString.class] ? p[@"status"] : @"offline";
            [friends addObject:@{@"user_id": i, @"status": st, @"activities": @[],
                                 @"client_status": @{([p[@"mobile"] boolValue] ? @"mobile" : @"desktop"): st}}];
        }
        for (id cu in users) FXCacheUser(cu);
        FXCacheUser(u);
        d[@"users"] = users;
        d[@"merged_presences"] = @{@"friends": friends, @"guilds": @[]};

        // sessions
        for (id ss in ([d[@"sessions"] isKindOfClass:NSArray.class] ? d[@"sessions"] : @[])) {
            NSMutableDictionary *sm = FXMut(ss); if (!sm) continue;
            FXDEFM(sm, @"activities", @[]);
            FXDEFM(sm, @"client_info", (@{@"client": [sm[@"mobile"] boolValue] ? @"mobile" : @"desktop", @"os": @"ios", @"version": @0}));
        }

        // guilds + merged_members (array of arrays, one per guild)
        NSMutableArray *merged = [NSMutableArray array];
        for (id g in gs) {
            NSMutableDictionary *gm = FXMut(g);
            if (!gm) { [merged addObject:@[]]; continue; }
            FXPatchGuild(gm, uid, merged);
        }
        d[@"merged_members"] = merged;

        // read state / guild settings: Discord wraps them as {entries, partial, version}
        NSMutableArray *rs = [d[@"read_states"] isKindOfClass:NSArray.class] ? d[@"read_states"] : [NSMutableArray array];
        for (id r in rs) {
            NSMutableDictionary *rm = FXMut(r); if (!rm) continue;
            FXDEFM(rm, @"mention_count", @0);
            FXDEFM(rm, @"last_message_id", (id)NSNull.null);
            FXDEFM(rm, @"last_pin_timestamp", (id)NSNull.null);
            FXDEFM(rm, @"flags", @0);
        }
        if (![d[@"read_state"] isKindOfClass:NSDictionary.class]) d[@"read_state"] = @{@"entries": rs, @"partial": @NO, @"version": @0};
        id ugs = d[@"user_guild_settings"];
        if ([ugs isKindOfClass:NSArray.class]) {
            for (id e in ugs) {
                NSMutableDictionary *em = FXMut(e); if (!em) continue;
                FXDEFM(em, @"channel_overrides", @[]);
                FXDEFM(em, @"muted", @NO);
                FXDEFM(em, @"mute_config", (id)NSNull.null);
                FXDEFM(em, @"suppress_everyone", @NO);
                FXDEFM(em, @"suppress_roles", @NO);
                FXDEFM(em, @"mobile_push", @YES);
                FXDEFM(em, @"hide_muted_channels", @NO);
                FXDEFM(em, @"message_notifications", @3);
                FXDEFM(em, @"flags", @0);
                FXDEFM(em, @"version", @0);
            }
            d[@"user_guild_settings"] = @{@"entries": ugs, @"partial": @NO, @"version": @0};
        } else if (![ugs isKindOfClass:NSDictionary.class]) {
            d[@"user_guild_settings"] = @{@"entries": @[], @"partial": @NO, @"version": @0};
        }

        // regions
        NSMutableArray *regions = [NSMutableArray array];
        for (id r in ([d[@"rtc_regions"] isKindOfClass:NSArray.class] ? d[@"rtc_regions"] : @[]))
            if ([r isKindOfClass:NSDictionary.class] && FXS(r[@"id"])) [regions addObject:FXS(r[@"id"])];
        FXDEF(@"geo_ordered_rtc_regions", regions);

        d[@"v"] = @9;
        d[@"resume_gateway_url"] = @"wss://gateway.discord.gg";   // a Discord host, so a resume goes through the rewrite (v=1)
        FXDEF(@"users", @[]);
        FXDEF(@"session_type", @"normal");
        FXDEF(@"user_settings_proto", @"");
        FXDEF(@"auth_session_id_hash", @"");
        FXDEF(@"analytics_token", @"");
        FXDEF(@"country_code", @"US");
        FXDEF(@"guild_join_requests", @[]);
        FXDEF(@"connected_accounts", @[]);
        FXDEF(@"notification_settings", @{});
        FXDEF(@"api_code_version", @1);
        FXDEF(@"consents", @{@"personalization": @{@"consented": @NO}});
        FXDEF(@"experiments", @[]);
        FXDEF(@"guild_experiments", @[]);
        FXDEF(@"friend_suggestion_count", @0);
        FXDEF(@"game_relationships", @[]);
        FXDEF(@"tutorial", (id)NSNull.null);

        NSData *out = [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingWithoutEscapingSlashes error:nil];
        NSString *str = out ? [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] : nil;
        if (str) { FXFileLog(@"READY patched (%lu -> %lu bytes, %lu guilds)", (unsigned long)m.length, (unsigned long)str.length, (unsigned long)gs.count); return str; }
    } @catch (NSException *e) { FXFileLog(@"READY patch exception: %@", e); }
    return m;
}

// Dispatches whose Fluxer payload differs from Discord's in ways the app trips over.
static NSString *FXEventName(NSString *m) {
    NSUInteger n = m.length;
    if (n < 20) return nil;
    NSRange r = [m rangeOfString:@"\"t\":\"" options:NSBackwardsSearch range:NSMakeRange(n > 120 ? n - 120 : 0, MIN(n, (NSUInteger)120))];
    if (r.location == NSNotFound) r = [m rangeOfString:@"\"t\":\"" options:0 range:NSMakeRange(0, MIN(n, (NSUInteger)200))];
    if (r.location == NSNotFound) return nil;
    NSUInteger st = NSMaxRange(r);
    NSRange q = [m rangeOfString:@"\"" options:0 range:NSMakeRange(st, MIN(n - st, (NSUInteger)40))];
    return q.location == NSNotFound ? nil : [m substringWithRange:NSMakeRange(st, q.location - st)];
}

static BOOL FXFixMessageObject(NSMutableDictionary *m);

static NSString *FXPatchEvents(NSString *m) {
    NSString *t = FXEventName(m);
    if (!t.length) return m;
    static NSSet *handled; static dispatch_once_t once;
    dispatch_once(&once, ^{ handled = [NSSet setWithArray:@[@"GUILD_CREATE", @"GUILD_SYNC", @"GUILD_UPDATE", @"GUILD_EMOJIS_UPDATE", @"GUILD_STICKERS_UPDATE",
        @"GUILD_ROLE_CREATE", @"GUILD_ROLE_UPDATE", @"GUILD_ROLE_UPDATE_BULK", @"TYPING_START", @"MESSAGE_CREATE", @"MESSAGE_UPDATE",
        @"PRESENCE_UPDATE", @"GUILD_MEMBER_LIST_UPDATE", @"GUILD_MEMBERS_CHUNK", @"PASSIVE_UPDATES", @"GUILD_MEMBER_ADD", @"GUILD_MEMBER_UPDATE",
        @"THREAD_LIST_SYNC", @"THREAD_CREATE", @"THREAD_UPDATE", @"THREAD_DELETE"]]; });
    if (![handled containsObject:t]) return m;
    @try {
        id root = [NSJSONSerialization JSONObjectWithData:[m dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
        NSMutableDictionary *d = [root isKindOfClass:NSMutableDictionary.class] ? root[@"d"] : nil;
        if (![d isKindOfClass:NSMutableDictionary.class]) return m;
        BOOL changed = YES;
        if ([t isEqualToString:@"GUILD_CREATE"] || [t isEqualToString:@"GUILD_SYNC"]) {
            NSArray *mem = [d[@"members"] isKindOfClass:NSArray.class] ? d[@"members"] : nil;
            for (id x in (mem ?: @[])) FXFixMember(FXMut(x));
            FXPatchGuild(d, @"", [NSMutableArray array]);
            if (mem) d[@"members"] = mem;
        } else if ([t isEqualToString:@"GUILD_UPDATE"]) {
            FXAddFeature(d);
            if (FXMut(d[@"properties"])) FXAddFeature(FXMut(d[@"properties"]));
        } else if ([t isEqualToString:@"GUILD_EMOJIS_UPDATE"]) {
            FXFixExpressions([d[@"emojis"] isKindOfClass:NSArray.class] ? d[@"emojis"] : nil, nil);
        } else if ([t isEqualToString:@"GUILD_STICKERS_UPDATE"]) {
            FXFixExpressions(nil, [d[@"stickers"] isKindOfClass:NSArray.class] ? d[@"stickers"] : nil);
        } else if ([t isEqualToString:@"GUILD_ROLE_CREATE"] || [t isEqualToString:@"GUILD_ROLE_UPDATE"]) {
            FXFixRole(FXMut(d[@"role"]));
        } else if ([t isEqualToString:@"GUILD_ROLE_UPDATE_BULK"]) {
            for (id r in ([d[@"roles"] isKindOfClass:NSArray.class] ? d[@"roles"] : @[])) FXFixRole(FXMut(r));
        } else if ([t isEqualToString:@"MESSAGE_CREATE"] || [t isEqualToString:@"MESSAGE_UPDATE"]) {
            FXCacheUser(d[@"author"]);
            changed = FXFixMessageObject(d);
        } else if ([t isEqualToString:@"TYPING_START"]) {
            NSString *uid = FXS(d[@"user_id"]);
            if (FXS(d[@"guild_id"]).length) {
                NSMutableDictionary *mem = FXMut(d[@"member"]);
                if (!mem) { mem = [NSMutableDictionary dictionary]; d[@"member"] = mem; }
                NSDictionary *cu = FXCachedUser(uid);
                NSDictionary *mu = [mem[@"user"] isKindOfClass:NSDictionary.class] ? mem[@"user"] : nil;
                if (cu && !mu[@"username"]) mem[@"user"] = cu;
                else if (!mu) mem[@"user"] = @{@"id": uid ?: @"", @"username": [mem[@"nick"] isKindOfClass:NSString.class] ? mem[@"nick"] : @"Someone", @"discriminator": @"0", @"avatar": NSNull.null};
                FXFixMember(mem);
            }
            if ([d[@"timestamp"] isKindOfClass:NSNumber.class] && [d[@"timestamp"] doubleValue] > 1e11) d[@"timestamp"] = @((long long)([d[@"timestamp"] doubleValue] / 1000.0));
            static int n; if (n++ < 10) FXFileLog(@"TYPING_START channel=%@ guild=%@ userCached=%d", FXS(d[@"channel_id"]) ? @"y" : @"n", FXS(d[@"guild_id"]) ? @"y" : @"dm", FXCachedUser(uid) != nil);
        } else if ([t isEqualToString:@"PRESENCE_UPDATE"]) {
            FXFixPresence(d);
        } else if ([t isEqualToString:@"GUILD_MEMBER_LIST_UPDATE"]) {
            for (id op in ([d[@"ops"] isKindOfClass:NSArray.class] ? d[@"ops"] : @[])) {
                if (![op isKindOfClass:NSDictionary.class]) continue;
                for (id item in ([op[@"items"] isKindOfClass:NSArray.class] ? op[@"items"] : @[])) {
                    NSMutableDictionary *mem = FXMut(item[@"member"]);
                    if (!mem) continue;
                    FXFixMember(mem);
                    NSMutableDictionary *pr = FXMut(mem[@"presence"]);
                    if (pr) {
                        if (!pr[@"user"] && [mem[@"user"] isKindOfClass:NSDictionary.class]) pr[@"user"] = @{@"id": mem[@"user"][@"id"] ?: @""};
                        FXFixPresence(pr);
                    }
                }
            }
        } else if ([t isEqualToString:@"GUILD_MEMBERS_CHUNK"]) {
            for (id x in ([d[@"members"] isKindOfClass:NSArray.class] ? d[@"members"] : @[])) FXFixMember(FXMut(x));
            for (id x in ([d[@"presences"] isKindOfClass:NSArray.class] ? d[@"presences"] : @[])) FXFixPresence(FXMut(x));
        } else if ([t isEqualToString:@"GUILD_MEMBER_ADD"] || [t isEqualToString:@"GUILD_MEMBER_UPDATE"]) {
            FXFixMember(d);
        } else if ([t isEqualToString:@"THREAD_LIST_SYNC"] || [t isEqualToString:@"THREAD_CREATE"] ||
                   [t isEqualToString:@"THREAD_UPDATE"] || [t isEqualToString:@"THREAD_DELETE"]) {
            id threads = d[@"threads"];
            id channel = d[@"channel"];
            FXFileLog(@"thread event %@ guild=%@ thread_count=%lu channel_object=%@ keys=%@", t,
                      FXS(d[@"guild_id"]) ?: @"-", (unsigned long)([threads isKindOfClass:NSArray.class] ? [threads count] : 0),
                      [channel isKindOfClass:NSDictionary.class] ? @"yes" : @"no",
                      [[d allKeys] sortedArrayUsingSelector:@selector(compare:)]);
        } else if ([t isEqualToString:@"PASSIVE_UPDATES"]) {
            // Fluxer {channels:{id:last_message_id}} -> Discord PASSIVE_UPDATE_V1 {channels:[{id,last_message_id}]}
            NSMutableArray *chs = [NSMutableArray array];
            if ([d[@"channels"] isKindOfClass:NSDictionary.class])
                for (id k in d[@"channels"]) [chs addObject:@{@"id": FXS(k) ?: @"", @"last_message_id": d[@"channels"][k] ?: NSNull.null, @"last_pin_timestamp": NSNull.null}];
            d[@"channels"] = chs;
            FXDEFM(d, @"voice_states", @[]);
            FXDEFM(d, @"members", @[]);
            root[@"t"] = @"PASSIVE_UPDATE_V1";
        }
        if (!changed) return m;
        NSData *out = [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingWithoutEscapingSlashes error:nil];
        NSString *str = out ? [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] : nil;
        if (str) return str;
    } @catch (NSException *e) { FXFileLog(@"event patch exception (%@): %@", t, e); }
    return m;
}

static id FXPatchGatewayIn(id msg) { return [msg isKindOfClass:NSString.class] ? FXPatchEvents(FXPatchReady(msg)) : msg; }

static BOOL FXFirstHook(const char *cls, const char *sel) {
    static NSMutableSet *h; static dispatch_once_t o;
    dispatch_once(&o, ^{ h = [NSMutableSet set]; });
    NSString *k = [NSString stringWithFormat:@"%s|%s", cls, sel];
    @synchronized (h) { if ([h containsObject:k]) return NO; [h addObject:k]; }
    return YES;
}

static void FXHookWSLog(Class c, Method m, const char *cn, const char *sn, BOOL allowSend) {
    SEL sel = method_getName(m);
    IMP orig = method_getImplementation(m);
    NSString *name = @(sn);
    if ([name isEqualToString:@"webSocketDidOpen:"]) {
        class_replaceMethod(c, sel, imp_implementationWithBlock(^void(id s, id ws) {
            FXFileLog(@"WS OPEN %@", FXWSURL(ws));
            ((void (*)(id, SEL, id))orig)(s, sel, ws);
        }), method_getTypeEncoding(m));
    } else if ([name isEqualToString:@"webSocket:didFailWithError:"]) {
        class_replaceMethod(c, sel, imp_implementationWithBlock(^void(id s, id ws, NSError *err) {
            FXFileLog(@"WS FAIL %@ code=%ld %@ (%@)", err.domain, (long)err.code, err.localizedDescription, FXWSURL(ws));
            ((void (*)(id, SEL, id, id))orig)(s, sel, ws, err);
        }), method_getTypeEncoding(m));
    } else if ([name isEqualToString:@"webSocket:didCloseWithCode:reason:wasClean:"]) {
        class_replaceMethod(c, sel, imp_implementationWithBlock(^void(id s, id ws, NSInteger code, id reason, BOOL clean) {
            FXFileLog(@"WS CLOSE code=%ld reason=%@ clean=%d (%@)", (long)code, reason, clean, FXWSURL(ws));
            ((void (*)(id, SEL, id, NSInteger, id, BOOL))orig)(s, sel, ws, code, reason, clean);
        }), method_getTypeEncoding(m));
    } else if ([name isEqualToString:@"webSocket:didReceiveMessage:"]) {
        class_replaceMethod(c, sel, imp_implementationWithBlock(^void(id s, id ws, id msg) {
            id out = FXPatchGatewayIn(msg);
            FXFileLog(@"WS RECV %@", FXFrame(out));
            ((void (*)(id, SEL, id, id))orig)(s, sel, ws, out);
        }), method_getTypeEncoding(m));
    } else if (allowSend && ([name isEqualToString:@"send:"] || [name isEqualToString:@"sendString:error:"] || [name isEqualToString:@"sendData:error:"])) {
        if (method_getNumberOfArguments(m) == 3) {
            class_replaceMethod(c, sel, imp_implementationWithBlock(^uintptr_t(id s, id msg) {
                id out = FXXformSendPayload(msg);
                if (out == FXDropSentinel()) return 1;
                FXFileLog(@"WS SEND %@", FXFrame(out));
                return ((uintptr_t (*)(id, SEL, id))orig)(s, sel, out);
            }), method_getTypeEncoding(m));
        } else {
            class_replaceMethod(c, sel, imp_implementationWithBlock(^uintptr_t(id s, id msg, uintptr_t e) {
                id out = FXXformSendPayload(msg);
                if (out == FXDropSentinel()) return 1;
                FXFileLog(@"WS SEND %@", FXFrame(out));
                return ((uintptr_t (*)(id, SEL, id, uintptr_t))orig)(s, sel, out, e);
            }), method_getTypeEncoding(m));
        }
    } else return;
    FXFileLog(@"  logging -[%s %s]", cn, sn);
}

static void FXHookWebSocketClasses(void) {
    unsigned cnt = 0;
    Class *all = objc_copyClassList(&cnt);
    for (unsigned i = 0; i < cnt; i++) {
        Class c = all[i];
        const char *nm = class_getName(c);
        if (!nm || !strcasestr(nm, "websocket")) continue;
        if (!strncmp(nm, "NS", 2) || !strncmp(nm, "__NS", 4) || !strncmp(nm, "_NS", 3)) continue;
        BOOL known = !strcmp(nm, "SRWebSocket") || !strcmp(nm, "RCTWebSocketModule");   // URL init already hooked by FXInstallHooks
        unsigned mc = 0;
        Method *ms = class_copyMethodList(c, &mc);
        for (unsigned j = 0; j < mc; j++) {
            const char *sn = sel_getName(method_getName(ms[j]));
            if (!strcmp(sn, "webSocketDidOpen:") || !strcmp(sn, "webSocket:didFailWithError:") ||
                !strcmp(sn, "webSocket:didCloseWithCode:reason:wasClean:") || !strcmp(sn, "webSocket:didReceiveMessage:") ||
                !strcmp(sn, "send:") || !strcmp(sn, "sendString:error:") || !strcmp(sn, "sendData:error:")) {
                if (FXFirstHook(nm, sn)) FXHookWSLog(c, ms[j], nm, sn, YES);
                continue;
            }
            if (known) continue;
            if (!(strstr(sn, "URL") || strstr(sn, "Url") || strstr(sn, "Request"))) continue;
            if (!(!strncmp(sn, "init", 4) || strstr(sn, "onnect") || strstr(sn, "pen"))) continue;
            unsigned na = method_getNumberOfArguments(ms[j]);
            if (na < 3 || na > 5) continue;
            BOOL ok = YES;
            char *a0 = method_copyArgumentType(ms[j], 2);
            if (!a0 || a0[0] != '@') ok = NO;
            free(a0);
            for (unsigned k = 3; k < na && ok; k++) {
                char *t = method_copyArgumentType(ms[j], k);
                if (!t || t[0] == 'd' || t[0] == 'f' || t[0] == '{') ok = NO;
                free(t);
            }
            char *rt = method_copyReturnType(ms[j]);
            if (!rt || !strchr("@vBc", rt[0])) ok = NO;
            free(rt);
            if (!ok || !FXFirstHook(nm, sn)) continue;
            FXFileLog(@"  hooked -[%s %s]", nm, sn);
            FXHookGeneric(c, ms[j]);
        }
        free(ms);
    }
    free(all);
}

// URL construction hooks, websocket URLs only (so nothing else is touched).
static void FXHookURLConstruction(void) {
    @try {
        Class meta = object_getClass(NSURL.class);
        Method m = class_getInstanceMethod(meta, @selector(URLWithString:));
        if (m) {
            IMP orig = method_getImplementation(m);
            class_replaceMethod(meta, @selector(URLWithString:), imp_implementationWithBlock(^id(id s, NSString *str) {
                NSURL *u = ((id (*)(id, SEL, id))orig)(s, @selector(URLWithString:), str);
                return FXIsWSScheme(u) ? (FXRewriteURL(u, YES) ?: u) : u;
            }), method_getTypeEncoding(m));
        }
        m = class_getInstanceMethod(NSMutableURLRequest.class, @selector(setURL:));
        if (m) {
            IMP orig = method_getImplementation(m);
            class_replaceMethod(NSMutableURLRequest.class, @selector(setURL:), imp_implementationWithBlock(^void(id s, NSURL *u) {
                ((void (*)(id, SEL, id))orig)(s, @selector(setURL:), FXIsWSScheme(u) ? (FXRewriteURL(u, YES) ?: u) : u);
            }), method_getTypeEncoding(m));
        }
        m = class_getInstanceMethod(NSURLRequest.class, @selector(initWithURL:cachePolicy:timeoutInterval:));
        if (m) {
            IMP orig = method_getImplementation(m);
            class_replaceMethod(NSURLRequest.class, @selector(initWithURL:cachePolicy:timeoutInterval:), imp_implementationWithBlock(^uintptr_t(id s, NSURL *u, NSUInteger p, NSTimeInterval t) {
                return ((uintptr_t (*)(id, SEL, id, NSUInteger, NSTimeInterval))orig)(s, @selector(initWithURL:cachePolicy:timeoutInterval:), FXIsWSScheme(u) ? (FXRewriteURL(u, YES) ?: u) : u, p, t);
            }), method_getTypeEncoding(m));
        }
        FXFileLog(@"url construction hooks installed (ws only)");
    } @catch (NSException *e) { FXFileLog(@"url construction hook exception: %@", e); }
}

#pragma mark - API proxy (rate-limit header fixes, telemetry short-circuit, typing/ack throttle)

// Fluxer's X-RateLimit-Reset is a UNIX time in MILLISECONDS and there is no X-RateLimit-Reset-After, while the
// Discord app reads those as seconds. Converted naively that locks the client out for "years" after one
// 429 (or after any response, if the phone's clock is off). Normalise the headers and the 429 body here.
static NSString *const kFXHandled = @"FluxerRedirect.handled";

static NSString *FXAPIHost(void) {
    NSString *a = gAPI;
    return a.length ? [NSURLComponents componentsWithString:a].host.lowercaseString : nil;
}

static NSString *FXMaskPath(NSString *path) {
    static NSRegularExpression *re; static dispatch_once_t o;
    dispatch_once(&o, ^{ re = [NSRegularExpression regularExpressionWithPattern:@"[0-9]{15,}" options:0 error:nil]; });
    return [re stringByReplacingMatchesInString:path ?: @"" options:0 range:NSMakeRange(0, path.length) withTemplate:@"{id}"];
}

static BOOL FXAllowEvery(NSString *key, NSTimeInterval gap) {
    static NSMutableDictionary *last; static NSObject *lock; static dispatch_once_t o;
    dispatch_once(&o, ^{ last = [NSMutableDictionary dictionary]; lock = [NSObject new]; });
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    @synchronized (lock) {
        NSNumber *t = last[key];
        if (t && now - t.doubleValue < gap) return NO;
        last[key] = @(now);
        if (last.count > 500) [last removeAllObjects];
    }
    return YES;
}

static BOOL FXLogOnce(NSString *key) {
    static NSMutableSet *seen; static NSObject *lock; static dispatch_once_t o;
    dispatch_once(&o, ^{ seen = [NSMutableSet set]; lock = [NSObject new]; });
    @synchronized (lock) { if ([seen containsObject:key] || seen.count > 300) return NO; [seen addObject:key]; }
    return YES;
}

static void FXInitUploadURLRegistry(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gUploadURLLock = [NSObject new];
        gUploadURLInfo = [NSMutableDictionary dictionary];
    });
}

static NSDictionary *FXUploadInfoForURL(NSURL *url) {
    if (!url.absoluteString.length) return nil;
    FXInitUploadURLRegistry();
    @synchronized (gUploadURLLock) {
        return gUploadURLInfo[url.absoluteString];
    }
}

static void FXRememberUploadURLs(NSData *data) {
    if (!data.length) return;
    id root = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![root isKindOfClass:NSDictionary.class]) return;
    id uploads = root[@"attachments"];
    if (![uploads isKindOfClass:NSArray.class]) return;

    FXInitUploadURLRegistry();
    NSUInteger saved = 0;
    @synchronized (gUploadURLLock) {
        for (id item in uploads) {
            if (![item isKindOfClass:NSDictionary.class]) continue;
            NSString *contentType = [item[@"content_type"] isKindOfClass:NSString.class]
                ? item[@"content_type"] : nil;
            NSString *singleURL = [item[@"upload_url"] isKindOfClass:NSString.class]
                ? item[@"upload_url"] : nil;
            if (singleURL.length) {
                NSURLComponents *u = [NSURLComponents componentsWithString:singleURL];
                if ([u.scheme.lowercaseString isEqualToString:@"https"] && u.host.length) {
                    gUploadURLInfo[singleURL] = contentType.length ? @{@"content_type": contentType} : @{};
                    saved++;
                }
            }
            id parts = item[@"parts"];
            if ([parts isKindOfClass:NSArray.class]) {
                for (id part in parts) {
                    NSString *partURL = [part isKindOfClass:NSDictionary.class] &&
                        [part[@"upload_url"] isKindOfClass:NSString.class] ? part[@"upload_url"] : nil;
                    if (partURL.length) {
                        NSURLComponents *u = [NSURLComponents componentsWithString:partURL];
                        if ([u.scheme.lowercaseString isEqualToString:@"https"] && u.host.length) {
                            gUploadURLInfo[partURL] = contentType.length ? @{@"content_type": contentType} : @{};
                            saved++;
                        }
                    }
                }
            }
        }
        if (gUploadURLInfo.count > 512) {
            NSArray *keys = gUploadURLInfo.allKeys;
            NSUInteger removeCount = gUploadURLInfo.count - 384;
            for (NSUInteger i = 0; i < removeCount && i < keys.count; i++)
                [gUploadURLInfo removeObjectForKey:keys[i]];
        }
    }
    if (saved && FXLogOnce(@"signed-upload-urls"))
        FXFileLog(@"upload: registered signed upload destinations=%lu (URLs hidden)", (unsigned long)saved);
}

static NSData *FXReadStream(NSInputStream *in) {
    if (!in) return nil;
    NSMutableData *out = [NSMutableData data];
    [in open];
    uint8_t buf[8192]; NSInteger n;
    while ((n = [in read:buf maxLength:sizeof buf]) > 0) {
        [out appendBytes:buf length:(NSUInteger)n];
        if (out.length > 8u * 1024 * 1024) break;
    }
    [in close];
    return out;
}

static NSString *FXUploadMIMEForFilename(NSString *filename) {
    NSString *f = filename.lowercaseString ?: @"";
    if ([f hasSuffix:@".png"]) return @"image/png";
    if ([f hasSuffix:@".jpg"] || [f hasSuffix:@".jpeg"]) return @"image/jpeg";
    if ([f hasSuffix:@".gif"]) return @"image/gif";
    if ([f hasSuffix:@".webp"]) return @"image/webp";
    if ([f hasSuffix:@".heic"]) return @"image/heic";
    if ([f hasSuffix:@".heif"]) return @"image/heif";
    if ([f hasSuffix:@".avif"]) return @"image/avif";
    if ([f hasSuffix:@".mp4"] || [f hasSuffix:@".m4v"]) return @"video/mp4";
    if ([f hasSuffix:@".mov"]) return @"video/quicktime";
    if ([f hasSuffix:@".webm"]) return @"video/webm";
    if ([f hasSuffix:@".mp3"]) return @"audio/mpeg";
    if ([f hasSuffix:@".m4a"]) return @"audio/mp4";
    if ([f hasSuffix:@".ogg"] || [f hasSuffix:@".opus"]) return @"audio/ogg";
    if ([f hasSuffix:@".wav"]) return @"audio/wav";
    if ([f hasSuffix:@".pdf"]) return @"application/pdf";
    if ([f hasSuffix:@".txt"]) return @"text/plain";
    return @"application/octet-stream";
}

static NSData *FXNormalizeUploadPlanBody(NSData *body) {
    if (!body.length) return body;
    id root = [NSJSONSerialization JSONObjectWithData:body options:NSJSONReadingMutableContainers error:nil];
    if (![root isKindOfClass:NSMutableDictionary.class]) return body;
    NSMutableDictionary *obj = root;
    id items = [obj[@"attachments"] isKindOfClass:NSArray.class] ? obj[@"attachments"] : obj[@"files"];
    if (![items isKindOfClass:NSArray.class]) return body;
    NSMutableArray *fixed = [NSMutableArray array];
    NSUInteger index = 0;
    for (id item in items) {
        if (![item isKindOfClass:NSDictionary.class]) { index++; continue; }
        NSMutableDictionary *a = [item mutableCopy];
        if (!a[@"id"]) a[@"id"] = @(index);
        if (!a[@"file_size"]) {
            id size = a[@"size"];
            if ([size isKindOfClass:NSNumber.class]) a[@"file_size"] = size;
            else if ([size isKindOfClass:NSString.class] && [(NSString *)size length] &&
                     [[NSScanner scannerWithString:size] scanLongLong:NULL]) a[@"file_size"] = @([(NSString *)size longLongValue]);
        }
        if (![a[@"filename"] isKindOfClass:NSString.class]) a[@"filename"] = [NSString stringWithFormat:@"upload-%lu.bin", (unsigned long)index];
        if (![a[@"content_type"] isKindOfClass:NSString.class] || ![a[@"content_type"] length])
            a[@"content_type"] = FXUploadMIMEForFilename(a[@"filename"]);
        [fixed addObject:a];
        index++;
    }
    if (!fixed.count) return body;
    obj[@"attachments"] = fixed;
    [obj removeObjectForKey:@"files"];
    NSData *out = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingWithoutEscapingSlashes error:nil];
    return out ?: body;
}

static NSData *FXNormalizeRL(NSMutableDictionary *h, NSInteger status, NSData *body, NSString *method, NSString *path) {
    NSString *(^get)(NSString *) = ^NSString *(NSString *name) {
        for (id k in h.allKeys) if ([[k description] caseInsensitiveCompare:name] == NSOrderedSame) return [h[k] description];
        return nil;
    };
    void (^set)(NSString *, NSString *) = ^(NSString *name, NSString *val) {
        for (id k in h.allKeys) if ([[k description] caseInsensitiveCompare:name] == NSOrderedSame) [h removeObjectForKey:k];
        h[name] = val;
    };
    double nowDev = [NSDate date].timeIntervalSince1970, serverNow = nowDev;
    NSString *dh = get(@"date");
    if (dh.length) {
        static NSDateFormatter *df; static dispatch_once_t o;
        dispatch_once(&o, ^{ df = [NSDateFormatter new]; df.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
                              df.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0]; df.dateFormat = @"EEE, dd MMM yyyy HH:mm:ss zzz"; });
        NSDate *sd = [df dateFromString:dh];
        if (sd) serverNow = sd.timeIntervalSince1970;
    }
    NSString *reset = get(@"x-ratelimit-reset");
    if (reset.length) {
        double r = reset.doubleValue, after;
        if (r > 1e11) after = r / 1000.0 - serverNow;       // ms timestamp (Fluxer)
        else if (r > 1e9) after = r - serverNow;            // seconds timestamp (Discord)
        else after = r;                                      // already relative
        after = MIN(3600.0, MAX(0.0, after));
        set(@"X-RateLimit-Reset", [NSString stringWithFormat:@"%.3f", nowDev + after]);   // on the phone's own clock
        if (!get(@"x-ratelimit-reset-after")) set(@"X-RateLimit-Reset-After", [NSString stringWithFormat:@"%.3f", after]);
    }
    if (status == 429) {
        id j = body.length ? [NSJSONSerialization JSONObjectWithData:body options:NSJSONReadingMutableContainers error:nil] : nil;
        NSMutableDictionary *jd = [j isKindOfClass:NSMutableDictionary.class] ? j : [NSMutableDictionary dictionary];
        double ra = [jd[@"retry_after"] isKindOfClass:NSNumber.class] ? [jd[@"retry_after"] doubleValue] : 0;
        if (ra <= 0) ra = [get(@"retry-after") doubleValue];
        if (ra <= 0) ra = 1;
        jd[@"retry_after"] = @(ra);
        if (![jd[@"global"] isKindOfClass:NSNumber.class]) {
            NSString *scope = get(@"x-ratelimit-scope");
            NSString *globalHeader = get(@"x-ratelimit-global");
            BOOL isGlobal = [scope caseInsensitiveCompare:@"global"] == NSOrderedSame ||
                            [globalHeader caseInsensitiveCompare:@"true"] == NSOrderedSame;
            jd[@"global"] = @(isGlobal);
        }
        if (![jd[@"message"] isKindOfClass:NSString.class]) jd[@"message"] = @"You are being rate limited.";
        set(@"Retry-After", [NSString stringWithFormat:@"%.0f", ceil(ra)]);
        if ([jd[@"global"] boolValue]) set(@"X-RateLimit-Global", @"true");
        FXFileLog(@"HTTP 429 %@ %@ retry_after=%.2f global=%@ bucket=%@ remaining=%@ limit=%@", method, FXMaskPath(path), ra,
                  [jd[@"global"] boolValue] ? @"yes" : @"no", get(@"x-ratelimit-bucket") ?: @"-", get(@"x-ratelimit-remaining") ?: @"-", get(@"x-ratelimit-limit") ?: @"-");
        NSData *nb = [NSJSONSerialization dataWithJSONObject:jd options:0 error:nil];
        if (nb) return nb;
    }
    return body;
}

// Discord's message renderer expects proxy_url and a few stable attachment fields.
// Fluxer supplies signed url/proxy_url fields, but older instances and some media
// responses omit proxy_url or content_type. Fill only safe, derivable metadata.
static BOOL FXFixAttachmentObject(NSMutableDictionary *a) {
    if (!a) return NO;
    BOOL changed = NO;
    id url = a[@"url"];
    if ((!a[@"proxy_url"] || a[@"proxy_url"] == NSNull.null) && [url isKindOfClass:NSString.class]) {
        a[@"proxy_url"] = url; changed = YES;
    }
    if (![a[@"filename"] isKindOfClass:NSString.class] || ![a[@"filename"] length]) {
        NSString *u = [url isKindOfClass:NSString.class] ? url : nil;
        NSString *last = u.length ? [NSURL URLWithString:u].lastPathComponent : nil;
        if (last.length) { a[@"filename"] = last; changed = YES; }
    }
    if (![a[@"content_type"] isKindOfClass:NSString.class]) {
        NSString *f = [a[@"filename"] isKindOfClass:NSString.class] ? [a[@"filename"] lowercaseString] : @"";
        NSString *mime = FXUploadMIMEForFilename(f);
        if (![mime isEqualToString:@"application/octet-stream"]) { a[@"content_type"] = mime; changed = YES; }
    }
    if (![a[@"size"] isKindOfClass:NSNumber.class] && [a[@"file_size"] isKindOfClass:NSNumber.class]) {
        a[@"size"] = a[@"file_size"]; changed = YES;
    }
    return changed;
}

static BOOL FXFixMessageObject(NSMutableDictionary *m) {
    if (!m) return NO;
    BOOL changed = NO;
    NSArray *attachments = [m[@"attachments"] isKindOfClass:NSArray.class] ? m[@"attachments"] : nil;
    for (id item in attachments) if (FXFixAttachmentObject(FXMut(item))) changed = YES;
    return changed;
}

// Fluxer flips the order of a message page when `after` is used; Discord's client always expects newest first.
static NSData *FXFixSingleMessage(NSData *data) {
    id root = data.length ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil] : nil;
    if (![root isKindOfClass:NSMutableDictionary.class]) return data;
    FXCacheUser(root[@"author"]);
    if (!FXFixMessageObject((NSMutableDictionary *)root)) return data;
    NSData *out = [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingWithoutEscapingSlashes error:nil];
    return out ?: data;
}

static NSData *FXFixMessageList(NSData *data) {
    id j = data.length ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil] : nil;
    if (![j isKindOfClass:NSArray.class]) return data;
    BOOL changed = NO;
    for (id x in j) {
        if (![x isKindOfClass:NSDictionary.class]) continue;
        FXCacheUser(x[@"author"]);
        if (FXFixMessageObject(FXMut(x))) changed = YES;
    }
    if ([j count] > 1) {
        NSInteger (^cmp)(id, id) = ^NSInteger(id a, id b) {
            NSString *x = [a isKindOfClass:NSDictionary.class] ? FXS(a[@"id"]) : nil;
            NSString *y = [b isKindOfClass:NSDictionary.class] ? FXS(b[@"id"]) : nil;
            if (!x || !y) return 0;
            if (x.length != y.length) return x.length < y.length ? -1 : 1;
            return [x compare:y];
        };
        BOOL desc = YES;
        for (NSUInteger i = 1; i < [j count]; i++) if (cmp(j[i - 1], j[i]) < 0) { desc = NO; break; }
        if (!desc) {
            j = [j sortedArrayUsingComparator:^NSComparisonResult(id a, id b) { return (NSComparisonResult)(-cmp(a, b)); }];
            changed = YES;
            if (FXLogOnce(@"msgorder")) FXFileLog(@"message list was not newest-first (Fluxer reverses `after` pages): re-sorted");
        }
    }
    if (!changed) return data;
    NSData *out = [NSJSONSerialization dataWithJSONObject:j options:NSJSONWritingWithoutEscapingSlashes error:nil];
    return out ?: data;
}

static NSData *FXFixProfileBadges(NSData *data) {
    if (!data.length) return data;
    id parsed = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSMutableDictionary *root = FXMut(parsed);
    if (!root) return data;

    NSArray *source = [root[@"profile_badges"] isKindOfClass:NSArray.class] ? root[@"profile_badges"] : nil;
    if (!source && [root[@"badges"] isKindOfClass:NSArray.class]) source = root[@"badges"];
    if (source) {
        NSMutableArray *badges = [NSMutableArray arrayWithCapacity:source.count];
        for (id item in source) {
            if (![item isKindOfClass:NSDictionary.class]) continue;
            NSMutableDictionary *badge = [item mutableCopy];
            id key = badge[@"key"] ?: badge[@"kind"];
            id label = badge[@"label"] ?: badge[@"accessible_label"];
            NSString *asset = [badge[@"asset"] isKindOfClass:NSString.class] ? badge[@"asset"] : nil;
            NSString *assetURL = [badge[@"asset_url"] isKindOfClass:NSString.class] ? badge[@"asset_url"] : nil;
            NSString *icon = asset;
            if (!icon.length && assetURL.length)
                icon = FXRegisterCustomBadgeURL([key isKindOfClass:NSString.class] ? key : @"custom", assetURL);
            id link = badge[@"href"];
            if ([key isKindOfClass:NSString.class]) badge[@"id"] = key;
            if ([label isKindOfClass:NSString.class]) badge[@"description"] = label;
            if (icon.length) badge[@"icon"] = icon;
            if ([link isKindOfClass:NSString.class]) badge[@"link"] = link;
            if ([badge[@"caption"] isKindOfClass:NSString.class]) badge[@"text"] = badge[@"caption"];
            [badges addObject:badge];
        }
        root[@"badges"] = badges;
    }

    NSMutableDictionary *user = FXMut(root[@"user"]);
    if (user) FXNormalizeUserBadgeFlags(user);
    NSData *out = [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingWithoutEscapingSlashes error:nil];
    return out ?: data;
}

static NSURLRequest *FXRewriteGIFRequest(NSURLRequest *request) {
    NSURL *url = request.URL;
    if (!url) return request;
    NSString *method = request.HTTPMethod.uppercaseString ?: @"GET";
    NSURLComponents *c = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
    NSString *path = c.percentEncodedPath ?: @"";
    NSString *replacement = nil;
    BOOL get = [method isEqualToString:@"GET"];
    if (get && [path hasSuffix:@"/gifs/trending-search"]) {
        // Discord's picker home is Fluxer's featured response: {gifs, categories}.
        replacement = @"/gifs/featured";
    } else if (get && [path hasSuffix:@"/gifs/trending-gifs"]) {
        replacement = @"/gifs/trending";
    } else if ([method isEqualToString:@"POST"] && [path hasSuffix:@"/gifs/select"]) {
        // Discord sends {id, q}; Fluxer accepts the same fields at register-share.
        replacement = @"/gifs/register-share";
    }
    if (!replacement) return request;
    NSRange range = [path rangeOfString:@"/gifs/" options:NSBackwardsSearch];
    if (range.location == NSNotFound) return request;
    c.percentEncodedPath = [[path substringToIndex:range.location] stringByAppendingString:replacement];
    NSSet *allowed = ([replacement isEqualToString:@"/gifs/featured"] ||
                      [replacement isEqualToString:@"/gifs/trending"])
        ? [NSSet setWithArray:@[@"locale"]]
        : [NSSet setWithArray:@[@"q", @"locale"]];
    NSMutableArray *query = [NSMutableArray array];
    for (NSURLQueryItem *item in c.queryItems ?: @[]) {
        if ([allowed containsObject:item.name.lowercaseString]) [query addObject:item];
    }
    c.queryItems = query.count ? query : nil;
    NSMutableURLRequest *out = [request mutableCopy];
    out.URL = c.URL;
    return out;
}

// Discord's profile editor sends extra decoration/client-only keys that Fluxer does not
// accept. Keep the real profile fields supported by Fluxer's Modify Current User API.
static NSData *FXNormalizeProfilePatch(NSData *body) {
    if (!body.length) return body;
    id json = [NSJSONSerialization JSONObjectWithData:body options:NSJSONReadingMutableContainers error:nil];
    if (![json isKindOfClass:NSDictionary.class]) return body;
    NSDictionary *input = (NSDictionary *)json;
    static NSSet *allowed;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        allowed = [NSSet setWithArray:@[
            @"username", @"discriminator", @"global_name", @"avatar", @"banner", @"bio",
            @"pronouns", @"accent_color", @"timezone", @"timezone_privacy_flags",
            @"hidden_profile_badges", @"premium_badge_hidden", @"premium_badge_masked",
            @"premium_badge_timestamp_hidden", @"premium_badge_sequence_hidden",
            @"premium_enabled_override", @"has_dismissed_premium_onboarding",
            @"has_unread_gift_inventory", @"mention_flags", @"password", @"new_password",
            @"email_token", @"mfa_method", @"mfa_code", @"webauthn_response",
            @"webauthn_challenge", @"email_code_ticket", @"email_code"
        ]];
    });
    NSMutableDictionary *output = [NSMutableDictionary dictionary];
    NSMutableArray *dropped = [NSMutableArray array];
    for (id key in input) {
        if (![key isKindOfClass:NSString.class]) continue;
        if ([allowed containsObject:key]) output[key] = input[key] ?: NSNull.null;
        else [dropped addObject:key];
    }
    if (!output.count) return body;
    if (dropped.count) FXFileLog(@"profile PATCH removed unsupported Discord-only fields: %@", [dropped componentsJoinedByString:@","]);
    NSData *normalized = [NSJSONSerialization dataWithJSONObject:output options:NSJSONWritingWithoutEscapingSlashes error:nil];
    return normalized ?: body;
}

static BOOL FXOptionalDiscordStub(NSString *method, NSString *path, NSInteger *status, NSData **body) {
    if (![method isEqualToString:@"GET"]) return NO;
    static NSArray<NSString *> *patterns;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        patterns = @[
            @"^/api/v1/users/@me/join-request-guilds$",
            @"^/api/v1/quests/@me$",
            @"^/api/v1/users/@me/affinities/guilds$",
            @"^/api/v1/users/@me/entitlements$",
            @"^/api/v1/users/@me/applications/[0-9]+/entitlements$",
            @"^/api/v1/guilds/[0-9]+/top-emojis$"
        ];
    });
    for (NSString *pattern in patterns) {
        NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:nil];
        if ([re firstMatchInString:path options:0 range:NSMakeRange(0, path.length)]) {
            if (status) *status = 200;
            if (body) *body = [@"[]" dataUsingEncoding:NSUTF8StringEncoding];
            if (FXLogOnce([@"stub:" stringByAppendingString:path]))
                FXFileLog(@"optional Discord collection endpoint stubbed as empty array: %@", FXMaskPath(path));
            return YES;
        }
    }
    return NO;
}

static NSString *FXBadgeSourceForToken(NSString *token) {
    if (!token.length) return nil;
    FXInitBadgeURLRegistry();
    @synchronized (gBadgeURLLock) { return [gBadgeURLInfo[token] copy]; }
}

static NSData *FXVectorizeBadgeWebP(NSData *webp) {
    if (!webp.length) return nil;
    NSString *encoded = [webp base64EncodedStringWithOptions:0];
    if (!encoded.length) return nil;
    NSString *svgString = [NSString stringWithFormat:
        @"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"100%%\" height=\"100%%\" viewBox=\"0 0 1 1\"><image x=\"0\" y=\"0\" width=\"1\" height=\"1\" preserveAspectRatio=\"none\" href=\"data:image/webp;base64,%@\" xlink:href=\"data:image/webp;base64,%@\"/></svg>", encoded, encoded];
    return [svgString dataUsingEncoding:NSUTF8StringEncoding];
}

@interface FXBadgeSVGProtocol : NSURLProtocol
@property (nonatomic, strong) NSURLSessionDataTask *task;
@end

@implementation FXBadgeSVGProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    if ([NSURLProtocol propertyForKey:kFXBadgeProtocolHandled inRequest:request]) return NO;
    NSString *host = request.URL.host.lowercaseString;
    if (!host.length || !gStatic.length || ![host isEqualToString:[NSURL URLWithString:gStatic].host.lowercaseString]) return NO;
    NSString *name = request.URL.lastPathComponent.stringByDeletingPathExtension;
    return [name hasPrefix:@"fxcustom_"] && FXBadgeSourceForToken(name).length > 0;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading {
    NSString *name = self.request.URL.lastPathComponent.stringByDeletingPathExtension;
    NSString *source = FXBadgeSourceForToken(name);
    NSURL *sourceURL = [NSURL URLWithString:source];
    if (!sourceURL || ![sourceURL.scheme.lowercaseString isEqualToString:@"https"]) {
        [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorBadURL userInfo:nil]];
        return;
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:sourceURL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    [NSURLProtocol setProperty:@YES forKey:kFXBadgeProtocolHandled inRequest:request];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    configuration.HTTPShouldSetCookies = NO;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration];
    self.task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error || ![response isKindOfClass:NSHTTPURLResponse.class] || ((NSHTTPURLResponse *)response).statusCode < 200 || ((NSHTTPURLResponse *)response).statusCode >= 300) {
            [self.client URLProtocol:self didFailWithError:error ?: [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorBadServerResponse userInfo:nil]];
            [session finishTasksAndInvalidate];
            return;
        }
        NSData *svg = FXVectorizeBadgeWebP(data);
        if (!svg.length) {
            [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorCannotDecodeContentData userInfo:nil]];
            [session finishTasksAndInvalidate];
            return;
        }
        NSDictionary *headers = @{@"Content-Type": @"image/svg+xml", @"Content-Length": @(svg.length).stringValue, @"Cache-Control": @"public, max-age=3600"};
        NSHTTPURLResponse *result = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:headers];
        [self.client URLProtocol:self didReceiveResponse:result cacheStoragePolicy:NSURLCacheStorageAllowed];
        [self.client URLProtocol:self didLoadData:svg];
        [self.client URLProtocolDidFinishLoading:self];
        [session finishTasksAndInvalidate];
    }];
    [self.task resume];
}
- (void)stopLoading { [self.task cancel]; self.task = nil; }
@end

@interface FXApiProtocol : NSURLProtocol
@property (nonatomic, strong) NSURLSessionDataTask *task;
@end

@implementation FXApiProtocol

+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    NSString *host = FXAPIHost();
    if (!host.length || [NSURLProtocol propertyForKey:kFXHandled inRequest:request]) return NO;
    NSString *sc = request.URL.scheme.lowercaseString;
    if (![sc isEqualToString:@"https"] && ![sc isEqualToString:@"http"]) return NO;
    if (![request.URL.host.lowercaseString isEqualToString:host]) return NO;
    if ([[request valueForHTTPHeaderField:@"Content-Type"].lowercaseString containsString:@"multipart"]) return NO;   // uploads go straight through
    return YES;
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }

+ (NSURLSession *)innerSession {
    static NSURLSession *s; static dispatch_once_t o;
    dispatch_once(&o, ^{
        NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        cfg.timeoutIntervalForRequest = 60;
        cfg.HTTPShouldSetCookies = NO;
        s = [NSURLSession sessionWithConfiguration:cfg];
    });
    return s;
}

- (void)relayStatus:(NSInteger)status headers:(NSDictionary *)hdr body:(NSData *)body {
    NSMutableDictionary *h = [NSMutableDictionary dictionary];
    for (id k in hdr) {
        NSString *lk = [[k description] lowercaseString];
        if ([lk isEqualToString:@"content-encoding"] || [lk isEqualToString:@"content-length"] || [lk isEqualToString:@"transfer-encoding"]) continue;
        h[[k description]] = hdr[k];
    }
    NSString *path = self.request.URL.path ?: @"";
    body = FXNormalizeRL(h, status, body, self.request.HTTPMethod ?: @"GET", path);
    h[@"Content-Length"] = @(body.length).stringValue;
    NSHTTPURLResponse *nr = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:status HTTPVersion:@"HTTP/1.1" headerFields:h];
    [self.client URLProtocol:self didReceiveResponse:nr cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    if (body.length) [self.client URLProtocol:self didLoadData:body];
    [self.client URLProtocolDidFinishLoading:self];
}

- (void)startLoading {
    NSURLRequest *req = self.request;
    NSString *method = req.HTTPMethod ?: @"GET";
    NSString *path = (req.URL.path ?: @"").lowercaseString;
    BOOL post = [method isEqualToString:@"POST"];
    if (post && ([path hasSuffix:@"/science"] || [path hasSuffix:@"/track"] || [path hasSuffix:@"/metrics"])) {
        if (FXLogOnce(@"telemetry")) FXFileLog(@"swallowing Discord telemetry POST %@ (Fluxer has no such endpoint)", FXMaskPath(path));
        [self relayStatus:204 headers:@{} body:[NSData data]];
        return;
    }
    NSInteger stubStatus = 0;
    NSData *stubBody = nil;
    if (FXOptionalDiscordStub(method, path, &stubStatus, &stubBody)) {
        [self relayStatus:stubStatus headers:@{@"Content-Type": @"application/json"} body:stubBody ?: [NSData data]];
        return;
    }
    if (post && [path rangeOfString:@"/channels/[0-9]+/typing$" options:NSRegularExpressionSearch].location != NSNotFound && !FXAllowEvery(path, 8.0)) {
        [self relayStatus:204 headers:@{} body:[NSData data]];
        return;
    }
    if (post && [path hasSuffix:@"/ack"] && !FXAllowEvery(path, 2.0)) {
        [self relayStatus:200 headers:@{@"Content-Type": @"application/json"} body:[@"{\"token\":null}" dataUsingEncoding:NSUTF8StringEncoding]];
        return;
    }
    NSMutableURLRequest *r = [FXRewriteGIFRequest(req) mutableCopy];
    if (!r) r = [req mutableCopy];
    if ([path containsString:@"/attachments"] && FXLogOnce([NSString stringWithFormat:@"upload-request:%@:%@", method, path])) {
        FXFileLog(@"attachment request method=%@ content_type=%@ body_bytes=%lu body_stream=%@ (body contents omitted)", method,
                  [r valueForHTTPHeaderField:@"Content-Type"] ?: @"-", (unsigned long)r.HTTPBody.length,
                  r.HTTPBodyStream ? @"yes" : @"no");
    }
    if (![r.URL isEqual:req.URL]) FXFileLog(@"GIF picker route mapped %@ -> %@", FXMaskPath(req.URL.path), FXMaskPath(r.URL.path));
    [NSURLProtocol setProperty:@YES forKey:kFXHandled inRequest:r];
    if (!r.HTTPBody && r.HTTPBodyStream) { NSData *b = FXReadStream(r.HTTPBodyStream); r.HTTPBodyStream = nil; r.HTTPBody = b; }
    if ([method isEqualToString:@"PATCH"] && ([path hasSuffix:@"/users/@me"] || [path hasSuffix:@"/users/@me/"])) {
        NSData *beforeProfile = r.HTTPBody;
        NSData *afterProfile = FXNormalizeProfilePatch(beforeProfile);
        if (afterProfile != beforeProfile && ![afterProfile isEqualToData:beforeProfile]) {
            r.HTTPBody = afterProfile;
            [r setValue:@(afterProfile.length).stringValue forHTTPHeaderField:@"Content-Length"];
            FXFileLog(@"normalized current-user profile PATCH payload");
        }
    }
    if (post && [path rangeOfString:@"/channels/[0-9]+/attachments$" options:NSRegularExpressionSearch].location != NSNotFound &&
        [r valueForHTTPHeaderField:@"Content-Type"].lowercaseString.length &&
        ![[r valueForHTTPHeaderField:@"Content-Type"].lowercaseString containsString:@"multipart"]) {
        NSData *before = r.HTTPBody;
        NSData *after = FXNormalizeUploadPlanBody(before);
        if (after != before && ![after isEqualToData:before]) {
            r.HTTPBody = after;
            [r setValue:@(after.length).stringValue forHTTPHeaderField:@"Content-Length"];
            FXFileLog(@"normalized attachment upload-plan JSON shape");
        }
    }
    self.task = [[FXApiProtocol innerSession] dataTaskWithRequest:r completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        if (err) { [self.client URLProtocol:self didFailWithError:err]; return; }
        if (![resp isKindOfClass:NSHTTPURLResponse.class]) {
            [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorBadServerResponse userInfo:nil]];
            return;
        }
        NSHTTPURLResponse *h = (NSHTTPURLResponse *)resp;
        NSData *body = data ?: [NSData data];

        BOOL isDMCreate = post && [path hasSuffix:@"/users/@me/channels"];
        if (isDMCreate && h.statusCode == 400 && gSolveCaptcha &&
            ![r valueForHTTPHeaderField:@"X-Captcha-Token"].length) {
            NSString *challengeText = [[NSString alloc] initWithData:body encoding:NSUTF8StringEncoding];
            FXChallenge *challenge = FXParseChallenge(h.statusCode, challengeText);
            if (challenge) {
                if (gAltchaVariant < 0) {
                    NSURL *calibration = FXBuild(gAPI, @"/v1/auth/login", nil);
                    if (calibration) (void)FXObtainCaptchaToken(calibration);
                }
                NSString *captchaToken = gAltchaVariant >= 0 ? FXMakeToken(challenge, gAltchaVariant) : nil;
                if (captchaToken.length) {
                    NSMutableURLRequest *retry = [r mutableCopy];
                    [retry setValue:captchaToken forHTTPHeaderField:@"X-Captcha-Token"];
                    FXFileLog(@"captcha: retrying DM creation once with its own challenge");
                    self.task = [[FXApiProtocol innerSession] dataTaskWithRequest:retry completionHandler:^(NSData *retryData, NSURLResponse *retryResponse, NSError *retryError) {
                        if (retryError) {
                            [self.client URLProtocol:self didFailWithError:retryError];
                            return;
                        }
                        if (![retryResponse isKindOfClass:NSHTTPURLResponse.class]) {
                            [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorBadServerResponse userInfo:nil]];
                            return;
                        }
                        NSHTTPURLResponse *retryHTTP = (NSHTTPURLResponse *)retryResponse;
                        NSData *retryBody = retryData ?: [NSData data];
                        if (retryHTTP.statusCode >= 400 && retryHTTP.statusCode != 429) {
                            id retryJSON = retryBody.length ? [NSJSONSerialization JSONObjectWithData:retryBody options:0 error:nil] : nil;
                            NSDictionary *retryErrorJSON = [retryJSON isKindOfClass:NSDictionary.class] ? retryJSON : @{};
                            id retryCode = retryErrorJSON[@"code"] ?: retryErrorJSON[@"error"] ?: @"-";
                            FXFileLog(@"DM create retry HTTP %ld code=%@", (long)retryHTTP.statusCode, retryCode);
                        }
                        [self relayStatus:retryHTTP.statusCode headers:retryHTTP.allHeaderFields body:retryBody];
                    }];
                    [self.task resume];
                    return;
                }
                FXFileLog(@"captcha: DM challenge received but could not be solved; original response preserved");
            }
        }

        if ((h.statusCode == 200 || h.statusCode == 201) && post &&
            [path rangeOfString:@"/channels/[0-9]+/attachments$" options:NSRegularExpressionSearch].location != NSNotFound) {
            FXRememberUploadURLs(body);
            id planJSON = body.length ? [NSJSONSerialization JSONObjectWithData:body options:0 error:nil] : nil;
            NSArray *planItems = [planJSON isKindOfClass:NSDictionary.class] && [planJSON[@"attachments"] isKindOfClass:NSArray.class] ? planJSON[@"attachments"] : nil;
            FXFileLog(@"upload plan HTTP %ld items=%lu", (long)h.statusCode, (unsigned long)planItems.count);
        }
        BOOL uploadFailure = [path containsString:@"/attachments"] || [path containsString:@"/messages"];
        if (h.statusCode >= 400 && h.statusCode != 429 &&
            (uploadFailure || FXLogOnce([NSString stringWithFormat:@"%@ %ld %@", method, (long)h.statusCode, FXMaskPath(path)]))) {
            id ej = body.length ? [NSJSONSerialization JSONObjectWithData:body options:0 error:nil] : nil;
            NSDictionary *ed = [ej isKindOfClass:NSDictionary.class] ? ej : @{};
            id code = ed[@"code"] ?: ed[@"error"] ?: ed[@"type"] ?: @"-";
            id msg = ed[@"message"] ?: ed[@"detail"] ?: @"-";
            id field = ed[@"path"] ?: ed[@"errors"] ?: @"-";
            FXFileLog(@"HTTP %ld %@ %@ error_code=%@ message=%@ field=%@", (long)h.statusCode, method,
                      FXMaskPath(path), code, msg, field);
        }
        if (h.statusCode == 200 && [method isEqualToString:@"GET"] &&
            [path rangeOfString:@"^/api/v[0-9]+/users/(?:[0-9]+|@me)/profile$" options:NSRegularExpressionSearch].location != NSNotFound)
            body = FXFixProfileBadges(body);
        if (h.statusCode == 200 && [method isEqualToString:@"GET"] &&
            [path rangeOfString:@"/channels/[0-9]+/messages$" options:NSRegularExpressionSearch].location != NSNotFound)
            body = FXFixMessageList(body);
        else if ((h.statusCode == 200 || h.statusCode == 201) && post &&
                 [path rangeOfString:@"/channels/[0-9]+/messages$" options:NSRegularExpressionSearch].location != NSNotFound)
            body = FXFixSingleMessage(body);
        [self relayStatus:h.statusCode headers:h.allHeaderFields body:body];
    }];
    [self.task resume];
}

- (void)stopLoading { [self.task cancel]; self.task = nil; }
@end

static void FXHookConfig(Class cls) {
    SEL sel = @selector(protocolClasses);
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return;
    IMP orig = method_getImplementation(m);
    class_replaceMethod(cls, sel, imp_implementationWithBlock(^id(id s) {
        NSArray *base = ((id (*)(id, SEL))orig)(s, sel) ?: @[];
        NSMutableArray *result = [base mutableCopy];
        if (![result containsObject:FXApiProtocol.class]) [result insertObject:FXApiProtocol.class atIndex:0];
        if (![result containsObject:FXBadgeSVGProtocol.class]) [result insertObject:FXBadgeSVGProtocol.class atIndex:0];
        return result;
    }), method_getTypeEncoding(m));
}

static void FXInstallApiProtocol(void) {
    @try {
        [NSURLProtocol registerClass:FXApiProtocol.class];
        [NSURLProtocol registerClass:FXBadgeSVGProtocol.class];
        FXHookConfig(NSURLSessionConfiguration.class);
        FXHookConfig([NSURLSessionConfiguration defaultSessionConfiguration].class);
        FXHookConfig([NSURLSessionConfiguration ephemeralSessionConfiguration].class);
        FXFileLog(@"api and on-device badge WebP-to-SVG protocols installed");
    } @catch (NSException *e) { FXFileLog(@"api protocol exception: %@", e); }
}

static void FXInstallHooks(int stage) {
    if (stage < 2) return;
    NSMutableArray *sessionClasses = [NSMutableArray arrayWithObject:NSURLSession.class];
    [sessionClasses addObject:object_getClass([NSURLSession sharedSession])];
    [sessionClasses addObject:object_getClass(
        [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration ephemeralSessionConfiguration]])];

    NSArray *reqSels = @[
        @"dataTaskWithRequest:", @"dataTaskWithRequest:completionHandler:",
        @"uploadTaskWithRequest:fromData:", @"uploadTaskWithRequest:fromData:completionHandler:",
        @"uploadTaskWithRequest:fromFile:", @"uploadTaskWithRequest:fromFile:completionHandler:",
        @"uploadTaskWithStreamedRequest:",
        @"downloadTaskWithRequest:", @"downloadTaskWithRequest:completionHandler:",
        @"webSocketTaskWithRequest:"];
    NSArray *urlSels = @[
        @"dataTaskWithURL:", @"dataTaskWithURL:completionHandler:",
        @"downloadTaskWithURL:", @"downloadTaskWithURL:completionHandler:",
        @"webSocketTaskWithURL:", @"webSocketTaskWithURL:protocols:"];
    if (stage >= 2) for (Class c in sessionClasses) {
        @try {
            FXFileLog(@"stage 2: checking %@", NSStringFromClass(c));
            FXHookMany(c, reqSels, FXXformReq);
            FXHookMany(c, urlSels, FXXformURL);
        } @catch (NSException *e) { FXFileLog(@"stage 2 class exception %@: %@", NSStringFromClass(c), e); }
    }
    FXFileLog(@"stage 2 done");
    if (stage < 3) return;

    // Outgoing gateway frames (Identify cleanup, drop Discord-only opcodes)
    for (NSString *n in @[@"NSURLSessionWebSocketTask", @"__NSURLSessionWebSocketTask"]) {
        @try {
            Class c = NSClassFromString(n);
            if (c) FXHookMany(c, @[@"sendMessage:completionHandler:"], FXXformWSMessage);
            else FXFileLog(@"stage 3: class %@ unavailable", n);
        } @catch (NSException *e) { FXFileLog(@"stage 3 websocket exception %@: %@", n, e); }
    }

    // Other websocket stacks, if the app ships them
    Class sr = NSClassFromString(@"SRWebSocket");
    @try { FXHookMany(sr, @[@"initWithURLRequest:", @"initWithURLRequest:protocols:"], FXXformReq); }
    @catch (NSException *e) { FXFileLog(@"SocketRocket request hook exception: %@", e); }
    @try { FXHookMany(sr, @[@"initWithURL:", @"initWithURL:protocols:"], FXXformURL); }
    @catch (NSException *e) { FXFileLog(@"SocketRocket URL hook exception: %@", e); }
    @try { FXHookMany(NSClassFromString(@"RCTWebSocketModule"), @[@"connect:protocols:options:socketID:"], FXXformURL); }
    @catch (NSException *e) { FXFileLog(@"React Native websocket hook exception: %@", e); }

    FXHookURLConstruction();
    FXHookWebSocketClasses();
    FXInstallApiProtocol();
    FXFileLog(@"stage 3 done");
}

__attribute__((constructor)) static void FXInit(void) {
#if FX_STAGE >= 1
    @autoreleasepool {
        @try {
            NSString *logPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/fluxer_redirect.log"];
            NSDictionary *at = [[NSFileManager defaultManager] attributesOfItemAtPath:logPath error:nil];
            if ([at fileSize] > 200000) [[NSFileManager defaultManager] removeItemAtPath:logPath error:nil];
            FXFileLog(@"---- launch, stage %d, iOS %@", FX_STAGE, UIDevice.currentDevice.systemVersion);
            FXInstallHooks(FX_STAGE);
            FXFileLog(@"hooks installed");
            FXStartResolve();
            dispatch_async(dispatch_get_main_queue(), ^{ FXInstallInstanceGesture(); });
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        FXInstallInstanceGesture();
                        static dispatch_once_t late;
                        dispatch_once(&late, ^{ FXHookWebSocketClasses(); });   // classes loaded after launch
                    });
                }];
            FXFileLog(@"init done");
        } @catch (NSException *e) {
            FXFileLog(@"init exception: %@", e);
        }
    }
#endif
}
