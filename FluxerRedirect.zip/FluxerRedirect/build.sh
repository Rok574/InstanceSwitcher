#!/bin/sh
# Build FluxerRedirect.dylib for the Discord 348.0 (113691) IPA.
# Requires macOS + Xcode command line tools + iPhoneOS SDK.
set -eu
cd "$(dirname "$0")"

command -v xcrun >/dev/null 2>&1 || {
  echo "ERROR: xcrun is required. Run this on macOS with Xcode installed." >&2
  exit 1
}
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
[ -d "$SDK" ] || { echo "ERROR: iPhoneOS SDK not found." >&2; exit 1; }

xcrun --sdk iphoneos clang \
  -arch arm64 \
  -miphoneos-version-min=16.0 \
  -isysroot "$SDK" \
  -fobjc-arc -O2 -fvisibility=hidden \
  -dynamiclib -install_name @rpath/FluxerRedirect.dylib \
  -framework Foundation -framework UIKit -framework WebKit \
  -o FluxerRedirect.dylib FluxerRedirect.m

codesign -f -s - FluxerRedirect.dylib
file FluxerRedirect.dylib
echo "Built $(pwd)/FluxerRedirect.dylib"
