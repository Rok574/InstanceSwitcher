#!/bin/sh
# Builds FluxerRedirect.dylib for iOS (needs Xcode command line tools on a Mac).
set -e
cd "$(dirname "$0")"
SDK=$(xcrun --sdk iphoneos --show-sdk-path)
xcrun --sdk iphoneos clang -arch arm64 -miphoneos-version-min=13.0 -isysroot "$SDK" \
  -fobjc-arc -O2 -dynamiclib -install_name @rpath/FluxerRedirect.dylib \
  -framework Foundation -framework UIKit -framework WebKit \
  -o FluxerRedirect.dylib FluxerRedirect.m
codesign -f -s - FluxerRedirect.dylib
echo "Built $(pwd)/FluxerRedirect.dylib"
