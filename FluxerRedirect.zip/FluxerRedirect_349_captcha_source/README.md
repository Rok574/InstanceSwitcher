# FluxerRedirect — Discord iOS 348.0 + Fluxer captcha solver

Target IPA: Discord **348.0 (113691)**, minimum iOS **16.0**, arm64.

## What's new: automatic Fluxer captcha

Fluxer protects `POST /v1/auth/login`, `/register`, `/register/handoff`, `/forgot` and `/recover`
with an [ALTCHA](https://altcha.org) proof-of-work challenge (`PBKDF2/SHA-256`). Requests must carry
`X-Captcha-Token`; without it the server answers `400 CAPTCHA_REQUIRED`. The Discord app cannot
produce that token, which is why login failed with a verification error.

Now, when a request for one of those endpoints is redirected to Fluxer, the tweak:

1. sends a bare `POST {}` to the endpoint (captcha is checked before the body is validated, so no
   login/registration happens and none of your data is sent) to get a challenge,
2. solves it natively with `CCKeyDerivationPBKDF` on all cores,
3. adds the `X-Captcha-Token` header to the real request.

Registration validates its body *before* the captcha, so for register the challenge is taken from
`/v1/auth/forgot` instead.

Because the exact byte layout altcha-lib v2 feeds to PBKDF2 could not be checked from the source
available (only its callers), the tweak **verifies it against your server the first time**: it submits
a solved token to the bare probe and watches for `INVALID_CAPTCHA`. A rejected layout is followed by
the next of four candidates until the server accepts one. Expect 1–3 extra solves on the first
login after launch. The result is logged (`captcha: variant N accepted`).

If the instance has captcha turned off, the probe returns no challenge and requests go out untouched.

Set `"solve_captcha": false` in `Documents/fluxer_redirect.json` to disable.

## Gateway (WSS) notes

- Fluxer's gateway URL comes from `endpoints.gateway` in the discovery document. Discovery is tried at
  `<instance>/.well-known/fluxer`, `<instance>/api/v1/.well-known/fluxer`, and (for `web.` hosts)
  `https://api.<root>/v1/.well-known/fluxer`. If all fail, the gateway is guessed
  (`wss://gateway.<root>` for `web.` hosts) instead of blocking the socket.
- The URL always gets `v=1&encoding=json`. `compress=zstd-stream` is kept only if the app asked for it
  (`"gateway_zstd": false` to drop it). Fluxer has no zlib-stream.
- Log lines to check: `discovery ok/miss`, `endpoints ... gateway=`, `gateway: app asked X -> Y`.
  No `gateway: app asked` line means the app isn't using a hooked WebSocket class.

## Not covered

- Only the five endpoints above are handled. Group DM creation, gift redeem and application creation
  can also be gated; they would need a response hook.
- Escalated register cost (after heavy sign-ups from one network) is not matched, because the
  challenge comes from `/forgot`.
- Discord's login/register request and response shapes versus Fluxer's are not translated. Fluxer's
  login schema ignores unknown fields, but check the log if login still fails after the captcha.
- Not compiled or run in the environment this was written in: build it and check the log.

## Build

On a Mac with Xcode command-line tools: `./build.sh`, or push this folder to GitHub and run the
**Build FluxerRedirect** workflow, then download the `FluxerRedirect-iOS-arm64-Discord-348` artifact.

## Debugging

Log: `<App>/Documents/fluxer_redirect.log`. Look for lines starting `captcha:`. Logs never contain
passwords, tokens, emails or request/response bodies.
